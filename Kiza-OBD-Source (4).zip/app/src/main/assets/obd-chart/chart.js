(() => {
  "use strict";
  const element = document.getElementById("chart");
  const selection = document.getElementById("selection");
  const axisText = "#bbd2e4";
  const defaultSelection = "Prevuci za ugao · Uštini za zum · Dodirni stub za vrednost";
  const webGlProbe = document.createElement("canvas");
  let chart;
  let currentGroup;
  let healthy = false;
  let autoRotate = false;

  try {
    const gl = webGlProbe.getContext("webgl") || webGlProbe.getContext("experimental-webgl");
    if (gl && window.echarts) {
      const extension = gl.getExtension("WEBGL_lose_context");
      if (extension) extension.loseContext();
      chart = window.echarts.init(element, null, { renderer: "canvas", devicePixelRatio: Math.min(devicePixelRatio, 2) });
      chart.on("click", event => {
        if (event.data && event.data.detail) selection.textContent = event.data.detail;
      });
      element.addEventListener("webglcontextlost", () => { healthy = false; }, true);
      window.addEventListener("resize", () => chart.resize());
      if (window.ResizeObserver) new ResizeObserver(() => chart.resize()).observe(element);
      selection.textContent = defaultSelection;
      healthy = true;
    }
  } catch (error) {
    console.warn("3D grafikon nije dostupan", error);
  }

  function commonAxis() {
    return {
      axisLine: { lineStyle: { color: "#4b6d86" } },
      axisLabel: { color: axisText, fontSize: 11, margin: 6 },
      nameTextStyle: { color: axisText, fontSize: 11 },
      splitLine: { show: true, lineStyle: { color: "#253d53" } },
      axisPointer: { show: false }
    };
  }

  function color(fraction) {
    const hue = Math.round(166 - 126 * fraction);
    return `hsl(${hue}, 81%, ${53 + 10 * fraction}%)`;
  }

  function camera(motion) {
    return {
      projection: "perspective", alpha: 28, beta: 28, distance: 222,
      minDistance: 120, maxDistance: 330, rotateSensitivity: 1.2, zoomSensitivity: 0.85,
      damping: motion ? 0.9 : 0, animation: motion,
      autoRotate: motion && autoRotate, autoRotateSpeed: 8, autoRotateAfterStill: 2.5,
      panSensitivity: 0
    };
  }

  function render(frame) {
    if (!healthy) return false;
    try {
      const reset = currentGroup === undefined;
      if (reset || currentGroup !== frame.group) selection.textContent = defaultSelection;
      currentGroup = frame.group;
      const grid = {
        boxWidth: 158, boxDepth: Math.max(31, frame.labels.length * 16), boxHeight: 72,
        left: 0, right: 0, top: 4, bottom: 8, environment: "#101d2f",
        light: { main: { intensity: 1.2, alpha: 37, beta: 22 }, ambient: { intensity: 0.58 } }
      };
      if (reset) grid.viewControl = camera(frame.motion);
      const x = commonAxis();
      x.type = "category";
      x.name = "Vreme";
      x.data = frame.bins;
      x.axisLabel.interval = index => index % 3 === 0 || index === frame.bins.length - 1;
      const y = commonAxis();
      y.type = "category";
      y.name = "";
      y.data = frame.labels;
      const z = commonAxis();
      z.type = "value";
      z.name = frame.unit;
      z.min = frame.low;
      z.max = frame.high;
      z.interval = (frame.high - frame.low) / frame.levels;
      z.axisLabel.formatter = value => frame.group === "GEAR" && value === -1 ? "R" : String(value);

      chart.setOption({
        backgroundColor: "#101d2f", animation: frame.motion,
        animationDuration: 520, animationDurationUpdate: 360,
        xAxis3D: x, yAxis3D: y, zAxis3D: z, grid3D: grid,
        series: [{
          id: "transmission", type: "bar3D", shading: "lambert",
          minHeight: 0.48, bevelSize: 0.16, bevelSmoothness: 2,
          data: frame.bars.map(bar => ({
            id: bar.id, value: bar.xyz, detail: bar.detail,
            itemStyle: { color: color(bar.fraction) }
          }))
        }]
      });
      return true;
    } catch (error) {
      healthy = false;
      console.warn("Neuspešan prikaz 3D grafikona", error);
      return false;
    }
  }

  window.obdChart = {
    ready: () => healthy,
    render,
    rotate: (enabled, motion) => {
      autoRotate = enabled;
      if (healthy && currentGroup !== undefined) chart.setOption({
        grid3D: { viewControl: { autoRotate: motion && enabled, autoRotateSpeed: 8, autoRotateAfterStill: 2.5 } }
      });
    },
    reset: motion => {
      autoRotate = false;
      if (healthy && currentGroup !== undefined) chart.setOption({ grid3D: { viewControl: camera(motion) } });
      selection.textContent = defaultSelection;
    }
  };
})();
