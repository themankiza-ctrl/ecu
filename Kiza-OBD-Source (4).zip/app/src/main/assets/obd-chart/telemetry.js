(() => {
  "use strict";
  const element = document.getElementById("telemetry");
  const detail = document.getElementById("reading");
  const chart = window.echarts && window.echarts.init(element, null, {
    renderer: "canvas", devicePixelRatio: Math.min(devicePixelRatio, 2)
  });
  const opts = window.telemetryOptions;
  let frame = null;

  function select(time) {
    if (!Number.isFinite(time)) return;
    window.location.href = "https://appassets.androidplatform.net/obd-telemetry/select?t=" + Math.round(time);
  }

  function render(next, time) {
    if (!chart || !opts) return false;
    try {
      frame = next;
      const timeline = frame.type === "timeline";
      element.setAttribute("aria-label", timeline ? "Vremenska linija telemetrije" : frame.title);
      detail.textContent = timeline ? "Dodirni grafikon ili pomeri kursor ispod." : frame.note;
      if (!timeline && !frame.cells.length) {
        chart.clear();
        return true;
      }
      chart.setOption(timeline ? opts.timeline(frame, time, element.clientWidth < 435)
        : opts.heatmap(frame, element.clientWidth < 435), { notMerge: true, lazyUpdate: false });
      return true;
    } catch (error) {
      console.warn("Telemetrija nije dostupna", error);
      return false;
    }
  }

  function seek(time) {
    if (!chart || !frame || frame.type !== "timeline") return;
    chart.setOption({ series: frame.tracks.map(track => ({ id: track.id, markLine: opts.cursor(time) })) }, { lazyUpdate: true });
  }

  if (chart) {
    chart.getZr().on("click", point => {
      if (!frame || frame.type !== "timeline") return;
      const pointPx = [point.offsetX, point.offsetY];
      const lanes = new Set(frame.tracks.map(track => track.lane));
      for (let i = 0; i < lanes.size; i++) {
        if (!chart.containPixel({ gridIndex: i }, pointPx)) continue;
        const result = chart.convertFromPixel({ gridIndex: i }, pointPx);
        if (Array.isArray(result)) select(result[0]);
        break;
      }
    });
    chart.on("click", event => {
      if (!frame || frame.type !== "map" || event.seriesType !== "heatmap") return;
      const [column, row, mean, count, peak, at] = event.value;
      const number = new Intl.NumberFormat("sr-Latn-RS", { maximumFractionDigits: 1 });
      detail.textContent = (row + 1) + ". stepen · " + frame.labels[column] + " o/min · " +
        number.format(mean) + " " + frame.unit + " · " + count + " uzoraka · vrh " + number.format(peak);
      select(at);
    });
    const resize = () => chart.resize();
    window.addEventListener("resize", resize);
    if (window.ResizeObserver) new ResizeObserver(resize).observe(element);
  }
  window.obdTelemetry = { ready: () => !!(chart && opts), render, seek };
})();
