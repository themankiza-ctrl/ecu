((root) => {
  "use strict";
  const palette = {
    ATF: "#ffcb78", CLUTCH_1: "#fa9d8a", CLUTCH_2: "#b4aaff", MODULE_TEMP: "#d1e58c",
    INPUT: "#71e4d0", OUTPUT: "#87bfff", GEAR: "#a8b9ff"
  };
  const title = ["Temperature · °C", "Vratila · o/min", "Stepen prenosa"];
  const short = {
    "Temperatura ulja": "Ulje", "Temperatura kvačila 1": "K1", "Temperatura kvačila 2": "K2",
    "Temperatura kontrolera": "TCM", "Ulazno vratilo": "Ulaz", "Izlazno vratilo": "Izlaz",
    "Stepen prenosa": "Stepen"
  };
  const gridColor = "#294359";
  const text = "#c1d3e5";
  const numeric = new Intl.NumberFormat("sr-Latn-RS", { maximumFractionDigits: 1 });

  function clock(time) {
    const seconds = Math.round(time / 1000);
    const minutes = Math.floor(seconds / 60);
    const mm = String(minutes % 60).padStart(2, "0");
    return (minutes >= 60 ? Math.floor(minutes / 60) + ":" : "") + mm + ":" + String(seconds % 60).padStart(2, "0");
  }

  function cursor(time) {
    return {
      silent: true, animation: false, symbol: "none", label: { show: false },
      lineStyle: { color: "#c5f8f0", type: "solid", opacity: 0.86, width: 1.5 },
      data: [{ xAxis: time }]
    };
  }

  function commonAxis() {
    return {
      axisLabel: { color: text, fontSize: 11, hideOverlap: true },
      axisLine: { lineStyle: { color: gridColor } },
      axisTick: { show: false },
      splitLine: { lineStyle: { color: gridColor } }
    };
  }

  function timeline(frame, time, narrow) {
    const lanes = [...new Set(frame.tracks.map(track => track.lane))];
    const height = 72 / lanes.length;
    const left = narrow ? 42 : 52;
    const right = narrow ? 12 : 20;
    const axes = lanes.map((_, i) => i);
    return {
      animation: false,
      backgroundColor: "#101d2f",
      legend: {
        type: "scroll", left, right, top: 0, itemHeight: 8, itemWidth: 10, itemGap: 8,
        textStyle: { color: text, fontSize: 10 }, pageTextStyle: { color: text },
        formatter: name => short[name] || name
      },
      title: lanes.map((lane, i) => ({
        left, top: (8 + i * height) + "%", text: title[lane],
        textStyle: { color: text, fontSize: 11, fontWeight: 550 }, padding: 0
      })),
      grid: lanes.map((_, i) => ({ left, right, top: (13 + i * height) + "%", height: (height - 7) + "%" })),
      axisPointer: { link: [{ xAxisIndex: "all" }] },
      tooltip: {
        trigger: "axis", renderMode: "richText", confine: true,
        backgroundColor: "#142638", borderColor: gridColor, textStyle: { color: text },
        axisPointer: { type: "line", snap: true, label: { show: false } },
        formatter: params => {
          if (!params.length) return "";
          const lines = [clock(params[0].axisValue)];
          for (const item of params) {
            if (!item.value || item.value[1] == null) continue;
            const value = item.seriesId === "GEAR" && item.value[1] === -1 ? "R" : numeric.format(item.value[1]);
            lines.push(item.seriesName + " · " + value);
          }
          return lines.join("\n");
        }
      },
      xAxis: lanes.map((_, i) => ({
        ...commonAxis(), type: "value", gridIndex: i, min: frame.from, max: frame.to,
        splitLine: { show: false },
        axisLabel: { color: text, show: i === lanes.length - 1, formatter: clock, hideOverlap: true }
      })),
      yAxis: lanes.map((lane, i) => ({
        ...commonAxis(), type: "value", gridIndex: i, scale: lane !== 2,
        min: lane === 2 ? -1 : undefined, max: lane === 2 ? 7 : undefined,
        minInterval: lane === 2 ? 1 : undefined,
        axisLabel: { color: text, formatter: value => lane === 2 && value === -1 ? "R" : numeric.format(value) }
      })),
      dataZoom: [
        { type: "inside", xAxisIndex: axes, filterMode: "none" },
        { type: "slider", xAxisIndex: axes, filterMode: "none", left, right, bottom: 3, height: 17,
          fillerColor: "#346c8548", borderColor: gridColor, textStyle: { color: text },
          labelFormatter: clock, showDataShadow: false, brushSelect: false }
      ],
      series: frame.tracks.map(track => ({
        id: track.id, name: track.label, type: "line", xAxisIndex: lanes.indexOf(track.lane),
        yAxisIndex: lanes.indexOf(track.lane), data: track.points, showSymbol: track.points.length === 1,
        symbolSize: 6, clip: true, step: track.lane === 2 ? "end" : false, connectNulls: false,
        lineStyle: { color: palette[track.id], width: 2 }, itemStyle: { color: palette[track.id] },
        markLine: cursor(time),
        markPoint: track.lane === 2 ? {
          symbol: "diamond", symbolSize: 8, label: { show: false }, itemStyle: { color: "#ffcb78" },
          data: frame.shifts.map(([ms, gear]) => ({ coord: [ms, gear] }))
        } : undefined
      }))
    };
  }

  function heatmap(frame, narrow) {
    const max = Math.max(frame.max, frame.min + 1);
    const color = ["#22354c", "#258d96", "#73d9c7", "#ffcb78"];
    return {
      animation: false,
      backgroundColor: "#101d2f",
      grid: { left: 34, right: 14, top: 13, bottom: narrow ? 101 : 88 },
      xAxis: {
        ...commonAxis(), type: "category", data: frame.labels, name: "Izlazno vratilo · o/min",
        nameLocation: "middle", nameGap: narrow ? 46 : 27, nameTextStyle: { color: text },
        axisLabel: { color: text, fontSize: narrow ? 9 : 11, interval: 0, rotate: narrow ? 37 : 0 }
      },
      yAxis: { ...commonAxis(), type: "category", data: ["1.", "2.", "3.", "4.", "5.", "6.", "7."] },
      visualMap: {
        type: "continuous", min: frame.min, max, dimension: 2, orient: "horizontal",
        left: "center", bottom: 3, itemWidth: 11, itemHeight: narrow ? 95 : 138,
        text: [numeric.format(max) + " " + frame.unit, numeric.format(frame.min)],
        textStyle: { color: text }, inRange: { color }
      },
      tooltip: {
        renderMode: "richText", confine: true, backgroundColor: "#142638", borderColor: gridColor, textStyle: { color: text },
        formatter: ({ value: [column, row, mean, count, peak] }) =>
          (row + 1) + ". stepen · " + frame.labels[column] + " o/min\n" +
          "Prosek " + numeric.format(mean) + " " + frame.unit + " · vrh " +
          numeric.format(peak) + " " + frame.unit + "\nUzoraka " + count
      },
      series: [{
        type: "heatmap", data: frame.cells, encode: { x: 0, y: 1, value: 2 },
        itemStyle: { borderColor: "#101d2f", borderWidth: 2 },
        label: { show: true, color: "#fff", textBorderColor: "#203143", textBorderWidth: 2,
          fontSize: narrow ? 10 : 12, formatter: data => numeric.format(data.value[2]) }
      }]
    };
  }

  const api = { timeline, heatmap, cursor, clock };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.telemetryOptions = api;
})(typeof window === "undefined" ? globalThis : window);
