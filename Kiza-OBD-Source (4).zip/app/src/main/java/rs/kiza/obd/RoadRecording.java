package rs.kiza.obd;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

final class RoadRecording {
    private static final int MAX_ROWS = 100_000;
    private static final long MAX_BYTES = 24L * 1024 * 1024;
    private static final long MAX_DURATION_MS = 24L * 60 * 60 * 1000;

    static final class Row {
        final long time;
        final long latency;
        final AudiQ5.Sample sample;
        final double[] readings = new double[AudiQ5.Channel.values().length];

        Row(long time, long latency, String[] values) {
            this.time = time;
            this.latency = latency;
            sample = new AudiQ5.Sample(values);
            for (int i = 0; i < values.length; i++) {
                readings[i] = values[i] == null ? Double.NaN : values[i].equals("R") ? -1
                    : Double.parseDouble(values[i]);
            }
        }

        double get(AudiQ5.Channel channel) { return readings[channel.ordinal()]; }
    }

    static final class Scan {
        final long time;
        final Map<String, Integer> codes;
        final AudiQ5.ScanStatus status;

        Scan(long time, String rawCodes, String status) {
            this.time = time;
            codes = new java.util.TreeMap<>();
            for (String item : rawCodes.toUpperCase(Locale.ROOT).split("\\|")) {
                if (item.matches("[PCBU][0-3][0-9A-F]{5}:[0-9A-F]{2}")) {
                    codes.merge(item.substring(0, 7), Integer.parseInt(item.substring(8), 16), (a, b) -> a | b);
                }
            }
            AudiQ5.ScanStatus parsed;
            try {
                parsed = AudiQ5.ScanStatus.valueOf(status);
            } catch (IllegalArgumentException error) {
                parsed = AudiQ5.ScanStatus.UNKNOWN;
            }
            this.status = parsed;
        }

        boolean usable() {
            return status == AudiQ5.ScanStatus.OK || !codes.isEmpty();
        }
    }

    final List<Row> rows = new ArrayList<>();
    final List<AudiQ5.Channel> channels = new ArrayList<>();
    final int[] counts = new int[AudiQ5.Channel.values().length];
    String identity = "";
    String ended = "";
    long duration;
    int malformed;
    boolean demo;
    Scan startScan;
    Scan endScan;

    static RoadRecording read(File file) throws IOException {
        if (file.length() > MAX_BYTES) throw new IOException("Snimak je prevelik za pregled.");
        RoadRecording record = new RoadRecording();
        record.demo = file.getName().startsWith("Q5-demo-");
        try (BufferedReader reader = Files.newBufferedReader(file.toPath(), StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (header == null) throw new IOException("Snimak nema CSV zaglavlje.");
            List<String> names = fields(header.replaceFirst("^\uFEFF", ""));
            Map<String, Integer> columns = new HashMap<>();
            for (int i = 0; i < names.size(); i++) columns.put(names.get(i), i);
            if (!columns.containsKey("elapsed_ms") || !columns.containsKey("event")) {
                throw new IOException("CSV format snimka nije prepoznat.");
            }
            String line;
            int lines = 0;
            while ((line = reader.readLine()) != null) {
                if (++lines > MAX_ROWS) throw new IOException("Snimak ima previše redova za pregled.");
                if (line.isEmpty()) continue;
                try {
                    List<String> row = fields(line);
                    if (row.size() != names.size()) throw new IllegalArgumentException("CSV width");
                    record.accept(row, columns);
                } catch (IllegalArgumentException error) {
                    record.malformed++;
                }
            }
        }
        for (AudiQ5.Channel channel : AudiQ5.Channel.values()) {
            if (record.counts[channel.ordinal()] > 0) record.channels.add(channel);
        }
        return record;
    }

    private void accept(List<String> row, Map<String, Integer> columns) {
        long time = Long.parseLong(get(row, columns, "elapsed_ms"));
        if (time < duration || time > MAX_DURATION_MS) throw new IllegalArgumentException("CSV time");
        String event = get(row, columns, "event");
        demo |= "demo".equals(get(row, columns, "source"));
        if ("sample".equals(event)) {
            String[] values = new String[counts.length];
            long latency = -1;
            String rawLatency = get(row, columns, "sample_ms");
            if (!rawLatency.isEmpty()) latency = Long.parseLong(rawLatency);
            for (AudiQ5.Channel channel : AudiQ5.Channel.values()) {
                String value = get(row, columns, channel.column);
                if (valid(channel, value)) {
                    values[channel.ordinal()] = value;
                    counts[channel.ordinal()]++;
                } else if (!value.isEmpty()) {
                    malformed++;
                }
            }
            rows.add(new Row(time, latency, values));
        } else if ("start".equals(event) || "end_scan".equals(event)) {
            if (identity.isEmpty()) {
                List<String> parts = new ArrayList<>();
                for (String column : Arrays.asList("tcm_part", "odx_or_system", "tcm_hardware", "tcm_software")) {
                    String value = get(row, columns, column);
                    if (!value.isEmpty()) parts.add(value);
                }
                identity = String.join(" · ", parts);
            }
            Scan scan = new Scan(time, get(row, columns, "tcm_dtc_status"), get(row, columns, "tcm_dtc_scan"));
            if ("start".equals(event)) startScan = scan;
            else endScan = scan;
        } else {
            ended = event;
        }
        duration = time;
    }

    List<RoadChartHistory.Point> window(long time) {
        if (rows.isEmpty()) return Collections.emptyList();
        List<RoadChartHistory.Point> result = new ArrayList<>();
        int low = 0;
        int high = rows.size();
        long from = time - RoadChartHistory.WINDOW_MS;
        while (low < high) {
            int mid = (low + high) >>> 1;
            if (rows.get(mid).time < from) low = mid + 1;
            else high = mid;
        }
        for (int i = low; i < rows.size(); i++) {
            Row row = rows.get(i);
            if (row.time > time) break;
            result.add(new RoadChartHistory.Point(row.time, row.sample));
        }
        if (result.isEmpty() || result.get(result.size() - 1).millis < time) {
            result.add(new RoadChartHistory.Point(time, new AudiQ5.Sample(new String[counts.length])));
        }
        return result;
    }

    private static boolean valid(AudiQ5.Channel channel, String raw) {
        if (raw.isEmpty() || raw.length() > 16) return false;
        if (channel == AudiQ5.Channel.GEAR) return raw.equals("R") || raw.length() == 1 && raw.charAt(0) >= '1' && raw.charAt(0) <= '7';
        try {
            double value = Double.parseDouble(raw);
            return Double.isFinite(value) && value >= -40 && value < 65535
                && (channel.slow || value >= 0);
        } catch (NumberFormatException error) {
            return false;
        }
    }

    private static String get(List<String> row, Map<String, Integer> columns, String key) {
        Integer index = columns.get(key);
        return index == null || index >= row.size() ? "" : row.get(index);
    }

    private static List<String> fields(String input) {
        List<String> result = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean quoted = false;
        boolean afterQuote = false;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (quoted) {
                if (c != '"') field.append(c);
                else if (i + 1 < input.length() && input.charAt(i + 1) == '"') {
                    field.append('"');
                    i++;
                } else {
                    quoted = false;
                    afterQuote = true;
                }
            } else if (c == ',') {
                result.add(field.toString());
                field.setLength(0);
                afterQuote = false;
            } else if (afterQuote) {
                throw new IllegalArgumentException("CSV quoted field");
            } else if (c == '"') {
                if (field.length() > 0) throw new IllegalArgumentException("CSV quote");
                quoted = true;
            } else {
                field.append(c);
            }
        }
        if (quoted) throw new IllegalArgumentException("CSV unfinished field");
        result.add(field.toString());
        return result;
    }
}
