package rs.kiza.obd;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Comparator;

public final class Q5Activity extends Activity {
    private static final int CONNECT_PERMISSION = 61;
    private static final int EXPORT = 62;
    private static final int NOTIFY = 63;
    private static final int BG = 0xFF0A1220;
    private static final int PANEL = 0xFF122135;
    private static final int OUTLINE = 0xFF294158;
    private static final int INK = 0xFFF2F8FF;
    private static final int SUB = 0xFFA6BFD1;
    private static final int ACCENT = 0xFF6AF1C2;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final AudiQ5.Channel[] allChannels = AudiQ5.Channel.values();
    private final TextView[] readings = new TextView[allChannels.length];
    private List<AudiQ5.Channel> chartChannels = Collections.emptyList();
    private AudiQ5.Channel selected = AudiQ5.Channel.GEAR;
    private RoadBarGrid.Group barGroup = RoadBarGrid.Group.TEMPERATURE;
    private List<RoadBarGrid.Group> barGroups = Collections.emptyList();
    private boolean barsVisible = true;
    private TransmissionChart chart;
    private EnhancedBars bars;
    private LinearLayout barCamera;
    private Button rotateBars;
    private boolean rotatingBars;
    private TextView chartValue, chartHint, barLegend, barDetail;
    private Button barsToggle, lineToggle;
    private LinearLayout livePanel;
    private LinearLayout diagnostics;
    private Q5RoadService.LocalBinder binder;
    private boolean bound;
    private boolean hasExport;
    private boolean wasRecording;
    private TextView status, details, coverage, faults, samples;
    private Button connect, demo, record, export, review, channelPicker;
    private File plannedExport;
    private final Runnable update = new Runnable() {
        @Override public void run() {
            render();
            ui.postDelayed(this, 400);
        }
    };

    private final ServiceConnection service = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder handle) {
            binder = (Q5RoadService.LocalBinder) handle;
            render();
        }

        @Override public void onServiceDisconnected(ComponentName name) {
            binder = null;
            render();
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (state != null) {
            if (state.getString("export_file") != null) {
                plannedExport = new File(Q5RoadService.logDirectory(this), state.getString("export_file"));
            }
            selected = AudiQ5.Channel.valueOf(state.getString("channel", AudiQ5.Channel.GEAR.name()));
            barGroup = RoadBarGrid.Group.valueOf(state.getString("bar_group", RoadBarGrid.Group.TEMPERATURE.name()));
            barsVisible = state.getBoolean("bars_visible", true);
        }
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        else getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(BG);
        buildUi();
    }

    @Override protected void onStart() {
        super.onStart();
        hasExport = availableLogs().length > 0;
        bound = bindService(new Intent(this, Q5RoadService.class), service, Context.BIND_AUTO_CREATE);
        ui.post(update);
    }

    @Override protected void onStop() {
        ui.removeCallbacks(update);
        if (bound) unbindService(service);
        bound = false;
        binder = null;
        super.onStop();
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        if (plannedExport != null) state.putString("export_file", plannedExport.getName());
        state.putString("channel", selected.name());
        state.putString("bar_group", barGroup.name());
        state.putBoolean("bars_visible", barsVisible);
        super.onSaveInstanceState(state);
    }

    private void buildUi() {
        LinearLayout root = column();
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets safe = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
            } else {
                view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, -1));
        LinearLayout page = column();
        page.setPadding(dp(20), dp(16), dp(20), dp(24));
        scroll.addView(page);

        page.addView(text(getString(R.string.q5_transmission), 30, INK, true));
        page.addView(text(getString(R.string.q5_subtitle), 15, SUB, false));
        gap(page, 16);

        LinearLayout link = card(page);
        status = text("", 16, ACCENT, true);
        link.addView(status);
        coverage = text("", 14, SUB, false);
        link.addView(coverage);
        gap(link, 8);
        connect = button(getString(R.string.connect_adapter), false, this::choose);
        demo = button(getString(R.string.try_demo), false, () -> startAdapter(new Intent().putExtra("type", "demo")));
        pair(link, connect, demo);

        gap(page, 12);
        LinearLayout logger = card(page);
        logger.addView(text(getString(R.string.road_log), 20, INK, true));
        gap(logger, 4);
        logger.addView(text(getString(R.string.road_log_help), 14, SUB, false));
        samples = text("", 14, ACCENT, true);
        logger.addView(samples);
        gap(logger, 8);
        record = button(getString(R.string.start_recording), true, this::toggleRecording);
        logger.addView(record);
        gap(logger, 7);
        export = button(getString(R.string.export_csv), false, this::chooseExport);
        logger.addView(export);
        gap(logger, 7);
        review = button("Analiziraj snimak", true, this::chooseReview);
        logger.addView(review);

        gap(page, 12);
        LinearLayout graph = card(page);
        graph.addView(text(getString(R.string.chart_title), 20, INK, true));
        gap(graph, 8);
        barsToggle = button(getString(R.string.bar_mode), true, () -> showChartMode(true));
        lineToggle = button(getString(R.string.line_mode), false, () -> showChartMode(false));
        pair(graph, barsToggle, lineToggle);
        gap(graph, 8);
        channelPicker = button(getString(R.string.chart_choose), false, this::chooseChartData);
        graph.addView(channelPicker);
        gap(graph, 6);
        chartValue = text("—", 29, ACCENT, true);
        graph.addView(chartValue);
        chart = new TransmissionChart(this);
        graph.addView(chart, new LinearLayout.LayoutParams(-1, dp(224)));
        bars = new EnhancedBars(this, detail -> {
            set(barDetail, detail);
            barDetail.setVisibility(detail.isEmpty() ? View.GONE : View.VISIBLE);
        });
        graph.addView(bars, new LinearLayout.LayoutParams(-1, dp(270)));
        barDetail = text("", 15, ACCENT, true);
        barDetail.setVisibility(View.GONE);
        graph.addView(barDetail);
        barLegend = text("", 12, SUB, false);
        graph.addView(barLegend);
        barCamera = column();
        rotateBars = button("Rotiraj", false, () -> {
            rotatingBars = !rotatingBars;
            bars.setRotating(rotatingBars);
            set(rotateBars, rotatingBars ? "Zaustavi rotaciju" : "Rotiraj");
        });
        Button resetCamera = button("Vrati ugao", false, () -> {
            rotatingBars = false;
            bars.resetCamera();
            set(rotateBars, "Rotiraj");
        });
        pair(barCamera, rotateBars, resetCamera);
        graph.addView(barCamera);
        gap(graph, 5);
        chartHint = text("", 12, SUB, false);
        graph.addView(chartHint);
        applyChartMode();

        gap(page, 12);
        livePanel = card(page);
        livePanel.addView(text(getString(R.string.transmission_readings), 19, INK, true));
        for (int i = 0; i < allChannels.length; i += 2) {
            gap(livePanel, 9);
            pair(livePanel, metric(i, allChannels[i].label), metric(i + 1, allChannels[i + 1].label));
        }

        gap(page, 12);
        diagnostics = card(page);
        diagnostics.addView(text(getString(R.string.transmission_identification), 19, INK, true));
        gap(diagnostics, 5);
        details = text("", 14, SUB, false);
        details.setTextIsSelectable(true);
        diagnostics.addView(details);
        gap(diagnostics, 10);
        diagnostics.addView(text(getString(R.string.transmission_faults), 18, INK, true));
        gap(diagnostics, 5);
        faults = text("", 14, SUB, false);
        faults.setTextIsSelectable(true);
        diagnostics.addView(faults);
        setContentView(root);
        render();
    }

    private void choose() {
        if (binder == null) return;
        Q5RoadService.State state = binder.snapshot();
        if (state.connected || state.waiting) {
            binder.disconnect();
        } else {
            new AlertDialog.Builder(this).setTitle(R.string.connect_adapter)
                .setItems(new String[]{getString(R.string.bluetooth_classic), "Wi-Fi"}, (dialog, item) -> {
                    if (item == 0) pairedBluetooth(); else wifiSettings();
                }).setNegativeButton(R.string.cancel, null).show();
        }
    }

    @SuppressLint("MissingPermission")
    private void pairedBluetooth() {
        if (Build.VERSION.SDK_INT >= 31
                && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, CONNECT_PERMISSION);
            return;
        }
        BluetoothManager manager = getSystemService(BluetoothManager.class);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null) {
            Toast.makeText(this, R.string.bluetooth_unavailable, Toast.LENGTH_LONG).show();
            return;
        }
        List<BluetoothDevice> devices = new ArrayList<>();
        if (adapter.isEnabled()) devices.addAll(adapter.getBondedDevices());
        devices.removeIf(device -> device.getType() == BluetoothDevice.DEVICE_TYPE_LE);
        if (devices.isEmpty()) {
            new AlertDialog.Builder(this).setTitle(R.string.pair_elm).setMessage(R.string.pair_elm_instructions)
                .setPositiveButton(R.string.bluetooth_settings, (dialog, item) ->
                    startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)))
                .setNegativeButton(R.string.cancel, null).show();
            return;
        }
        devices.sort(Comparator.comparing(this::deviceLabel, String.CASE_INSENSITIVE_ORDER));
        String[] labels = devices.stream().map(this::deviceLabel).toArray(String[]::new);
        new AlertDialog.Builder(this).setTitle(R.string.paired_bluetooth_devices)
            .setItems(labels, (dialog, item) -> startAdapter(new Intent().putExtra("type", "bt")
                .putExtra("address", devices.get(item).getAddress()).putExtra("label", labels[item])))
            .setNegativeButton(R.string.cancel, null).show();
    }

    @SuppressLint("MissingPermission")
    private String deviceLabel(BluetoothDevice device) {
        String name = device.getName();
        String address = device.getAddress();
        return name == null || name.trim().isEmpty() ? address : name + " · " + address.substring(12);
    }

    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        if (request != CONNECT_PERMISSION || results.length == 0) return;
        if (results[0] == PackageManager.PERMISSION_GRANTED) pairedBluetooth();
        else Toast.makeText(this, R.string.bluetooth_permission, Toast.LENGTH_LONG).show();
    }

    private void wifiSettings() {
        android.content.SharedPreferences settings = getSharedPreferences("MainActivity", MODE_PRIVATE);
        LinearLayout fields = column();
        fields.setPadding(dp(22), dp(8), dp(22), 0);
        fields.addView(text(getString(R.string.wifi_join), 14, SUB, false));
        EditText host = new EditText(this);
        host.setSingleLine();
        host.setHint(R.string.adapter_ipv4);
        host.setInputType(InputType.TYPE_CLASS_PHONE);
        host.setText(settings.getString("host", "192.168.0.10"));
        fields.addView(host);
        EditText port = new EditText(this);
        port.setSingleLine();
        port.setHint("Port");
        port.setInputType(InputType.TYPE_CLASS_NUMBER);
        port.setText(settings.getString("port", "35000"));
        fields.addView(port);

        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(R.string.wifi_adapter).setView(fields)
            .setNeutralButton(R.string.wifi_settings, (d, item) ->
                startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)))
            .setNegativeButton(R.string.cancel, null).setPositiveButton(R.string.connect, null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String address = host.getText().toString().trim();
            String portText = port.getText().toString().trim();
            if (!validIpv4(address)) {
                host.setError(getString(R.string.invalid_ipv4));
                return;
            }
            int number;
            try {
                number = Integer.parseInt(portText);
                if (number < 1 || number > 65535) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                port.setError(getString(R.string.invalid_port));
                return;
            }
            dialog.dismiss();
            settings.edit().putString("host", address).putString("port", portText).apply();
            startAdapter(new Intent().putExtra("type", "wifi").putExtra("address", address)
                .putExtra("port", number).putExtra("label", "Wi-Fi · " + address));
        }));
        dialog.show();
    }

    private static boolean validIpv4(String address) {
        if (!address.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) return false;
        for (String part : address.split("\\.")) {
            if (Integer.parseInt(part) > 255) return false;
        }
        return true;
    }

    private void chooseChartData() {
        if (barsVisible) {
            List<RoadBarGrid.Group> choices = barGroups;
            String[] names = choices.stream().map(group -> group.label).toArray(String[]::new);
            new AlertDialog.Builder(this).setTitle(R.string.bar_group_choose)
                .setSingleChoiceItems(names, choices.indexOf(barGroup), (dialog, position) -> {
                    barGroup = choices.get(position);
                    dialog.dismiss();
                    render();
                }).setNegativeButton(R.string.cancel, null).show();
            return;
        }
        List<AudiQ5.Channel> choices = chartChannels;
        String[] names = choices.stream().map(channel -> channel.label).toArray(String[]::new);
        new AlertDialog.Builder(this).setTitle(R.string.chart_choose)
            .setSingleChoiceItems(names, choices.indexOf(selected), (dialog, position) -> {
                selected = choices.get(position);
                dialog.dismiss();
                render();
            }).setNegativeButton(R.string.cancel, null).show();
    }

    private void startAdapter(Intent target) {
        if (binder == null || binder.snapshot().connected || binder.snapshot().waiting) return;
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED && !getPreferences(0).getBoolean("notificationAsked", false)) {
            getPreferences(0).edit().putBoolean("notificationAsked", true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFY);
        }
        Intent command = new Intent(this, Q5RoadService.class).setAction(Q5RoadService.OPEN);
        if (target.getExtras() != null) command.putExtras(target.getExtras());
        try {
            startForegroundService(command);
        } catch (IllegalStateException | SecurityException error) {
            Toast.makeText(this, getString(R.string.service_start_failed), Toast.LENGTH_LONG).show();
        }
    }

    private void toggleRecording() {
        if (binder == null) return;
        if (binder.snapshot().recording) binder.stopRecording();
        else binder.record();
    }

    private File[] availableLogs() {
        File[] files = Q5RoadService.logDirectory(this)
            .listFiles((folder, name) -> name.startsWith("Q5-") && name.endsWith(".csv"));
        if (files == null) return new File[0];
        Arrays.sort(files, Comparator.comparingLong(File::lastModified).thenComparing(File::getName).reversed());
        return files;
    }

    private void chooseReview() {
        File[] files = availableLogs();
        if (files.length == 0) return;
        if (files.length == 1) {
            openReview(files[0]);
            return;
        }
        String[] names = Arrays.stream(files).map(File::getName).toArray(String[]::new);
        new AlertDialog.Builder(this).setTitle("Izaberi snimak za analizu")
            .setItems(names, (dialog, index) -> openReview(files[index]))
            .setNegativeButton(R.string.cancel, null).show();
    }

    private void openReview(File file) {
        startActivity(new Intent(this, RoadReviewActivity.class)
            .putExtra(RoadReviewActivity.FILE, file.getName()));
    }

    private void chooseExport() {
        File[] files = availableLogs();
        if (files.length == 0) return;
        if (files.length == 1) {
            requestExport(files[0]);
            return;
        }
        String[] names = Arrays.stream(files).map(File::getName).toArray(String[]::new);
        new AlertDialog.Builder(this).setTitle(getString(R.string.choose_road_log))
            .setItems(names, (dialog, index) -> requestExport(files[index]))
            .setNegativeButton(getString(R.string.cancel), null).show();
    }

    private void requestExport(File file) {
        plannedExport = file;
        Intent picker = new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/csv")
            .addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE, file.getName());
        try {
            startActivityForResult(picker, EXPORT);
        } catch (android.content.ActivityNotFoundException error) {
            plannedExport = null;
            Toast.makeText(this, getString(R.string.file_picker_unavailable), Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != EXPORT) return;
        File file = plannedExport;
        plannedExport = null;
        if (result != RESULT_OK || data == null || data.getData() == null || file == null) return;
        android.net.Uri uri = data.getData();
        new Thread(() -> {
            boolean saved;
            try (OutputStream output = getContentResolver().openOutputStream(uri, "wt")) {
                if (output == null) throw new IOException(getString(R.string.cannot_open_destination));
                Files.copy(file.toPath(), output);
                saved = true;
            } catch (IOException | SecurityException error) {
                saved = false;
            }
            String message = saved ? getString(R.string.csv_exported) : getString(R.string.csv_export_failed);
            runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
        }, "q5-csv-export").start();
    }

    private void render() {
        Q5RoadService.State state = binder == null ? Q5RoadService.State.idle(getString(R.string.opening_q5))
            : binder.snapshot();
        set(status, state.status);
        set(details, state.identity);
        set(coverage, state.coverage);
        set(faults, state.faultText);
        diagnostics.setVisibility(state.identity.isEmpty() && state.faultText.isEmpty() ? View.GONE : View.VISIBLE);
        set(samples, state.recording || state.rows > 0
            ? getString(R.string.stored_sample_count, state.rows) : "");
        samples.setVisibility(state.recording || state.rows > 0 ? View.VISIBLE : View.GONE);
        set(connect, state.connected || state.waiting ? getString(R.string.disconnect) : getString(R.string.connect_adapter));
        set(record, state.recording ? getString(R.string.stop_and_save) : getString(R.string.start_recording));

        enable(connect, binder != null);
        enable(demo, binder != null && !state.connected && !state.waiting);
        enable(record, state.connected && !state.waiting && !state.channels.isEmpty());
        if (wasRecording && !state.recording) hasExport = availableLogs().length > 0;
        wasRecording = state.recording;
        enable(export, !state.recording && hasExport);
        enable(review, !state.recording && hasExport);
        barCamera.setVisibility(barsVisible && !state.channels.isEmpty() ? View.VISIBLE : View.GONE);
        updateReadings(state);
    }

    private void showChartMode(boolean showBars) {
        if (barsVisible == showBars) return;
        barsVisible = showBars;
        applyChartMode();
        render();
    }

    private void applyChartMode() {
        styleButton(barsToggle, barsVisible);
        styleButton(lineToggle, !barsVisible);
        barsToggle.setSelected(barsVisible);
        lineToggle.setSelected(!barsVisible);
        chart.setVisibility(barsVisible ? View.GONE : View.VISIBLE);
        chartValue.setVisibility(barsVisible ? View.GONE : View.VISIBLE);
        bars.setVisibility(barsVisible ? View.VISIBLE : View.GONE);
        if (!barsVisible && rotatingBars) {
            rotatingBars = false;
            bars.setRotating(false);
            set(rotateBars, "Rotiraj");
        }
        barLegend.setVisibility(barsVisible && barLegend.length() > 0 ? View.VISIBLE : View.GONE);
        barDetail.setVisibility(barsVisible && barDetail.length() > 0 ? View.VISIBLE : View.GONE);
        set(chartHint, getString(barsVisible ? R.string.bar_hint : R.string.chart_gesture));
    }

    private void updateReadings(Q5RoadService.State state) {
        if (chartChannels != state.channels) {
            chartChannels = state.channels;
            List<RoadBarGrid.Group> groups = new ArrayList<>();
            for (RoadBarGrid.Group group : RoadBarGrid.Group.values()) {
                if (!group.supported(chartChannels).isEmpty()) groups.add(group);
            }
            barGroups = groups;
        }
        String[] values = state.sample == null ? null : state.sample.values;
        if (barsVisible) updateBars(state);
        else updateLine(state, values);
        livePanel.setVisibility(chartChannels.isEmpty() ? View.GONE : View.VISIBLE);
        for (int i = 0; i < allChannels.length; i++) {
            AudiQ5.Channel channel = allChannels[i];
            set(readings[i], channel.display(values == null ? null : values[i]));
            readings[i].setTextColor(chartChannels.contains(channel) ? INK : SUB);
        }
    }

    private void updateBars(Q5RoadService.State state) {
        enable(channelPicker, !barGroups.isEmpty());
        if (!barGroups.isEmpty() && !barGroups.contains(barGroup)) barGroup = barGroups.get(0);
        set(channelPicker, barGroups.isEmpty() ? getString(R.string.bar_group_choose) : barGroup.label + "  ▾");
        bars.update(barGroup, chartChannels, state.history);
        List<String> legend = new ArrayList<>();
        for (AudiQ5.Channel channel : barGroup.supported(chartChannels)) {
            legend.add(barGroup.abbreviation(channel) + " · " + channel.label);
        }
        set(barLegend, String.join("  /  ", legend));
        barLegend.setVisibility(legend.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void updateLine(Q5RoadService.State state, String[] values) {
        enable(channelPicker, !chartChannels.isEmpty());
        if (!chartChannels.isEmpty() && !chartChannels.contains(selected)) selected = chartChannels.get(0);
        set(channelPicker, chartChannels.isEmpty() ? getString(R.string.chart_choose) : selected.label + "  ▾");
        set(chartValue, selected.display(values == null ? null : values[selected.ordinal()]));
        chart.update(selected, state.history);
    }

    private static void enable(Button button, boolean enabled) {
        button.setEnabled(enabled);
        button.setAlpha(enabled ? 1f : .55f);
    }

    private static void set(TextView view, String text) {
        if (!TextUtils.equals(view.getText(), text)) view.setText(text);
    }

    private LinearLayout metric(int index, String name) {
        LinearLayout box = column();
        box.addView(text(name, 13, SUB, false));
        readings[index] = text("—", 19, INK, true);
        box.addView(readings[index]);
        return box;
    }

    private LinearLayout card(LinearLayout page) {
        LinearLayout box = column();
        int p = dp(14);
        box.setPadding(p, p, p, p);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(PANEL);
        bg.setStroke(dp(1), OUTLINE);
        bg.setCornerRadius(dp(17));
        box.setBackground(bg);
        page.addView(box);
        return box;
    }

    private void pair(LinearLayout column, View a, View b) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(0, -2, 1);
        left.setMarginEnd(dp(8));
        row.addView(a, left);
        row.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        column.addView(row);
    }

    private Button button(String name, boolean primary, Runnable action) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(name);
        button.setTextSize(14);
        button.setMinimumHeight(dp(48));
        button.setPadding(dp(10), dp(8), dp(10), dp(8));
        styleButton(button, primary);
        button.setOnClickListener(view -> action.run());
        return button;
    }

    private void styleButton(Button button, boolean primary) {
        button.setTextColor(primary ? BG : INK);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(primary ? ACCENT : 0xFF152C43);
        bg.setStroke(dp(1), primary ? ACCENT : OUTLINE);
        bg.setCornerRadius(dp(10));
        button.setBackgroundTintList(null);
        button.setBackground(new RippleDrawable(ColorStateList.valueOf(0x338CCEF4), bg, null));
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return text;
    }

    private LinearLayout column() {
        LinearLayout result = new LinearLayout(this);
        result.setOrientation(LinearLayout.VERTICAL);
        return result;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private void gap(LinearLayout parent, int size) {
        parent.addView(new View(this), new LinearLayout.LayoutParams(-1, dp(size)));
    }
}
