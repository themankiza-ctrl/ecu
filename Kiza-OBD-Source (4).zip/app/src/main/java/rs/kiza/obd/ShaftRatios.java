package rs.kiza.obd;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class ShaftRatios {
    static final long MAX_GAP_MS = 2500;

    static final class Sample {
        final int gear;
        final long time;
        final double output;
        final double value;
        final long segment;

        Sample(int gear, long time, double output, double value, long segment) {
            this.gear = gear;
            this.time = time;
            this.output = output;
            this.value = value;
            this.segment = segment;
        }
    }

    final List<Sample> samples = new ArrayList<>();
    final int[] counts = new int[8];
    final double[] baseline = new double[8];
    final double[] noise = new double[8];

    ShaftRatios(RoadRecording road) {
        if (!AudiQ5.identifiesDl501(road.identity)) return;
        List<List<Double>> groups = new ArrayList<>();
        for (int i = 0; i < 8; i++) groups.add(new ArrayList<>());
        int lastGear = 0;
        long last = -MAX_GAP_MS;
        long stable = 0;
        for (RoadRecording.Row row : road.rows) {
            int gear = (int) row.get(AudiQ5.Channel.GEAR);
            if (gear != lastGear || row.time - last > MAX_GAP_MS) stable = row.time;
            lastGear = gear;
            last = row.time;
            double input = row.get(AudiQ5.Channel.INPUT);
            double output = row.get(AudiQ5.Channel.OUTPUT);
            if (gear <= 0 || row.time - stable < 1200 || row.latency > 1500 || !(input >= 500 && output >= 200)) continue;
            double ratio = input / output;
            samples.add(new Sample(gear, row.time, output, ratio, stable));
            groups.get(gear).add(ratio);
        }
        for (int gear = 1; gear <= 7; gear++) {
            List<Double> data = groups.get(gear);
            counts[gear] = data.size();
            if (data.size() < 20) continue;
            double center = median(data);
            List<Double> deviations = new ArrayList<>(data.size());
            for (double point : data) deviations.add(Math.abs(point - center) / center);
            double spread = median(deviations);
            if (spread <= .08) {
                baseline[gear] = center;
                noise[gear] = spread;
            }
        }
    }

    double offset(Sample sample) {
        double center = baseline[sample.gear];
        return center == 0 ? Double.NaN : Math.abs(sample.value - center) / center;
    }

    private static double median(List<Double> data) {
        Collections.sort(data);
        return (data.get((data.size() - 1) / 2) + data.get(data.size() / 2)) / 2;
    }
}
