package rs.kiza.obd;

import java.io.BufferedInputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

final class ElmConnection implements Closeable, Obd.Link {
    interface Transport extends Closeable {
        void connect() throws IOException;
        InputStream input() throws IOException;
        OutputStream output() throws IOException;
    }

    private interface Operation<T> {
        T run() throws IOException;
    }

    private final Transport transport;
    private final ScheduledExecutorService timer;
    private final AtomicBoolean closed = new AtomicBoolean();
    private InputStream input;
    private OutputStream output;

    ElmConnection(Transport transport, ScheduledExecutorService timer) {
        this.transport = transport;
        this.timer = timer;
    }

    void connect() throws IOException {
        withTimeout(18000, "Adapter nije uspostavio vezu na vreme.", () -> {
            transport.connect();
            input = new BufferedInputStream(transport.input());
            output = transport.output();
            return null;
        });
    }

    @Override
    public String command(String command, int timeoutMillis) throws IOException {
        return withTimeout(timeoutMillis, "Adapter više ne odgovara na komandu " + command + ".", () -> {
            output.write((command + "\r").getBytes(StandardCharsets.US_ASCII));
            output.flush();

            StringBuilder reply = new StringBuilder();
            for (int i = 0; i < 32768; i++) {
                int next = input.read();
                if (next == '>') return reply.toString();
                if (next == -1) throw new AdapterException("Adapter je prekinuo vezu.");
                if (next != 0) reply.append((char) next);
            }
            throw new AdapterException("Adapter je poslao predugačak odgovor.");
        });
    }

    private <T> T withTimeout(int timeoutMillis, String timeoutMessage, Operation<T> operation)
            throws IOException {
        if (closed.get()) throw new AdapterException("Adapter nije povezan.");
        AtomicBoolean finished = new AtomicBoolean();
        ScheduledFuture<?> deadline = timer.schedule(() -> {
            if (finished.compareAndSet(false, true)) close();
        }, timeoutMillis, TimeUnit.MILLISECONDS);
        try {
            return operation.run();
        } finally {
            boolean completedInTime = finished.compareAndSet(false, true);
            deadline.cancel(false);
            if (!completedInTime) throw new AdapterException.Timeout(timeoutMessage);
        }
    }

    @Override
    public void close() {
        if (!closed.compareAndSet(false, true)) return;
        try {
            transport.close();
        } catch (IOException ignored) {
            // The operation that initiated closure will report its own connection error.
        }
    }
}
