package rs.kiza.obd;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class AudiQ5 {
    private static final int TIMEOUT = 4500;

    enum Channel {
        GEAR(0x210F, 1, "gear", "Stepen prenosa", "", false),
        ATF(0x2104, 1, "atf_c", "Temperatura ulja", "°C", true),
        INPUT(0x2102, 2, "trans_input_rpm", "Ulazno vratilo", "o/min", false),
        OUTPUT(0x2103, 2, "trans_output_rpm", "Izlazno vratilo", "o/min", false),
        CLUTCH_1(0x102B, 1, "clutch_1_c", "Temperatura kvačila 1", "°C", true),
        CLUTCH_2(0x102C, 1, "clutch_2_c", "Temperatura kvačila 2", "°C", true),
        MODULE_TEMP(0x0301, 1, "tcm_c", "Temperatura kontrolera", "°C", true),
        CLUTCH_1_ADAPT(0x10C9, 2, "clutch_1_adapt_ok", "Uspešne adaptacije kvačila 1", "", true),
        CLUTCH_2_ADAPT(0x10EA, 2, "clutch_2_adapt_ok", "Uspešne adaptacije kvačila 2", "", true),
        CLUTCH_2_ADAPT_FAILED(0x10ED, 2, "clutch_2_adapt_failed", "Neuspešne adaptacije kvačila 2", "", true);

        final int did;
        final int length;
        final String column;
        final String label;
        final String unit;
        final boolean slow;
        final String request;

        Channel(int did, int length, String column, String label, String unit, boolean slow) {
            this.did = did;
            this.length = length;
            this.column = column;
            this.label = label;
            this.unit = unit;
            this.slow = slow;
            this.request = String.format(Locale.US, "22%04X1", did);
        }

        String value(String reply) {
            int[] data = did(reply, did);
            if (data == null || data.length != length + 3) return "";
            switch (this) {
                case GEAR:
                    int gear = data[3];
                    if (gear == 1) return "R";
                    return gear >= 3 && gear <= 9 ? Integer.toString(gear - 2) : "";
                case MODULE_TEMP:
                case ATF: return Integer.toString(data[3] - 40);
                case INPUT:
                case OUTPUT:
                    return String.format(Locale.US, "%.2f", ((data[3] << 8) | data[4]) / 4.0);
                case CLUTCH_1_ADAPT:
                case CLUTCH_2_ADAPT: return counter((data[4] << 8) | data[3]);
                case CLUTCH_2_ADAPT_FAILED: return counter((data[3] << 8) | data[4]);
                default: return data[3] == 255 ? "" : Integer.toString(data[3]);
            }
        }

        boolean responds(String reply) {
            int[] data = did(reply, did);
            if (data == null || data.length != length + 3) return false;
            switch (this) {
                case CLUTCH_1_ADAPT:
                case CLUTCH_2_ADAPT:
                case CLUTCH_2_ADAPT_FAILED:
                    return data[3] != 0xFF || data[4] != 0xFF;
                default: return true;
            }
        }

        private static String counter(int raw) {
            return raw == 0xFFFF ? "" : Integer.toString(raw);
        }

        String display(String value) {
            if (value == null || value.isEmpty()) return "—";
            return value.replace('.', ',') + (unit.isEmpty() ? "" : " " + unit);
        }
    }

    enum ScanStatus { OK, UNSUPPORTED, PARTIAL, NO_RESPONSE, UNKNOWN }

    static final class FaultReport {
        final String message;
        final String codes;
        final ScanStatus status;

        FaultReport(String message, String codes, ScanStatus status) {
            this.message = message;
            this.codes = codes;
            this.status = status;
        }
    }

    static final class Sample {
        final String[] values;

        Sample(String[] values) { this.values = values; }

        Sample over(Sample previous) {
            if (previous == null) return this;
            String[] merged = previous.values.clone();
            for (int i = 0; i < values.length; i++) {
                if (values[i] != null) merged[i] = values[i];
            }
            return new Sample(merged);
        }
    }

    static final class Session {
        final Obd.Link link;
        final List<Channel> supported = new ArrayList<>();
        String module = "";
        String part = "";
        String hardware = "";
        String softwareVersion = "";
        boolean isDl501;
        boolean tcmResponded;
        FaultReport faults = new FaultReport("Očitavanje grešaka menjača još nije obavljeno.", "", ScanStatus.UNKNOWN);

        Session(Obd.Link link) { this.link = link; }

        void initialize() throws IOException {
            int protocol = Obd.detectProtocol(link);
            if (protocol != 6 && protocol != 8) {
                throw new AdapterException("Nije prepoznat kompatibilan CAN protokol. Uključi kontakt i pokušaj ponovo.");
            }
            for (String command : new String[]{"ATCAF1", "ATCFC1", "ATSH7E1", "ATCRA7E9"}) {
                Obd.requireOk(link, command, TIMEOUT);
            }

            part = identification("22F187", 0xF187);
            module = identification("22F19E", 0xF19E);
            if (module.isEmpty()) module = identification("22F197", 0xF197);
            hardware = identification("22F191", 0xF191);
            softwareVersion = identification("22F189", 0xF189);

            isDl501 = identifiesDl501(part + " " + module + " " + hardware);
            scan();
            if (isDl501) {
                for (Channel channel : Channel.values()) {
                    if (channel.responds(link.command(channel.request, TIMEOUT))) supported.add(channel);
                }
            }
        }

        private String identification(String request, int did) throws IOException {
            String reply = link.command(request, TIMEOUT);
            tcmResponded |= udsResponded(reply, 0x22);
            return ascii(AudiQ5.did(reply, did));
        }

        void scan() throws IOException {
            String reply = link.command("1902FF", 9000);
            tcmResponded |= udsResponded(reply, 0x19);
            faults = decodeFaults(reply);
            if (isDl501) {
                faults = new FaultReport(explainDl501(faults.message), faults.codes, faults.status);
            }
        }

        Sample sample(boolean includeSlow) throws IOException {
            String[] values = new String[Channel.values().length];
            for (Channel channel : supported) {
                if (!channel.slow || includeSlow) {
                    values[channel.ordinal()] = channel.value(link.command(channel.request, TIMEOUT));
                }
            }
            return new Sample(values);
        }
    }

    static boolean identifiesDl501(String identity) {
        String key = identity.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
        return key.contains("0B5") || key.contains("DL501");
    }

    private static int[] did(String reply, int did) {
        for (int[] frame : Obd.payloads(reply)) {
            if (frame.length >= 3 && frame[0] == 0x62
                    && ((frame[1] << 8) | frame[2]) == did) return frame;
        }
        return null;
    }

    private static String ascii(int[] frame) {
        if (frame == null) return "";
        StringBuilder result = new StringBuilder();
        for (int i = 3; i < frame.length; i++) {
            int value = frame[i];
            if (value >= 32 && value < 127) result.append((char) value);
            else result.append(' ');
        }
        return result.toString().trim().replaceAll("\\s+", " ");
    }

    private static boolean udsResponded(String reply, int request) {
        for (int[] data : Obd.payloads(reply)) {
            if (data[0] == request + 0x40 || (data.length >= 3 && data[0] == 0x7F && data[1] == request)) {
                return true;
            }
        }
        return false;
    }

    static FaultReport decodeFaults(String reply) {
        boolean partial = false;
        List<String> codes = new ArrayList<>();
        List<String> descriptions = new ArrayList<>();
        for (int[] frame : Obd.payloads(reply)) {
            if (frame.length < 2) continue;
            if (frame[0] == 0x7F && frame[1] == 0x19 && frame.length >= 3) {
                partial = true;
                continue;
            }
            if (frame[0] != 0x59 || frame[1] != 0x02) continue;
            if (frame.length < 3 || (frame.length - 3) % 4 != 0) {
                partial = true;
                continue;
            }
            for (int i = 3; i < frame.length; i += 4) {
                int a = frame[i];
                int status = frame[i + 3];
                String code = String.format(Locale.US, "%c%01X%01X%02X%02X",
                    "PCBU".charAt(a >> 6), (a >> 4) & 3, a & 15, frame[i + 1], frame[i + 2]);
                String hexStatus = String.format(Locale.US, "%02X", status);
                codes.add(code + ":" + hexStatus);
                List<String> statuses = new ArrayList<>();
                if ((status & 1) != 0) statuses.add("trenutno prisutna");
                if ((status & 4) != 0) statuses.add("na čekanju");
                if ((status & 8) != 0) statuses.add("potvrđena");
                descriptions.add(code + " · " + (statuses.isEmpty() ? "status 0x" + hexStatus : String.join(", ", statuses)));
            }
            if (frame[2] == 0) return new FaultReport("Upravljačka jedinica menjača nije prijavila podržane statuse grešaka.", "", ScanStatus.UNSUPPORTED);
            if (codes.isEmpty()) return new FaultReport("Upravljačka jedinica menjača nije prijavila kodove grešaka.", "", ScanStatus.OK);
            return new FaultReport(String.join("\n", descriptions), String.join("|", codes), ScanStatus.OK);
        }
        return new FaultReport(partial ? "Upravljačka jedinica menjača nije završila očitavanje grešaka."
            : "Nema odgovora na zahtev za očitavanje grešaka menjača.", "",
            partial ? ScanStatus.PARTIAL : ScanStatus.NO_RESPONSE);
    }

    private static String explainDl501(String report) {
        return report
            .replace("P17CF00 ·", "P17CF00 · Prekomerno proklizavanje kvačila 1 ·")
            .replace("P17D000 ·", "P17D000 · Prekomerno proklizavanje kvačila 2 ·")
            .replace("P17D800 ·", "P17D800 · Obrtni moment je ograničen zbog temperature kvačila ·");
    }

    private AudiQ5() {}
}
