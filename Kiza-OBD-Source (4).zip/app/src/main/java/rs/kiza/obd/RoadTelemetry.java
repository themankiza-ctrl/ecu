package rs.kiza.obd;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.function.ToLongFunction;

final class RoadTelemetry {
    private static final int MAX_BINS = 320;
    private static final int MAP_COLUMNS = 8;
    private static final long SLOW_GAP_MS = 7000;
    private static final AudiQ5.Channel[] CHART_CHANNELS = {
        AudiQ5.Channel.ATF, AudiQ5.Channel.CLUTCH_1, AudiQ5.Channel.CLUTCH_2, AudiQ5.Channel.MODULE_TEMP,
        AudiQ5.Channel.INPUT, AudiQ5.Channel.OUTPUT, AudiQ5.Channel.GEAR
    };

    static final class Point {
        final long time;
        final Double value;

        Point(long time, Double value) {
            this.time = time;
            this.value = value;
        }
    }

    static final class Track {
        final AudiQ5.Channel channel;
        final List<Point> points = new ArrayList<>();

        Track(AudiQ5.Channel channel) { this.channel = channel; }

        int lane() {
            if (channel == AudiQ5.Channel.GEAR) return 2;
            if (channel == AudiQ5.Channel.INPUT || channel == AudiQ5.Channel.OUTPUT) return 1;
            return 0;
        }

        long maxGap() { return channel.slow ? SLOW_GAP_MS : ShaftRatios.MAX_GAP_MS; }

        Point at(long time) {
            int i = upperBound(points, time, point -> point.time) - 1;
            return i >= 0 && time - points.get(i).time <= maxGap() ? points.get(i) : null;
        }

        List<Point> plot(long from, long to) {
            List<Point> result = new ArrayList<>();
            int start = upperBound(points, from - 1, point -> point.time);
            long width = Math.max(1, (to - from + MAX_BINS) / MAX_BINS);
            long lastTime = start > 0 ? points.get(start - 1).time : -1;
            long bucket = -1;
            Point first = null;
            Point last = null;
            Point min = null;
            Point max = null;
            int gapBin = -1;
            for (int i = start; i < points.size() && points.get(i).time <= to; i++) {
                Point point = points.get(i);
                int next = (int) ((point.time - from) / width);
                boolean gap = lastTime >= 0 && point.time - lastTime > maxGap();
                if (bucket != next || (gap && gapBin != next)) {
                    if (first != null) appendExtrema(result, first, last, min, max);
                    first = last = min = max = point;
                    bucket = next;
                    if (gap) {
                        result.add(new Point(Math.max(from, lastTime + 1), null));
                        gapBin = next;
                    }
                } else {
                    if (point.value < min.value) min = point;
                    if (point.value > max.value) max = point;
                    last = point;
                }
                lastTime = point.time;
            }
            if (first != null) appendExtrema(result, first, last, min, max);
            return result;
        }

        private static void appendExtrema(List<Point> result, Point first, Point last, Point min, Point max) {
            result.add(first);
            Point earlier = min.time <= max.time ? min : max;
            Point later = earlier == min ? max : min;
            if (earlier != first && earlier != last) result.add(earlier);
            if (later != earlier && later != first && later != last) result.add(later);
            if (last != first) result.add(last);
        }
    }

    static final class Shift {
        final long time;
        final int from;
        final int to;

        Shift(long time, int from, int to) {
            this.time = time;
            this.from = from;
            this.to = to;
        }

        String label() { return gear(from) + " → " + gear(to); }
    }

    static final class Cell {
        final int column;
        final int gear;
        int count;
        double sum;
        double peak = Double.NEGATIVE_INFINITY;
        long time;

        Cell(int column, int gear) {
            this.column = column;
            this.gear = gear;
        }

        void add(double value, long time) {
            count++;
            sum += value;
            if (value > peak) {
                peak = value;
                this.time = time;
            }
        }

        double mean() { return sum / count; }
    }

    static final class MapData {
        final List<String> labels = new ArrayList<>();
        final List<Cell> cells = new ArrayList<>();

        MapData(int width) {
            for (int i = 0; i < MAP_COLUMNS; i++) {
                labels.add(i * width + "–" + ((i + 1) * width - 1));
            }
        }
    }

    final long duration;
    final List<Track> tracks = new ArrayList<>();
    final List<Shift> shifts = new ArrayList<>();
    final MapData ratios;
    final MapData temperatures;
    private final ShaftRatios profile;
    private final List<ShaftRatios.Sample> ratioPoints = new ArrayList<>();

    RoadTelemetry(RoadRecording road, ShaftRatios profile) {
        this.profile = profile;
        duration = road.duration;
        double maxOutput = 0;
        for (AudiQ5.Channel channel : CHART_CHANNELS) {
            if (!road.channels.contains(channel)) continue;
            Track track = new Track(channel);
            for (RoadRecording.Row row : road.rows) {
                double value = row.get(channel);
                if (!Double.isFinite(value)) continue;
                track.points.add(new Point(row.time, value));
                if (channel == AudiQ5.Channel.OUTPUT) maxOutput = Math.max(maxOutput, value);
            }
            tracks.add(track);
        }
        Track gears = track(AudiQ5.Channel.GEAR);
        if (gears != null) {
            Point previous = null;
            for (Point reading : gears.points) {
                if (previous != null && reading.time - previous.time <= gears.maxGap()
                    && !reading.value.equals(previous.value)) {
                    shifts.add(new Shift(reading.time, previous.value.intValue(), reading.value.intValue()));
                }
                previous = reading;
            }
        }

        int width = 250 * Math.max(1, (int) Math.ceil((maxOutput + 1) / (MAP_COLUMNS * 250)));
        ratios = new MapData(width);
        temperatures = new MapData(width);
        Cell[][] ratioCells = new Cell[MAP_COLUMNS][8];
        Cell[][] temperatureCells = new Cell[MAP_COLUMNS][8];
        for (ShaftRatios.Sample sample : profile.samples) {
            double offset = profile.offset(sample);
            if (!Double.isFinite(offset)) continue;
            ratioPoints.add(sample);
            cell(ratios, ratioCells, width, sample.gear, sample.output).add(100 * offset, sample.time);
        }
        for (RoadRecording.Row row : road.rows) {
            int gear = (int) row.get(AudiQ5.Channel.GEAR);
            double rpm = row.get(AudiQ5.Channel.OUTPUT);
            double temp = row.get(AudiQ5.Channel.ATF);
            if (gear < 1 || !Double.isFinite(rpm) || !Double.isFinite(temp)) continue;
            cell(temperatures, temperatureCells, width, gear, rpm).add(temp, row.time);
        }
    }

    Track track(AudiQ5.Channel channel) {
        for (Track track : tracks) if (track.channel == channel) return track;
        return null;
    }

    String measure(AudiQ5.Channel channel, long time) {
        Track track = track(channel);
        Point point = track == null ? null : track.at(time);
        if (point == null) return "—";
        if (channel == AudiQ5.Channel.GEAR) return gear(point.value.intValue());
        return number(point.value) + " " + channel.unit;
    }

    String deviation(long time) {
        int i = upperBound(ratioPoints, time, sample -> sample.time) - 1;
        if (i < 0) return "—";
        ShaftRatios.Sample sample = ratioPoints.get(i);
        Track gearTrack = track(AudiQ5.Channel.GEAR);
        Point reading = gearTrack == null ? null : gearTrack.at(time);
        int shift = upperBound(shifts, time, item -> item.time) - 1;
        if (reading == null || reading.value.intValue() != sample.gear || time - sample.time > ShaftRatios.MAX_GAP_MS
            || shift >= 0 && shifts.get(shift).time > sample.time) return "—";
        return number(100 * profile.offset(sample)) + " %";
    }

    List<Shift> visibleShifts(long from, long to) {
        int left = upperBound(shifts, from - 1, shift -> shift.time);
        int right = upperBound(shifts, to, shift -> shift.time);
        return left >= right ? Collections.emptyList() : shifts.subList(left, right);
    }

    private static Cell cell(MapData map, Cell[][] index, int width, int gear, double rpm) {
        int column = Math.min(MAP_COLUMNS - 1, (int) rpm / width);
        Cell previous = index[column][gear];
        if (previous != null) return previous;
        Cell created = new Cell(column, gear);
        index[column][gear] = created;
        map.cells.add(created);
        return created;
    }

    private static <T> int upperBound(List<T> list, long time, ToLongFunction<T> timestamp) {
        int low = 0;
        int high = list.size();
        while (low < high) {
            int mid = (low + high) >>> 1;
            if (timestamp.applyAsLong(list.get(mid)) <= time) low = mid + 1;
            else high = mid;
        }
        return low;
    }

    static String gear(int value) { return value == -1 ? "R" : Integer.toString(value); }

    static String number(double value) {
        double rounded = Math.rint(value * 10) / 10;
        if (rounded == 0) return "0";
        String format = Math.rint(rounded) == rounded ? "%.0f" : "%.1f";
        return String.format(Locale.ROOT, format, rounded).replace('.', ',');
    }
}
