package rs.kiza.obd;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class Obd {
    interface Link {
        String command(String command, int timeoutMillis) throws IOException;
    }

    static int detectProtocol(Link link) throws IOException {
        String banner = link.command("ATZ", 5000).trim();
        if (banner.isEmpty() || banner.equals("?")) {
            throw new AdapterException("Adapter nije prihvatio komandu za resetovanje ELM327.");
        }
        for (String command : Arrays.asList("ATE0", "ATL0", "ATS1", "ATH0", "ATSP0")) {
            requireOk(link, command, 3000);
        }

        // ELM327 uses this read-only OBD request to discover the CAN protocol.
        link.command("0100", 26000);
        String number = link.command("ATDPN", 3500).trim().toUpperCase(Locale.ROOT);
        if (number.matches("A?[1-9A-C]")) {
            return Character.digit(number.charAt(number.length() - 1), 16);
        }
        return -1;
    }

    static void requireOk(Link link, String command, int timeout) throws IOException {
        if (!link.command(command, timeout).trim().endsWith("OK")) {
            throw new AdapterException("Adapter je odbio komandu " + command + ".");
        }
    }

    private static final Pattern FRAME = Pattern.compile("^([0-9A-F]+):\\s*(.*)$");
    private static final Pattern PROGRESS = Pattern.compile("^(?:(?:SEARCHING\\.{3}|BUS INIT:\\s*(?:OK)?|BUS INIT\\.{3})\\s*)+");

    static List<int[]> payloads(String reply) {
        List<int[]> results = new ArrayList<>();
        StringBuilder aggregate = new StringBuilder();
        int expectedLength = -1;
        int nextFrame = 0;
        for (String raw : reply.toUpperCase(Locale.ROOT).split("[\\r\\n>]+")) {
            String row = PROGRESS.matcher(raw.trim()).replaceFirst("").trim();
            Matcher frame = FRAME.matcher(row);
            if (frame.matches()) {
                String data = frame.group(2).replaceAll("\\s+", "");
                if (expectedLength < 0 || frame.group(1).length() != 1
                        || Character.digit(frame.group(1).charAt(0), 16) != nextFrame
                        || !data.matches("(?:[0-9A-F]{2})+")) {
                    expectedLength = -1;
                    continue;
                }
                aggregate.append(data);
                nextFrame = (nextFrame + 1) & 0x0F;
                if (aggregate.length() >= expectedLength * 2) {
                    results.add(hexBytes(aggregate.substring(0, expectedLength * 2)));
                    expectedLength = -1;
                }
                continue;
            }

            String compact = row.replaceAll("\\s+", "");
            if (compact.matches("[0-9A-F]{3}")) {
                expectedLength = Integer.parseInt(compact, 16);
                aggregate.setLength(0);
                nextFrame = 0;
            } else if (compact.matches("(?:[0-9A-F]{2})+")) {
                expectedLength = -1;
                results.add(hexBytes(compact));
            }
        }
        return results;
    }

    private static int[] hexBytes(String data) {
        int[] bytes = new int[data.length() / 2];
        for (int i = 0; i < bytes.length; i++) {
            bytes[i] = Integer.parseInt(data.substring(i * 2, i * 2 + 2), 16);
        }
        return bytes;
    }

    private Obd() {}
}
