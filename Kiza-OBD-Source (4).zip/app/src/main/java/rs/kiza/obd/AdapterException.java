package rs.kiza.obd;

import java.io.IOException;
import java.net.SocketTimeoutException;

class AdapterException extends IOException {
    private static final long serialVersionUID = 1L;

    AdapterException(String message) {
        super(message);
    }

    AdapterException(String message, Throwable cause) {
        super(message, cause);
    }

    static String displayMessage(Exception error) {
        return error instanceof AdapterException || error instanceof Timeout
            ? error.getMessage() : null;
    }

    static final class Timeout extends SocketTimeoutException {
        private static final long serialVersionUID = 1L;

        Timeout(String message) {
            super(message);
        }
    }
}
