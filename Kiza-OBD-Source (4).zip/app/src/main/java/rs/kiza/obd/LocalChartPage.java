package rs.kiza.obd;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Collections;

class LocalChartPage extends WebViewClient {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String ASSETS = "/assets/obd-chart/";
    private static final String COLOR = "#101d2f";

    static String url(String file) { return "https://" + HOST + ASSETS + file; }

    static boolean hosts(Uri uri) {
        return "https".equals(uri.getScheme()) && HOST.equals(uri.getAuthority());
    }

    @SuppressLint("SetJavaScriptEnabled")
    static WebView create(Context context) {
        WebView view = new WebView(context);
        view.setBackgroundColor(android.graphics.Color.parseColor(COLOR));
        view.getSettings().setJavaScriptEnabled(true);
        view.getSettings().setAllowFileAccess(false);
        view.getSettings().setAllowContentAccess(false);
        view.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        view.getSettings().setSupportMultipleWindows(false);
        view.getSettings().setMediaPlaybackRequiresUserGesture(true);
        view.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        view.setOnTouchListener((chart, event) -> {
            if (chart.getParent() != null) chart.getParent().requestDisallowInterceptTouchEvent(true);
            return false;
        });
        return view;
    }

    @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        Uri url = request.getUrl();
        String path = url.getPath();
        if (!hosts(url) || path == null || !path.startsWith(ASSETS)) return blocked();
        String file = path.substring(ASSETS.length());
        String mime;
        switch (file) {
            case "chart.html":
            case "telemetry.html": mime = "text/html"; break;
            case "chart.css":
            case "telemetry.css": mime = "text/css"; break;
            case "chart.js":
            case "echarts.min.js":
            case "echarts-gl.min.js":
            case "telemetry-options.js":
            case "telemetry.js": mime = "text/javascript"; break;
            default: return blocked();
        }
        try {
            return new WebResourceResponse(mime, "UTF-8", view.getContext().getAssets().open("obd-chart/" + file));
        } catch (IOException error) {
            return blocked();
        }
    }

    @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return true; }

    private static WebResourceResponse blocked() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked",
            Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
    }
}
