package rs.kiza.obd;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public final class Q5RoadService extends Service {
    static final String OPEN = "rs.kiza.obd.OPEN_Q5";
    private static final String STOP = "rs.kiza.obd.STOP_Q5";
    private static final String CHANNEL = "q5_road_log";
    private static final int NOTIFICATION = 25;
    private static final long MAX_RECORDING_MS = TimeUnit.HOURS.toMillis(2);

    static final class State {
        final boolean connected;
        final boolean waiting;
        final boolean recording;
        final boolean demo;
        final String status;
        final String identity;
        final String coverage;
        final String faultText;
        final AudiQ5.Sample sample;
        final List<AudiQ5.Channel> channels;
        final List<RoadChartHistory.Point> history;
        final int rows;

        State(boolean connected, boolean waiting, boolean recording, boolean demo,
                String status, String identity, String coverage, String faultText,
                AudiQ5.Sample sample, List<AudiQ5.Channel> channels,
                List<RoadChartHistory.Point> history, int rows) {
            this.connected = connected;
            this.waiting = waiting;
            this.recording = recording;
            this.demo = demo;
            this.status = status;
            this.identity = identity;
            this.coverage = coverage;
            this.faultText = faultText;
            this.sample = sample;
            this.channels = channels;
            this.history = history;
            this.rows = rows;
        }

        static State idle(String status) {
            return new State(false, false, false, false, status, "", "", "", null,
                Collections.emptyList(), Collections.emptyList(), 0);
        }
    }

    private static final class Run {
        final boolean demo;
        volatile ElmConnection connection;
        volatile boolean cancelled;
        AudiQ5.Session session;
        AudiQ5.Sample sample;
        List<AudiQ5.Channel> channels = Collections.emptyList();
        final RoadChartHistory chart = new RoadChartHistory();
        List<RoadChartHistory.Point> history = Collections.emptyList();
        long nextSlowSample;
        boolean hasFastChannels;
        ScheduledFuture<?> polling;
        RoadLog log;
        long started;
        int rows;
        String status;

        Run(boolean demo, String status) {
            this.demo = demo;
            this.status = status;
        }
    }

    final class LocalBinder extends Binder {
        State snapshot() { return state; }
        void record() { withRun(Q5RoadService.this::startRecording); }
        void stopRecording() { withRun(Q5RoadService.this::finishRecording); }
        void disconnect() { cancelRun(); }
    }

    private interface Action { void run(Run run) throws IOException; }

    private final LocalBinder binder = new LocalBinder();
    private final ScheduledThreadPoolExecutor worker = new ScheduledThreadPoolExecutor(1);
    private final ScheduledThreadPoolExecutor timer = new ScheduledThreadPoolExecutor(1);
    private volatile State state;
    private volatile Run active;
    private volatile boolean uiBound;
    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate() {
        super.onCreate();
        state = State.idle(getString(R.string.connect_ignition_on));
        worker.setRemoveOnCancelPolicy(true);
        timer.setRemoveOnCancelPolicy(true);
        getSystemService(NotificationManager.class).createNotificationChannel(
            new NotificationChannel(CHANNEL, getString(R.string.q5_notification_channel), NotificationManager.IMPORTANCE_LOW));
    }

    @Override public IBinder onBind(Intent intent) { uiBound = true; return binder; }
    @Override public void onRebind(Intent intent) { uiBound = true; }
    @Override public boolean onUnbind(Intent intent) { uiBound = false; return true; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf(startId);
            return START_NOT_STICKY;
        }
        if (STOP.equals(intent.getAction())) {
            cancelRun();
            if (active == null) stopSelf(startId);
            return START_NOT_STICKY;
        }
        if (!OPEN.equals(intent.getAction()) || active != null) return START_NOT_STICKY;
        String type = intent.getStringExtra("type");
        boolean demo = "demo".equals(type);
        String label = demo ? getString(R.string.demo_ecu) : intent.getStringExtra("label");
        if (label == null) label = "ELM327";
        Run run = new Run(demo, getString(R.string.connecting_adapter, label));
        active = run;
        state = new State(false, true, false, demo, run.status, "", "", "", null,
            run.channels, run.history, 0);
        try {
            Notification connecting = notification(run.status);
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION, connecting, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
            } else {
                startForeground(NOTIFICATION, connecting);
            }
        } catch (SecurityException error) {
            active = null;
            state = State.idle(getString(R.string.service_start_denied));
            stopSelf(startId);
            return START_NOT_STICKY;
        }
        worker.execute(() -> open(run, intent));
        return START_NOT_STICKY;
    }

    @SuppressLint("MissingPermission")
    private void open(Run run, Intent intent) {
        try {
            if (run.cancelled) return;
            Obd.Link link = new Q5Demo();
            if (!run.demo) {
                String type = intent.getStringExtra("type");
                String address = intent.getStringExtra("address");
                ElmConnection.Transport transport;
                if ("bt".equals(type)) {
                    BluetoothDevice device = getSystemService(BluetoothManager.class).getAdapter()
                        .getRemoteDevice(address);
                    transport = AndroidAdapters.bluetooth(device);
                } else if ("wifi".equals(type)) {
                    transport = AndroidAdapters.wifi(getSystemService(ConnectivityManager.class),
                        address, intent.getIntExtra("port", 35000));
                } else {
                    throw new AdapterException(getString(R.string.choose_supported_adapter));
                }
                run.connection = new ElmConnection(transport, timer);
                if (run.cancelled) {
                    run.connection.close();
                    return;
                }
                run.connection.connect();
                link = run.connection;
            }
            AudiQ5.Session session = new AudiQ5.Session(link);
            session.initialize();
            if (run.cancelled) return;
            run.session = session;
            run.channels = Collections.unmodifiableList(new ArrayList<>(session.supported));
            if (run.demo) prepareDemoChart(run);
            run.hasFastChannels = run.channels.stream().anyMatch(channel -> !channel.slow);
            run.status = run.demo ? getString(R.string.demo_connected) : getString(R.string.adapter_connected);
            publish(run, false);
            updateNotification(run.status);
            if (!run.channels.isEmpty()) {
                run.polling = worker.scheduleWithFixedDelay(() -> poll(run), 0, 160, TimeUnit.MILLISECONDS);
            }
        } catch (IOException | SecurityException | IllegalArgumentException error) {
            finish(run, run.cancelled ? getString(R.string.adapter_disconnected) : message(error), run.cancelled ? "stop" : "connection_error");
        }
    }

    private void prepareDemoChart(Run run) throws IOException {
        long now = SystemClock.elapsedRealtime();
        for (int i = RoadBarGrid.COLUMNS - 1; i >= 0; i--) {
            AudiQ5.Sample sample = run.session.sample(true);
            run.history = run.chart.append(now - i * RoadBarGrid.BIN_MS, sample);
            run.sample = sample;
        }
    }

    private void withRun(Action action) {
        Run run = active;
        if (run == null || run.cancelled) return;
        worker.execute(() -> {
            if (active != run || run.cancelled || run.session == null) return;
            try {
                action.run(run);
                publish(run, false);
            } catch (IOException error) {
                finish(run, message(error), "log_or_connection_error");
            }
        });
    }

    private void poll(Run run) {
        if ((!uiBound && run.log == null) || run.cancelled || active != run) return;
        long start = SystemClock.elapsedRealtime();
        boolean readSlow = start >= run.nextSlowSample;
        if (!readSlow && !run.hasFastChannels) return;
        try {
            AudiQ5.Sample sample = run.session.sample(readSlow);
            long now = SystemClock.elapsedRealtime();
            if (run.cancelled) return;
            if (readSlow) run.nextSlowSample = now + 1800;
            run.sample = sample.over(run.sample);
            run.history = run.chart.append(now, sample);
            if (run.log != null) {
                run.log.sample(Instant.now(), now, now - start, sample);
                run.rows = run.log.rows;
                if (now - run.started >= MAX_RECORDING_MS) closeLog(run, "time_limit");
            }
            publish(run, false);
        } catch (IOException | SecurityException error) {
            finish(run, run.cancelled ? getString(R.string.adapter_disconnected) : message(error), run.cancelled ? "stop" : "connection_error");
        }
    }

    private void startRecording(Run run) {
        if (run.log != null || run.channels.isEmpty()) return;
        run.nextSlowSample = 0;
        run.started = SystemClock.elapsedRealtime();
        try {
            run.log = new RoadLog(logDirectory(this), run.demo, Instant.now(), run.started);
            run.log.event(Instant.now(), run.started, "start", run.session);
            acquireWakeLock();
            run.rows = 0;
            run.status = run.demo ? getString(R.string.recording_demo) : getString(R.string.recording_drive);
            updateNotification(run.status);
        } catch (IOException error) {
            try {
                closeLog(run, "file_error");
            } catch (IOException ignored) {
                // The file error is reported below.
            }
            run.status = getString(R.string.cannot_start_recording, message(error));
        }
    }

    private void closeLog(Run run, String event) throws IOException {
        if (run.log == null) return;
        try (RoadLog previous = run.log) {
            run.log = null;
            previous.event(Instant.now(), SystemClock.elapsedRealtime(), event, null);
            run.status = getString(R.string.road_log_saved);
        } finally {
            releaseWakeLock();
        }
        updateNotification(run.status);
    }

    private void finishRecording(Run run) throws IOException {
        if (run.log == null) return;
        publish(run, true);
        if (run.session.tcmResponded && !run.cancelled) {
            run.session.scan();
            run.log.event(Instant.now(), SystemClock.elapsedRealtime(), "end_scan", run.session);
        }
        closeLog(run, "stop");
    }

    private void cancelRun() {
        Run run = active;
        if (run == null) return;
        run.cancelled = true;
        ElmConnection connection = run.connection;
        if (connection != null) timer.execute(connection::close);
        worker.execute(() -> finish(run, getString(R.string.adapter_disconnected), "stop"));
    }

    private void finish(Run run, String status, String event) {
        if (active != run) return;
        if (run.polling != null) run.polling.cancel(false);
        if (run.connection != null) run.connection.close();
        try {
            closeLog(run, event);
        } catch (IOException error) {
            status += " " + message(error);
        }
        synchronized (this) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            state = new State(false, false, false, run.demo, status,
                identity(run.session), coverage(run.session), run.session == null ? "" : run.session.faults.message,
                run.sample, run.channels, run.history, run.rows);
            active = null;
        }
    }

    @Override public void onDestroy() {
        Run run = active;
        if (run != null) {
            run.cancelled = true;
            if (run.connection != null) run.connection.close();
            worker.execute(() -> finish(run, getString(R.string.adapter_disconnected), "service_closed"));
        }
        worker.shutdown();
        timer.shutdown();
        releaseWakeLock();
        super.onDestroy();
    }

    private void publish(Run run, boolean busy) {
        state = new State(run.session != null, busy, run.log != null, run.demo,
            run.status, identity(run.session), coverage(run.session),
            run.session == null ? "" : run.session.faults.message, run.sample, run.channels, run.history, run.rows);
    }

    private String identity(AudiQ5.Session session) {
        if (session == null) return "";
        if (!session.tcmResponded) return getString(R.string.no_tcm_response);
        StringBuilder result = new StringBuilder(session.isDl501 ? "0B5 / DL501 S tronic" : getString(R.string.transmission_controller));
        if (!session.part.isEmpty()) result.append('\n').append(getString(R.string.software_part, session.part));
        if (!session.hardware.isEmpty()) result.append('\n').append(getString(R.string.hardware_part, session.hardware));
        if (!session.softwareVersion.isEmpty()) result.append('\n').append(getString(R.string.software_version, session.softwareVersion));
        if (!session.module.isEmpty()) result.append("\n").append(session.module);
        return result.toString();
    }

    private String coverage(AudiQ5.Session session) {
        if (session == null) return "";
        if (!session.tcmResponded) return getString(R.string.no_transmission_channels);
        if (!session.isDl501) return getString(R.string.dl501_unconfirmed);
        if (session.supported.isEmpty()) return getString(R.string.dl501_channels_unavailable);
        return getString(R.string.q5_channel_count, session.supported.size(), AudiQ5.Channel.values().length);
    }

    static File logDirectory(android.content.Context context) {
        return new File(context.getFilesDir(), "q5-road-logs");
    }

    private synchronized void acquireWakeLock() {
        wakeLock = getSystemService(PowerManager.class)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "KizaOBD:Q5RoadLog");
        wakeLock.acquire(MAX_RECORDING_MS + 60000);
    }

    private synchronized void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        wakeLock = null;
    }

    private Notification notification(String body) {
        int flags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent open = PendingIntent.getActivity(this, 0,
            new Intent(this, Q5Activity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), flags);
        PendingIntent stop = PendingIntent.getService(this, 1,
            new Intent(this, Q5RoadService.class).setAction(STOP), flags);
        return new Notification.Builder(this, CHANNEL)
            .setContentTitle(getString(R.string.q5_notification_title)).setContentText(body)
            .setSmallIcon(android.R.drawable.ic_menu_compass).setContentIntent(open)
            .setOnlyAlertOnce(true).setOngoing(true)
            .addAction(new Notification.Action.Builder(null, getString(R.string.disconnect), stop).build()).build();
    }

    private void updateNotification(String body) {
        getSystemService(NotificationManager.class).notify(NOTIFICATION, notification(body));
    }

    private String message(Exception error) {
        if (error instanceof SecurityException) return getString(R.string.missing_adapter_permission);
        String text = AdapterException.displayMessage(error);
        if (text != null) return text;
        android.util.Log.w("KizaOBD", "Q5 diagnostics or recording failed", error);
        return getString(R.string.service_error);
    }
}
