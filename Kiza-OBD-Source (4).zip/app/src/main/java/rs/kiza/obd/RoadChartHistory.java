package rs.kiza.obd;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class RoadChartHistory {
    static final long WINDOW_MS = 60_000;
    private static final int MAX_POINTS = 400;

    static final class Point {
        final long millis;
        final AudiQ5.Sample sample;

        Point(long millis, AudiQ5.Sample sample) {
            this.millis = millis;
            this.sample = sample;
        }
    }

    private final ArrayDeque<Point> points = new ArrayDeque<>();

    List<Point> append(long now, AudiQ5.Sample sample) {
        points.addLast(new Point(now, sample));
        while (points.size() > MAX_POINTS || points.getFirst().millis < now - WINDOW_MS) {
            points.removeFirst();
        }
        return Collections.unmodifiableList(new ArrayList<>(points));
    }
}
