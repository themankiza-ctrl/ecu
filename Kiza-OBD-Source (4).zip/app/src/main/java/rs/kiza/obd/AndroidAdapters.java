package rs.kiza.obd;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.UUID;

final class AndroidAdapters {
    private static final UUID SERIAL_PORT = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

    @SuppressLint("MissingPermission")
    static ElmConnection.Transport bluetooth(BluetoothDevice device) throws IOException {
        BluetoothSocket socket = device.createRfcommSocketToServiceRecord(SERIAL_PORT);
        return new ElmConnection.Transport() {
            @Override public void connect() throws IOException { socket.connect(); }
            @Override public InputStream input() throws IOException { return socket.getInputStream(); }
            @Override public OutputStream output() throws IOException { return socket.getOutputStream(); }
            @Override public void close() throws IOException { socket.close(); }
        };
    }

    static ElmConnection.Transport wifi(ConnectivityManager manager, String host, int port)
            throws IOException {
        Network chosen = manager.getActiveNetwork();
        if (!isWifi(manager, chosen)) {
            chosen = null;
            for (Network network : manager.getAllNetworks()) {
                if (isWifi(manager, network)) {
                    chosen = network;
                    break;
                }
            }
        }
        if (chosen == null) throw new AdapterException("Prvo se poveži na Wi-Fi mrežu adaptera u podešavanjima telefona.");
        Socket socket = chosen.getSocketFactory().createSocket();
        return new ElmConnection.Transport() {
            @Override public void connect() throws IOException {
                socket.connect(new InetSocketAddress(host, port), 10000);
            }
            @Override public InputStream input() throws IOException { return socket.getInputStream(); }
            @Override public OutputStream output() throws IOException { return socket.getOutputStream(); }
            @Override public void close() throws IOException { socket.close(); }
        };
    }

    private static boolean isWifi(ConnectivityManager manager, Network network) {
        if (network == null) return false;
        NetworkCapabilities capabilities = manager.getNetworkCapabilities(network);
        return capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
    }

    private AndroidAdapters() {}
}
