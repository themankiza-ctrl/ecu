package rs.kiza.obd;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

import java.util.Collections;
import java.util.List;

final class TransmissionChart extends View {
    private static final int AXIS = 0xFF426173;
    private static final int GRID = 0x80415B70;
    private static final int TICK = 0xFFACC4D1;
    private static final int FRONT = 0xFF74F9D0;
    private static final int DEPTH = 0xBC4D8AFF;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path face = new Path();
    private final float density;
    private final ValueAnimator pulse;
    private List<RoadChartHistory.Point> points = Collections.emptyList();
    private AudiQ5.Channel channel = AudiQ5.Channel.GEAR;
    private long lastValueAt = Long.MIN_VALUE;
    private String lastValue;
    private float phase = 1;
    private float tilt = 1;
    private float startX;
    private float startTilt;

    TransmissionChart(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);
        setContentDescription(context.getString(R.string.chart_empty));
        pulse = ValueAnimator.ofFloat(0, 1);
        pulse.setDuration(380);
        pulse.addUpdateListener(animator -> {
            phase = (float) animator.getAnimatedValue();
            invalidate();
        });
    }

    void update(AudiQ5.Channel selected, List<RoadChartHistory.Point> samples) {
        if (channel == selected && points == samples) return;
        boolean changed = selected != channel;
        if (changed || samples.isEmpty()) lastValueAt = Long.MIN_VALUE;
        channel = selected;
        points = samples;
        long currentTime = Long.MIN_VALUE;
        String currentValue = null;
        for (int i = points.size() - 1; i >= 0; i--) {
            RoadChartHistory.Point point = points.get(i);
            String candidate = point.sample.values[channel.ordinal()];
            if (candidate != null) {
                currentTime = point.millis;
                currentValue = candidate;
                break;
            }
        }
        if (changed || !java.util.Objects.equals(currentValue, lastValue)) {
            String label = channel.display(currentValue);
            setContentDescription(getContext().getString(R.string.chart_accessible, channel.label, label));
        }
        lastValue = currentValue;
        if (currentTime != lastValueAt && currentValue != null && !currentValue.isEmpty()) {
            if (ValueAnimator.areAnimatorsEnabled() && isAttachedToWindow() && !pulse.isRunning()) {
                pulse.start();
            }
        }
        lastValueAt = currentTime;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float left = 47 * density;
        float top = 30 * density;
        float bottom = getHeight() - 33 * density;
        float depthX = 26 * density * tilt;
        float depthY = 17 * density;
        float right = getWidth() - 12 * density - depthX;
        if (right <= left || bottom <= top) return;
        long end = points.isEmpty() ? 0 : points.get(points.size() - 1).millis;
        long start = end - RoadChartHistory.WINDOW_MS;
        double min = Double.POSITIVE_INFINITY;
        double max = Double.NEGATIVE_INFINITY;
        for (RoadChartHistory.Point point : points) {
            if (point.millis < start) continue;
            double reading = number(point.sample.values[channel.ordinal()]);
            if (Double.isFinite(reading)) {
                min = Math.min(min, reading);
                max = Math.max(max, reading);
            }
        }
        boolean hasData = Double.isFinite(min);
        if (channel == AudiQ5.Channel.GEAR) {
            min = -1;
            max = 7;
        } else if (!hasData) {
            min = 0;
            max = 1;
        } else {
            double spread = Math.max(1, max - min);
            double step = Math.pow(10, Math.floor(Math.log10(spread)));
            min = Math.floor((min - .12 * spread) / step) * step;
            max = Math.ceil((max + .12 * spread) / step) * step;
        }

        polygon(c, 0xFF111F36, left, bottom, right, bottom, right + depthX, bottom - depthY,
            left + depthX, bottom - depthY);
        polygon(c, 0xFF112840, left, top, left + depthX, top - depthY, left + depthX, bottom - depthY,
            left, bottom);
        polygon(c, 0xFF0B192A, left + depthX, top - depthY, right + depthX, top - depthY,
            right + depthX, bottom - depthY, left + depthX, bottom - depthY);
        for (int i = 0; i <= 4; i++) {
            float y = bottom - (bottom - top) * i / 4;
            line(c, left, y, left + depthX, y - depthY, GRID, 1);
            line(c, left + depthX, y - depthY, right + depthX, y - depthY, GRID, 1);
            if (hasData) {
                double tick = min + (max - min) * i / 4;
                text(c, axisNumber(tick), left - 7 * density, y + 4 * density, Paint.Align.RIGHT);
            }
        }
        for (int i = 0; i <= 3; i++) {
            float x = left + (right - left) * i / 3;
            line(c, x, bottom, x + depthX, bottom - depthY, GRID, 1);
            line(c, x + depthX, bottom - depthY, x + depthX, top - depthY, GRID, 1);
            String label = i == 3 ? getContext().getString(R.string.chart_now) : (i * 20 - 60) + " s";
            text(c, label, x, bottom + 20 * density, i == 3 ? Paint.Align.RIGHT : Paint.Align.LEFT);
        }
        line(c, left, top, left, bottom, AXIS, 1.2f);
        line(c, left, bottom, right, bottom, AXIS, 1.2f);

        if (!hasData) {
            text(c, getContext().getString(R.string.chart_empty), (left + right) / 2,
                (top + bottom) / 2, Paint.Align.CENTER);
            return;
        }

        float priorX = 0;
        float priorY = 0;
        boolean previous = false;
        for (RoadChartHistory.Point point : points) {
            if (point.millis < start) continue;
            String value = point.sample.values[channel.ordinal()];
            if (value == null) continue;
            double numeric = number(value);
            if (!Double.isFinite(numeric)) {
                previous = false;
                continue;
            }
            float x = left + (right - left) * (point.millis - start) / RoadChartHistory.WINDOW_MS;
            float y = bottom - (float) ((numeric - min) / (max - min)) * (bottom - top);
            if (previous) {
                if (channel == AudiQ5.Channel.GEAR) {
                    ribbon(c, priorX, priorY, x, priorY, depthX, depthY);
                    ribbon(c, x, priorY, x, y, depthX, depthY);
                } else {
                    ribbon(c, priorX, priorY, x, y, depthX, depthY);
                }
            } else {
                paint.setColor(FRONT);
                c.drawCircle(x, y, 2.5f * density, paint);
            }
            priorX = x;
            priorY = y;
            previous = true;
        }
        if (previous) {
            paint.setColor(FRONT);
            c.drawCircle(priorX, priorY, 3.5f * density, paint);
            if (phase < 1) {
                paint.setColor(Color.argb((int) (130 * (1 - phase)), 116, 249, 208));
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(density);
                c.drawCircle(priorX, priorY, (5 + 10 * phase) * density, paint);
                paint.setStyle(Paint.Style.FILL);
            }
        }
    }

    private void ribbon(Canvas c, float x, float y, float x2, float y2, float dx, float dy) {
        paint.setShader(new LinearGradient(x, y, x + dx, y - dy, 0x9874F9D0, 0x244D8AFF, Shader.TileMode.CLAMP));
        polygon(c, Color.WHITE, x, y, x2, y2, x2 + dx, y2 - dy, x + dx, y - dy);
        paint.setShader(null);
        line(c, x + dx, y - dy, x2 + dx, y2 - dy, DEPTH, 1.3f);
        line(c, x, y, x2, y2, 0x3874F9D0, 7);
        line(c, x, y, x2, y2, FRONT, 2.2f);
    }

    private static double number(String value) {
        if (value == null || value.isEmpty()) return Double.NaN;
        return value.equals("R") ? -1 : Double.parseDouble(value);
    }

    private String axisNumber(double value) {
        if (channel == AudiQ5.Channel.GEAR) return value < 0 ? "R" : Integer.toString((int) value);
        if (value == Math.rint(value)) return Long.toString((long) value);
        return String.format(java.util.Locale.US, "%.1f", value).replace('.', ',');
    }

    private void polygon(Canvas c, int color, float x, float y, float x2, float y2, float x3,
                         float y3, float x4, float y4) {
        paint.setColor(color);
        face.reset();
        face.moveTo(x, y);
        face.lineTo(x2, y2);
        face.lineTo(x3, y3);
        face.lineTo(x4, y4);
        face.close();
        c.drawPath(face, paint);
    }

    private void line(Canvas c, float x, float y, float x2, float y2, int color, float width) {
        paint.setColor(color);
        paint.setStrokeWidth(width * density);
        paint.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(x, y, x2, y2, paint);
    }

    private void text(Canvas c, String s, float x, float y, Paint.Align align) {
        paint.setColor(TICK);
        paint.setTextSize(11 * getResources().getDisplayMetrics().scaledDensity);
        paint.setTextAlign(align);
        c.drawText(s, x, y, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                startX = event.getX();
                startTilt = tilt;
                return true;
            case MotionEvent.ACTION_MOVE:
                float offset = event.getX() - startX;
                if (Math.abs(offset) > 8 * density) getParent().requestDisallowInterceptTouchEvent(true);
                tilt = Math.max(.45f, Math.min(2.15f, startTilt + offset / (100 * density)));
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                if (Math.abs(event.getX() - startX) < 8 * density) performClick();
                return true;
            case MotionEvent.ACTION_CANCEL: return true;
            default: return super.onTouchEvent(event);
        }
    }

    @Override public boolean performClick() { super.performClick(); return true; }

    @Override protected void onDetachedFromWindow() {
        pulse.cancel();
        phase = 1;
        super.onDetachedFromWindow();
    }
}
