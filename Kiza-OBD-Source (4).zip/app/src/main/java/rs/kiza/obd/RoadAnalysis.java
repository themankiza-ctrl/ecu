package rs.kiza.obd;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;

final class RoadAnalysis {
    enum Level { CONTROLLER, OBSERVATION, COVERAGE }

    static final class Finding {
        final Level level;
        final String title;
        final String evidence;
        final String interpretation;
        final long time;
        final RoadBarGrid.Group group;

        Finding(Level level, String title, String evidence, String interpretation, long time, RoadBarGrid.Group group) {
            this.level = level;
            this.title = title;
            this.evidence = evidence;
            this.interpretation = interpretation;
            this.time = time;
            this.group = group;
        }
    }

    static final class Report {
        final List<Finding> findings = new ArrayList<>();
        final String summary;
        final String readings;

        Report(RoadRecording road) {
            summary = (road.demo ? "Demo · simulirani podaci\n" : "") +
                time(road.duration) + " · " + road.rows.size() + " uzoraka · " + road.channels.size() +
                "/" + AudiQ5.Channel.values().length + " kanala\n" +
                "Na početku: " + scanStatus(road.startScan) + " · Na kraju: " + scanStatus(road.endScan);
            StringBuilder summary = new StringBuilder();
            for (AudiQ5.Channel channel : road.channels) {
                double low = Double.POSITIVE_INFINITY;
                double high = Double.NEGATIVE_INFINITY;
                for (RoadRecording.Row row : road.rows) {
                    double value = row.get(channel);
                    if (!Double.isFinite(value)) continue;
                    low = Math.min(low, value);
                    high = Math.max(high, value);
                }
                String min = channel == AudiQ5.Channel.GEAR && low == -1 ? "R" : value(low);
                String max = channel == AudiQ5.Channel.GEAR && high == -1 ? "R" : value(high);
                if (summary.length() > 0) summary.append('\n');
                summary.append(channel.label).append(" · ").append(min).append("–").append(max);
                if (!channel.unit.isEmpty()) summary.append(' ').append(channel.unit);
                summary.append(" · ").append(road.counts[channel.ordinal()]).append(" očitavanja");
            }
            readings = summary.toString();
        }
    }

    private static final long SLOW_GAP_MS = 7000;
    private static final long FAST_GAP_MS = 2500;

    static Report analyze(RoadRecording road) {
        return analyze(road, new ShaftRatios(road));
    }

    static Report analyze(RoadRecording road, ShaftRatios profile) {
        Report report = new Report(road);
        boolean dl501 = AudiQ5.identifiesDl501(road.identity);
        codes(road, report, dl501);
        int before = report.findings.size();
        if (dl501) {
            temperatureRise(road, report, AudiQ5.Channel.ATF, 12);
            temperatureRise(road, report, AudiQ5.Channel.CLUTCH_1, 22);
            temperatureRise(road, report, AudiQ5.Channel.CLUTCH_2, 22);
            temperatureRise(road, report, AudiQ5.Channel.MODULE_TEMP, 15);
            clutchDifference(road, report);
            ratios(profile, report);
            gearHunting(road, report);
            adaptations(road, report, AudiQ5.Channel.CLUTCH_1_ADAPT);
            adaptations(road, report, AudiQ5.Channel.CLUTCH_2_ADAPT);
            adaptations(road, report, AudiQ5.Channel.CLUTCH_2_ADAPT_FAILED);
        }
        coverage(road, report, dl501, report.findings.size() == before);
        report.findings.sort(Comparator.comparing((Finding finding) -> finding.level).thenComparingLong(finding -> finding.time));
        return report;
    }

    private static void codes(RoadRecording road, Report report, boolean dl501) {
        Map<String, Integer> start = road.startScan == null ? Collections.emptyMap() : road.startScan.codes;
        Map<String, Integer> end = road.endScan == null ? Collections.emptyMap() : road.endScan.codes;
        TreeSet<String> both = new TreeSet<>(start.keySet());
        both.addAll(end.keySet());
        for (String code : both) {
            Integer a = start.get(code);
            Integer b = end.get(code);
            if (a == null && b == null) continue;
            String difference = a == null && road.startScan != null && road.startScan.usable()
                ? "Prvi put očitan na kraju ovog snimka. " : "";
            long at = b != null ? road.endScan.time : road.startScan.time;
            String evidence = difference + "Početak: " + status(a, road.startScan) + " · Kraj: " + status(b, road.endScan);
            String title = code + " · Zapis kontrolera";
            String interpretation = "Kod je zabeležio kontroler. Značenje i stanje zavise od tačne verzije modula.";
            RoadBarGrid.Group group = RoadBarGrid.Group.GEAR;
            if (dl501) {
                switch (code) {
                    case "P17CF00":
                    case "P17D000":
                        String clutch = code.equals("P17CF00") ? "K1" : "K2";
                        title = code + " · Proklizavanje " + clutch + " iznad granice kontrolera";
                        interpretation = "Mogući prateći simptom je porast obrtaja uz slabiji prenos momenta. " +
                            "Za utvrđivanje uzroka potrebni su ciljani podaci tog kvačila, pritisak i mehanička provera.";
                        group = RoadBarGrid.Group.SHAFTS;
                        break;
                    case "P17D800":
                        title = code + " · Ograničenje momenta zbog temperature kvačila";
                        interpretation = "Mogući prateći simptom je privremeno slabiji prenos momenta. Uporedi tok temperatura " +
                            "sa trenutkom simptoma. Status koda važi za vreme očitavanja grešaka.";
                        group = RoadBarGrid.Group.TEMPERATURE;
                        break;
                    case "P284D00":
                    case "P284E00":
                    case "P284F00":
                    case "P285000":
                        title = code + " · Neočekivano pomeranje viljuške menjača";
                        interpretation = "Mogući prateći simptomi su prekid ili kašnjenje izbora stepena. " +
                            "Za razlikovanje položaja viljuške, aktuatora i signala potrebna su dodatna očitavanja.";
                        break;
                    default:
                        break;
                }
            }
            report.findings.add(new Finding(Level.CONTROLLER, title, evidence, interpretation, at, group));
        }
    }

    private static void temperatureRise(RoadRecording road, Report report, AudiQ5.Channel channel, int threshold) {
        List<RoadRecording.Row> valid = new ArrayList<>();
        int lower = 0;
        long last = -SLOW_GAP_MS;
        double biggest = threshold;
        RoadRecording.Row from = null;
        RoadRecording.Row to = null;
        for (RoadRecording.Row row : road.rows) {
            double current = row.get(channel);
            if (!Double.isFinite(current) || row.time - last < 500) continue;
            if (row.time - last > SLOW_GAP_MS) lower = valid.size();
            last = row.time;
            while (lower < valid.size() && row.time - valid.get(lower).time > 30_000) lower++;
            for (int i = lower; i + 2 < valid.size(); i++) {
                RoadRecording.Row old = valid.get(i);
                long interval = row.time - old.time;
                double rise = current - old.get(channel);
                if (interval >= 8000 && rise >= biggest && valid.get(valid.size() - 1).get(channel) >= current - 4) {
                    biggest = rise;
                    from = old;
                    to = row;
                }
            }
            valid.add(row);
        }
        if (to != null) {
            report.findings.add(new Finding(Level.OBSERVATION, channel.label + " · Brz porast",
                value(from.get(channel)) + " → " + value(to.get(channel)) + " °C za " +
                    value((to.time - from.time) / 1000.0) + " s (" + time(from.time) + "–" + time(to.time) + ").",
                "Porast može pratiti veće opterećenje ili promenu hlađenja. Nalaz opisuje promenu unutar snimka.",
                to.time, RoadBarGrid.Group.TEMPERATURE));
        }
    }

    private static void clutchDifference(RoadRecording road, Report report) {
        long start = -1;
        long last = -SLOW_GAP_MS;
        long longest = 0;
        long bestEnd = 0;
        int sign = 0;
        double peak = 0;
        double bestPeak = 0;
        for (RoadRecording.Row row : road.rows) {
            double diff = row.get(AudiQ5.Channel.CLUTCH_1) - row.get(AudiQ5.Channel.CLUTCH_2);
            if (!Double.isFinite(diff)) continue;
            int direction = diff >= 25 ? 1 : diff <= -25 ? -1 : 0;
            if (direction != sign || row.time - last > SLOW_GAP_MS) {
                start = -1;
                peak = 0;
            }
            last = row.time;
            sign = direction;
            if (sign == 0) continue;
            if (start < 0) start = row.time;
            peak = Math.max(peak, Math.abs(diff));
            if (row.time - start > longest) {
                longest = row.time - start;
                bestEnd = row.time;
                bestPeak = peak;
            }
        }
        if (longest >= 12000) {
            report.findings.add(new Finding(Level.OBSERVATION, "Trajna razlika temperature kvačila",
                "Razlika najmanje 25 °C tokom " + value(longest / 1000.0) + " s. Najviše " + value(bestPeak) + " °C.",
                "Kvačila mogu raditi pod različitim opterećenjem. Veća težina nalaza dolazi iz ponavljanja u sličnim uslovima ili pratećeg DTC-a.",
                bestEnd, RoadBarGrid.Group.TEMPERATURE));
        }
    }

    private static void ratios(ShaftRatios profile, Report report) {
        for (int gear = 1; gear <= 7; gear++) {
            double baseline = profile.baseline[gear];
            if (baseline == 0) continue;
            double gate = Math.max(.15, 5 * profile.noise[gear]);
            long begin = -1;
            long previous = -FAST_GAP_MS;
            int streak = 0;
            double peak = 0;
            double best = 0;
            long from = 0;
            long end = 0;
            long lastSegment = -1;
            for (ShaftRatios.Sample sample : profile.samples) {
                double offset = profile.offset(sample);
                if (sample.gear != gear || offset < gate) {
                    begin = -1;
                    continue;
                }
                if (begin < 0 || lastSegment != sample.segment || sample.time - previous > FAST_GAP_MS) {
                    begin = sample.time;
                    streak = 0;
                    peak = 0;
                }
                previous = sample.time;
                lastSegment = sample.segment;
                streak++;
                peak = Math.max(peak, offset);
                if (streak >= 3 && sample.time - begin >= 1200 && peak >= best) {
                    best = peak;
                    from = begin;
                    end = sample.time;
                }
            }
            if (best > 0) {
                report.findings.add(new Finding(Level.OBSERVATION, "Odstupanje odnosa vratila · " + gear + ". stepen",
                    "Uobičajen odnos u snimku " + value(baseline) + " (" + profile.counts[gear] + " uzoraka). " +
                        "Odstupanje do " + value(best * 100) + "% u " + time(from) + "–" + time(end) + ".",
                    "Proveri da li se u tom trenutku osećao prekid prenosa. Uzrok može biti promena opterećenja, " +
                        "asinkrono očitavanje ili problem prenosa/signala. Odnos vratila sam ne meri proklizavanje kvačila.",
                    end, RoadBarGrid.Group.SHAFTS));
            }
        }
    }

    private static void gearHunting(RoadRecording road, Report report) {
        int last = 0;
        int older = 0;
        int streak = 0;
        long time = -FAST_GAP_MS;
        long start = 0;
        for (RoadRecording.Row row : road.rows) {
            int gear = (int) row.get(AudiQ5.Channel.GEAR);
            if (gear <= 0 || !(row.get(AudiQ5.Channel.OUTPUT) >= 250) || row.time - time > FAST_GAP_MS) {
                last = 0;
                older = 0;
                streak = 0;
            }
            time = row.time;
            if (gear <= 0 || !(row.get(AudiQ5.Channel.OUTPUT) >= 250) || gear == last) continue;
            if (last > 0 && Math.abs(gear - last) == 1) {
                if (gear == older && streak > 0 && row.time - start <= 8000) streak++;
                else {
                    start = row.time;
                    streak = 1;
                }
                if (streak >= 4) {
                    report.findings.add(new Finding(Level.OBSERVATION, "Uzastopne promene između susednih stepena",
                        "Višestruko prebacivanje između " + Math.min(gear, last) + ". i " + Math.max(gear, last) +
                            ". stepena u " + value((row.time - start) / 1000.0) + " s.",
                        "Može se osetiti učestalo prebacivanje. Saobraćaj, nagib i promena gasa takođe mogu izazvati taj obrazac.",
                        row.time, RoadBarGrid.Group.GEAR));
                    return;
                }
            } else {
                streak = 0;
            }
            older = last;
            last = gear;
        }
    }

    private static void adaptations(RoadRecording road, Report report, AudiQ5.Channel channel) {
        double first = Double.NaN;
        double last = Double.NaN;
        long changed = -1;
        boolean lowered = false;
        for (RoadRecording.Row row : road.rows) {
            double count = row.get(channel);
            if (!Double.isFinite(count)) continue;
            if (!Double.isFinite(first)) first = count;
            if (count < last) lowered = true;
            if (count > last) changed = row.time;
            last = count;
        }
        if (lowered) {
            report.findings.add(new Finding(Level.COVERAGE, channel.label + " · Prekid kontinuiteta",
                "Zabeleženo je smanjenje brojača tokom snimka.",
                "Moguć je reset, prelivanje ili prekid konzistentnog očitavanja. Neto promena nije predstavljena kao broj neuspeha.",
                -1, RoadBarGrid.Group.COUNTERS));
        } else if (changed >= 0 && last > first) {
            boolean failed = channel == AudiQ5.Channel.CLUTCH_2_ADAPT_FAILED;
            report.findings.add(new Finding(failed ? Level.OBSERVATION : Level.COVERAGE, channel.label,
                value(first) + " → " + value(last) + " (+" + value(last - first) + ").",
                failed ? "Kontroler je povećao brojač neuspešnih adaptacija K2. Uzrok se proverava uz status grešaka, " +
                    "uslove adaptacije i merenja kvačila." : "Brojač potvrđuje adaptacije registrovane tokom posmatranog intervala.",
                changed, RoadBarGrid.Group.COUNTERS));
        }
    }

    private static void coverage(RoadRecording road, Report report, boolean dl501, boolean noPattern) {
        long gap = 0;
        long gapEnd = 0;
        long previous = -1;
        for (RoadRecording.Row row : road.rows) {
            if (previous >= 0 && row.time - previous > gap) {
                gap = row.time - previous;
                gapEnd = row.time;
            }
            previous = row.time;
        }
        List<String> limits = new ArrayList<>();
        if (!dl501) limits.add("Identitet DL501 nije potvrđen u snimku.");
        if (road.rows.size() < 20) limits.add("Premalo uzoraka za pouzdano poređenje odnosa vratila.");
        if (road.malformed > 0) limits.add("Preskočenih neispravnih redova ili polja: " + road.malformed + ".");
        if (gap >= 3000) limits.add("Najduža pauza između uzoraka: " + value(gap / 1000.0) + " s.");
        if (road.ended.isEmpty()) limits.add("Nedostaje završni zapis snimka.");
        if ("connection_error".equals(road.ended) || "log_or_connection_error".equals(road.ended)) {
            limits.add("Snimanje je završeno greškom veze ili zapisa.");
        }
        if (!limits.isEmpty()) report.findings.add(new Finding(Level.COVERAGE, "Ograničenja snimka",
            String.join(" ", limits), "Neočitan kanal, sporo uzorkovanje i pauze smanjuju vidljivost kratkih događaja.",
            gap >= 3000 ? gapEnd : -1, RoadBarGrid.Group.TEMPERATURE));
        if (noPattern && dl501 && road.rows.size() >= 20) report.findings.add(new Finding(Level.COVERAGE,
            "Pravila analize nisu izdvojila obrazac", "Pregledani su kanali i periodi za koje je bilo dovoljno podataka.",
            "Kratkotrajni simptomi mogu biti između uzoraka.", -1, RoadBarGrid.Group.TEMPERATURE));
    }

    private static String scanStatus(RoadRecording.Scan scan) {
        if (scan == null) return "nema očitavanja";
        if (scan.usable()) return scan.codes.isEmpty() ? "očitano bez kodova" : scan.codes.size() + " DTC";
        switch (scan.status) {
            case UNSUPPORTED: return "statusi nisu podržani";
            case PARTIAL: return "nepotpun odgovor";
            case NO_RESPONSE: return "bez odgovora";
            default: return "status nije sačuvan";
        }
    }

    private static String status(Integer value, RoadRecording.Scan scan) {
        if (value == null) return scan != null && scan.usable() ? "nije prijavljen" : scanStatus(scan);
        List<String> bits = new ArrayList<>(Arrays.asList(String.format(Locale.ROOT, "0x%02X", value)));
        if ((value & 1) != 0) bits.add("prisutan pri očitavanju");
        if ((value & 4) != 0) bits.add("na čekanju");
        if ((value & 8) != 0) bits.add("potvrđen");
        return String.join(", ", bits);
    }

    static String time(long millis) {
        long seconds = millis / 1000;
        return String.format(Locale.ROOT, "%02d:%02d:%02d", seconds / 3600, seconds / 60 % 60, seconds % 60);
    }

    private static String value(double number) {
        String format = Math.rint(number) == number ? "%.0f" : "%.1f";
        return String.format(Locale.ROOT, format, number).replace('.', ',');
    }

    private RoadAnalysis() {}
}
