package rs.kiza.obd;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

final class TransmissionBars extends View {
    interface SelectionListener { void selected(String detail); }

    private static final int GRID = 0xFF34536C;
    private static final int TEXT = 0xFFBBCEDE;
    private static final int HIGHLIGHT = 0xFFE4F8FF;
    private static final int BASE = 0xFF129368;
    private static final int MID = 0xFFB3D342;
    private static final int HIGH = 0xFFFFA34E;
    private static final float MAX_HEIGHT = .75f;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final ValueAnimator growth = ValueAnimator.ofFloat(0, 1);
    private final ValueAnimator orbit = ValueAnimator.ofFloat(0, 1);
    private final List<BarDrawing> onScreen = new ArrayList<>();
    private final float dp;
    private final float touchSlop;
    private final SelectionListener selectionListener;

    private RoadBarGrid.Group group = RoadBarGrid.Group.TEMPERATURE;
    private List<AudiQ5.Channel> channels = Collections.emptyList();
    private List<RoadChartHistory.Point> history = Collections.emptyList();
    private RoadBarGrid grid = new RoadBarGrid(group, channels, history);
    private RoadBarGrid previous = grid;
    private RoadBarGrid.Bar selected;
    private float phase = 1;
    private float yaw = 34;
    private float pitch = 34;
    private float downX, downY, startYaw, startPitch;
    private boolean dragging;
    private boolean review;
    private boolean touchClick;
    private int pointerId = -1;

    TransmissionBars(Context context, SelectionListener listener) {
        super(context);
        selectionListener = listener;
        dp = getResources().getDisplayMetrics().density;
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        setClickable(true);
        setFocusable(true);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);
        setContentDescription(context.getString(R.string.chart_empty));
        growth.setDuration(250);
        orbit.setDuration(4200);
        orbit.setRepeatMode(ValueAnimator.REVERSE);
        orbit.setRepeatCount(ValueAnimator.INFINITE);
        orbit.addUpdateListener(anim -> {
            float position = (float) anim.getAnimatedValue();
            yaw = 24 + 22 * position;
            pitch = 30 + 7 * position;
            invalidate();
        });
        growth.setInterpolator(new DecelerateInterpolator());
        growth.addUpdateListener(anim -> {
            phase = (float) anim.getAnimatedValue();
            invalidate();
        });
    }

    void update(RoadBarGrid.Group requested, List<AudiQ5.Channel> available, List<RoadChartHistory.Point> samples) {
        if (group == requested && channels == available && history == samples) return;
        boolean changedGroup = group != requested;
        if (changedGroup) selected = null;
        group = requested;
        channels = available;
        history = samples;
        RoadBarGrid next = new RoadBarGrid(group, channels, history);
        boolean changedDrawing = changedGroup || !next.sameDrawing(grid);
        if (changedDrawing) previous = changedGroup ? new RoadBarGrid(group, channels, Collections.emptyList()) : grid;
        grid = next;

        if (selected != null) {
            selected = grid.at(selected.channel, selected.bucket);
        }
        publishSelection();
        if (!changedDrawing) return;
        if (isShown() && isAttachedToWindow() && grid.hasData() && ValueAnimator.areAnimatorsEnabled()) {
            growth.start();
        } else {
            growth.cancel();
            phase = 1;
            invalidate();
        }
    }

    void setReviewMode() { review = true; }

    void setRotating(boolean enabled) {
        if (!enabled) orbit.cancel();
        else if (!orbit.isRunning() && ValueAnimator.areAnimatorsEnabled()) orbit.start();
    }

    void resetCamera() {
        orbit.cancel();
        yaw = 34;
        pitch = 34;
        select(null);
    }

    private void publishSelection() {
        if (selected == null) {
            selectionListener.selected("");
            setContentDescription(getContext().getString(grid.hasData() ? R.string.bar_hint : R.string.chart_empty));
            return;
        }
        String time = String.format(Locale.US, "%.1f", (grid.latest - selected.time) / 1000.0).replace('.', ',');
        String value = selected.channel.display(selected.value);
        String message = review ? selected.channel.label + " · " + value + " · " + RoadAnalysis.time(selected.time)
            : getContext().getString(R.string.bar_selection, selected.channel.label, value, time);
        selectionListener.selected(message);
        setContentDescription(message);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        onScreen.clear();
        if (getWidth() < 160 * dp || getHeight() < 140 * dp) return;
        int rowCount = Math.max(1, grid.rows.size());
        float depth = .22f * rowCount;
        Projection p = new Projection(getWidth(), getHeight(), dp, yaw, pitch, depth);

        quad(canvas, 0xFF0D1929, p.point(0, 0, 0), p.point(1, 0, 0),
            p.point(1, 0, depth), p.point(0, 0, depth));
        quad(canvas, 0xFF13263A, p.point(0, 0, 0), p.point(1, 0, 0),
            p.point(1, MAX_HEIGHT, 0), p.point(0, MAX_HEIGHT, 0));
        quad(canvas, 0xFF172E43, p.point(0, 0, 0), p.point(0, 0, depth),
            p.point(0, MAX_HEIGHT, depth), p.point(0, MAX_HEIGHT, 0));
        for (int i = 0; i <= grid.levels; i++) {
            float y = MAX_HEIGHT * i / grid.levels;
            line(canvas, p.point(0, y, depth), p.point(0, y, 0));
            line(canvas, p.point(0, y, 0), p.point(1, y, 0));
        }
        for (int col = 0; col <= RoadBarGrid.COLUMNS; col++) {
            float x = col / (float) RoadBarGrid.COLUMNS;
            line(canvas, p.point(x, 0, 0), p.point(x, 0, depth));
        }
        for (int row = 0; row <= rowCount; row++) {
            float z = depth * row / rowCount;
            line(canvas, p.point(0, 0, z), p.point(1, 0, z));
        }
        for (int row = 0; row < grid.rows.size(); row++) {
            for (int col = 0; col < RoadBarGrid.COLUMNS; col++) {
                RoadBarGrid.Bar bar = grid.bar(row, col);
                if (bar != null) onScreen.add(drawing(p, bar, row, col));
            }
        }
        onScreen.sort(Comparator.comparingDouble(drawing -> drawing.distance));
        for (BarDrawing bar : onScreen) drawBar(canvas, bar);
        drawLabels(canvas, p, depth, rowCount);
        if (onScreen.isEmpty()) {
            label(canvas, getContext().getString(R.string.chart_empty), getWidth() / 2f,
                getHeight() * .48f, Paint.Align.CENTER);
        }
    }

    private BarDrawing drawing(Projection p, RoadBarGrid.Bar bar, int row, int col) {
        float fraction = (float) grid.fraction(bar.numeric);
        RoadBarGrid.Bar old = previous.at(bar.channel, bar.bucket);
        float start = old == null ? 0 : (float) grid.fraction(old.numeric);
        float rise = Math.max(.009f, MAX_HEIGHT * (start + phase * (fraction - start)));
        float x = (col + .13f) / RoadBarGrid.COLUMNS;
        float endX = (col + .87f) / RoadBarGrid.COLUMNS;
        float z = row * .22f + .027f;
        float endZ = (row + 1) * .22f - .027f;
        Vec a = p.point(x, 0, endZ);
        Vec b = p.point(endX, 0, endZ);
        Vec c = p.point(endX, 0, z);
        Vec at = p.point(x, rise, endZ);
        Vec bt = p.point(endX, rise, endZ);
        Vec ct = p.point(endX, rise, z);
        Vec dt = p.point(x, rise, z);
        return new BarDrawing(bar, p.distance((x + endX) / 2, (z + endZ) / 2), fraction,
            new Vec[]{a, b, bt, at}, new Vec[]{b, c, ct, bt}, new Vec[]{at, bt, ct, dt});
    }

    private void drawBar(Canvas canvas, BarDrawing bar) {
        boolean highlighted = selected != null && selected.channel == bar.bar.channel && selected.time == bar.bar.time;
        int crown = bar.fraction <= .62f ? mix(BASE, MID, bar.fraction / .62f)
            : mix(MID, HIGH, (bar.fraction - .62f) / .38f);
        if (highlighted) crown = mix(crown, HIGHLIGHT, .60f);
        Vec base = bar.front[0];
        Vec top = bar.front[3];
        paint.setShader(new LinearGradient(base.x, base.y, top.x, top.y,
            mix(BASE, 0xFF0A2530, .50f), crown, Shader.TileMode.CLAMP));
        quad(canvas, Color.WHITE, bar.front[0], bar.front[1], bar.front[2], bar.front[3]);
        quad(canvas, Color.WHITE, bar.side[0], bar.side[1], bar.side[2], bar.side[3]);
        paint.setShader(null);
        quad(canvas, 0x50091E30, bar.side[0], bar.side[1], bar.side[2], bar.side[3]);
        quad(canvas, mix(crown, HIGHLIGHT, .23f), bar.top[0], bar.top[1], bar.top[2], bar.top[3]);
        if (highlighted) {
            outline(canvas, HIGHLIGHT, bar.front);
            outline(canvas, HIGHLIGHT, bar.top);
        }
    }

    private void drawLabels(Canvas canvas, Projection p, float depth, int count) {
        for (int i = 0; i <= grid.levels && !onScreen.isEmpty(); i++) {
            float y = MAX_HEIGHT * i / grid.levels;
            double v = grid.low + (grid.high - grid.low) * i / grid.levels;
            String tick = group == RoadBarGrid.Group.GEAR && v == -1
                ? "R" : v == Math.rint(v) ? Long.toString((long) v)
                : String.format(Locale.US, "%.1f", v).replace('.', ',');
            Vec left = p.point(0, y, depth);
            label(canvas, tick, left.x - 6 * dp, left.y + 4 * dp, Paint.Align.RIGHT);
        }
        for (int i = 0; i <= 3; i++) {
            Vec mark = p.point(i / 3f, 0, depth);
            String text = i == 3 ? (review ? "Kursor" : getContext().getString(R.string.chart_now)) : (i * 20 - 60) + " s";
            label(canvas, text, mark.x, mark.y + 16 * dp,
                i == 0 ? Paint.Align.LEFT : i == 3 ? Paint.Align.RIGHT : Paint.Align.CENTER);
        }
        for (int i = 0; i < grid.rows.size(); i++) {
            Vec row = p.point(1, 0, depth * (i + .5f) / count);
            label(canvas, group.abbreviation(grid.rows.get(i)), row.x + 6 * dp, row.y + 3 * dp, Paint.Align.LEFT);
        }
        if (!group.unit.isEmpty()) {
            Vec scale = p.point(0, MAX_HEIGHT, depth);
            label(canvas, group.unit, scale.x - 6 * dp, scale.y - 10 * dp, Paint.Align.RIGHT);
        }
    }

    private static int mix(int a, int b, float t) {
        return Color.rgb(Math.round(Color.red(a) + (Color.red(b) - Color.red(a)) * t),
            Math.round(Color.green(a) + (Color.green(b) - Color.green(a)) * t),
            Math.round(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t));
    }

    private void setPath(Vec a, Vec b, Vec c, Vec d) {
        path.reset();
        path.moveTo(a.x, a.y);
        path.lineTo(b.x, b.y);
        path.lineTo(c.x, c.y);
        path.lineTo(d.x, d.y);
        path.close();
    }

    private void quad(Canvas canvas, int color, Vec a, Vec b, Vec c, Vec d) {
        paint.setColor(color);
        setPath(a, b, c, d);
        canvas.drawPath(path, paint);
    }

    private void outline(Canvas canvas, int color, Vec[] points) {
        paint.setColor(color);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.25f * dp);
        setPath(points[0], points[1], points[2], points[3]);
        canvas.drawPath(path, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void line(Canvas canvas, Vec a, Vec b) {
        paint.setColor(GRID);
        paint.setStrokeWidth(dp);
        canvas.drawLine(a.x, a.y, b.x, b.y, paint);
    }

    private void label(Canvas canvas, String value, float x, float y, Paint.Align align) {
        paint.setColor(TEXT);
        paint.setTextAlign(align);
        paint.setTextSize(11 * dp);
        canvas.drawText(value, x, y, paint);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                orbit.cancel();
                pointerId = event.getPointerId(0);
                downX = event.getX();
                downY = event.getY();
                startYaw = yaw;
                startPitch = pitch;
                dragging = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            case MotionEvent.ACTION_MOVE:
                int pointer = event.findPointerIndex(pointerId);
                if (pointer < 0) return true;
                float dx = event.getX(pointer) - downX;
                float dy = event.getY(pointer) - downY;
                if (!dragging && Math.hypot(dx, dy) <= touchSlop) return true;
                dragging = true;
                yaw = Math.max(12, Math.min(67, startYaw + dx / (4 * dp)));
                pitch = Math.max(20, Math.min(53, startPitch - dy / (4 * dp)));
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                if (!dragging && event.getPointerId(0) == pointerId) {
                    selectAt(event.getX(), event.getY());
                    touchClick = true;
                    performClick();
                    touchClick = false;
                }
                pointerId = -1;
                return true;
            case MotionEvent.ACTION_CANCEL:
                pointerId = -1;
                return true;
            default: return super.onTouchEvent(event);
        }
    }

    private void selectAt(float x, float y) {
        RoadBarGrid.Bar bar = findBar(x, y);
        if (bar == null) {
            float step = 3 * dp;
            bar = findBar(x, y + step);
            if (bar == null) bar = findBar(x, y - step);
            if (bar == null) bar = findBar(x + step, y);
            if (bar == null) bar = findBar(x - step, y);
        }
        select(bar);
    }

    private RoadBarGrid.Bar findBar(float x, float y) {
        for (int i = onScreen.size() - 1; i >= 0; i--) {
            BarDrawing view = onScreen.get(i);
            if (inside(view.top, x, y) || inside(view.front, x, y) || inside(view.side, x, y)) {
                return grid.at(view.bar.channel, view.bar.bucket);
            }
        }
        return null;
    }

    private void select(RoadBarGrid.Bar bar) {
        selected = bar;
        publishSelection();
        invalidate();
    }

    @Override public boolean performClick() {
        if (!touchClick) {
            RoadBarGrid.Bar latest = null;
            for (BarDrawing drawing : onScreen) {
                RoadBarGrid.Bar bar = grid.at(drawing.bar.channel, drawing.bar.bucket);
                if (bar != null && (latest == null || bar.time > latest.time)) latest = bar;
            }
            select(latest);
        }
        super.performClick();
        return true;
    }

    private static boolean inside(Vec[] polygon, float x, float y) {
        boolean positive = false;
        boolean negative = false;
        for (int i = 0; i < polygon.length; i++) {
            Vec a = polygon[i];
            Vec b = polygon[(i + 1) % polygon.length];
            float cross = (b.x - a.x) * (y - a.y) - (b.y - a.y) * (x - a.x);
            if (cross > .01f) positive = true;
            if (cross < -.01f) negative = true;
            if (positive && negative) return false;
        }
        return positive || negative;
    }

    @Override protected void onDetachedFromWindow() {
        orbit.cancel();
        growth.cancel();
        phase = 1;
        super.onDetachedFromWindow();
    }

    private static final class Vec {
        final float x, y;
        Vec(float x, float y) { this.x = x; this.y = y; }
    }

    private static final class BarDrawing {
        final RoadBarGrid.Bar bar;
        final float distance;
        final float fraction;
        final Vec[] front, side, top;

        BarDrawing(RoadBarGrid.Bar bar, float distance, float fraction, Vec[] front, Vec[] side, Vec[] top) {
            this.bar = bar;
            this.distance = distance;
            this.fraction = fraction;
            this.front = front;
            this.side = side;
            this.top = top;
        }
    }

    private static final class Projection {
        final float sinYaw, cosYaw, sinPitch, cosPitch, scale, offsetX, offsetY;

        Projection(int width, int height, float dp, float yaw, float pitch, float depth) {
            sinYaw = (float) Math.sin(Math.toRadians(yaw));
            cosYaw = (float) Math.cos(Math.toRadians(yaw));
            sinPitch = (float) Math.sin(Math.toRadians(pitch));
            cosPitch = (float) Math.cos(Math.toRadians(pitch));
            float minX = -depth * sinYaw;
            float minY = -MAX_HEIGHT * cosPitch;
            float spanX = cosYaw - minX;
            float spanY = distance(1, depth) * sinPitch - minY;
            scale = Math.min((width - 98 * dp) / spanX, (height - 57 * dp) / spanY);
            offsetX = (width - spanX * scale) / 2 - minX * scale;
            offsetY = (height - spanY * scale) / 2 - minY * scale - 4 * dp;
        }

        float distance(float x, float z) { return x * sinYaw + z * cosYaw; }

        Vec point(float x, float height, float z) {
            return new Vec(offsetX + scale * (x * cosYaw - z * sinYaw),
                offsetY + scale * (distance(x, z) * sinPitch - height * cosPitch));
        }
    }
}
