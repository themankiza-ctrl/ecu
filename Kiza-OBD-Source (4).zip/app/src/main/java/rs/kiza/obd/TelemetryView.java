package rs.kiza.obd;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.widget.FrameLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.function.LongConsumer;

final class TelemetryView extends FrameLayout {
    private static final String PAGE = LocalChartPage.url("telemetry.html");
    private static final String SELECT = "/obd-telemetry/select";

    private static final class Line {
        final RoadTelemetry.Track track;
        final List<RoadTelemetry.Point> points;

        Line(RoadTelemetry.Track track, long from, long to) {
            this.track = track;
            points = track.plot(from, to);
        }
    }

    private final RoadTelemetry data;
    private final LongConsumer selected;
    private final Fallback fallback;
    private final List<Line> lines = new ArrayList<>();
    private final boolean[] lanes = new boolean[3];
    private RoadTelemetry.MapData map;
    private double mapMin;
    private double mapMax;
    private String mapUnit;
    private String mapNote;
    private String mapTitle;
    private WebView web;
    private boolean ready;
    private boolean failed;
    private long from;
    private long to;
    private long cursor;
    private int revision;

    TelemetryView(Context context, RoadTelemetry data, LongConsumer selected) {
        super(context);
        this.data = data;
        this.selected = selected;
        fallback = new Fallback(context);
        addView(fallback, new LayoutParams(-1, -1));
    }

    void timeline(long from, long to) {
        this.from = from;
        this.to = Math.max(from + 1, to);
        map = null;
        lines.clear();
        for (int i = 0; i < lanes.length; i++) lanes[i] = false;
        for (RoadTelemetry.Track track : data.tracks) {
            lines.add(new Line(track, from, to));
            lanes[track.lane()] = true;
        }
        refresh();
    }

    void heatmap(boolean oil) {
        map = oil ? data.temperatures : data.ratios;
        fallback.selection = "";
        mapUnit = oil ? "°C" : "%";
        mapTitle = oil ? "Mapa temperature ulja" : "Mapa odstupanja odnosa vratila";
        mapNote = map.cells.isEmpty() ? "Nema dovoljno odgovarajućih očitavanja za ovu mapu."
            : "Dodirni polje za detalje i skok na vrh u tom rasponu.";
        mapMin = oil ? Double.POSITIVE_INFINITY : 0;
        mapMax = Double.NEGATIVE_INFINITY;
        for (RoadTelemetry.Cell cell : map.cells) {
            mapMin = Math.min(mapMin, cell.mean());
            mapMax = Math.max(mapMax, cell.mean());
        }
        if (!Double.isFinite(mapMin)) mapMin = 0;
        if (!Double.isFinite(mapMax)) mapMax = 1;
        mapMin = Math.floor(mapMin);
        mapMax = Math.max(mapMin + 1, Math.ceil(mapMax));
        refresh();
    }

    void seek(long time) {
        cursor = time;
        if (fallback.getVisibility() == VISIBLE) fallback.invalidate();
        if (ready && map == null && isShown()) web.evaluateJavascript("window.obdTelemetry.seek(" + time + ")", null);
    }

    private void refresh() {
        fallback.setContentDescription(map == null ? "Vremenska linija očitavanja" : mapTitle + ". " + mapNote);
        fallback.invalidate();
        if (isAttachedToWindow() && isShown() && web == null && !failed) launch();
        if (ready) render();
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        post(() -> {
            if (isAttachedToWindow() && !failed && web == null) launch();
        });
    }

    @Override public void onVisibilityAggregated(boolean visible) {
        super.onVisibilityAggregated(visible);
        if (web == null) return;
        if (visible) web.onResume();
        else web.onPause();
    }

    private void launch() {
        try {
            WebView candidate = LocalChartPage.create(getContext());
            candidate.setOnTouchListener(new OnTouchListener() {
                private float x;
                private float y;

                @Override public boolean onTouch(View chart, MotionEvent event) {
                    if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                        x = event.getX();
                        y = event.getY();
                    } else if (event.getActionMasked() == MotionEvent.ACTION_MOVE || event.getPointerCount() > 1) {
                        boolean horizontal = Math.abs(event.getX() - x) > Math.abs(event.getY() - y);
                        requestDisallowInterceptTouchEvent(horizontal || event.getPointerCount() > 1);
                    }
                    return false;
                }
            });
            candidate.setVisibility(INVISIBLE);
            web = candidate;
            candidate.setWebViewClient(new LocalChartPage() {
                @Override public void onPageFinished(WebView view, String url) {
                    if (web != view || !PAGE.equals(url)) return;
                    view.evaluateJavascript("Boolean(window.obdTelemetry && window.obdTelemetry.ready())", result -> {
                        if (web != view) return;
                        if (!"true".equals(result)) {
                            useFallback();
                            return;
                        }
                        ready = true;
                        render();
                    });
                }

                @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    android.net.Uri url = request.getUrl();
                    if (web == view && request.isForMainFrame() && LocalChartPage.hosts(url) && SELECT.equals(url.getPath())) {
                        String raw = url.getQueryParameter("t");
                        if (raw != null && raw.matches("[0-9]{1,10}")) {
                            long time = Math.min(data.duration, Long.parseLong(raw));
                            post(() -> {
                                if (web == view && isShown()) selected.accept(time);
                            });
                        }
                    }
                    return true;
                }

                @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                    if (web == view) useFallback();
                    return true;
                }
            });
            addView(candidate, new LayoutParams(-1, -1));
            candidate.loadUrl(PAGE);
            postDelayed(() -> {
                if (web == candidate && !ready) useFallback();
            }, 6000);
        } catch (RuntimeException error) {
            useFallback();
        }
    }

    private void render() {
        if (web == null || lines.isEmpty() && map == null) return;
        try {
            int request = ++revision;
            WebView candidate = web;
            JSONObject data = map == null ? timelineJson() : heatmapJson();
            candidate.evaluateJavascript("window.obdTelemetry.render(" + data + "," + cursor + ")", result -> {
                if (web != candidate || request != revision) return;
                if ("true".equals(result)) {
                    fallback.setVisibility(INVISIBLE);
                    candidate.setVisibility(VISIBLE);
                } else {
                    useFallback();
                }
            });
        } catch (JSONException error) {
            useFallback();
        }
    }

    private JSONObject timelineJson() throws JSONException {
        JSONArray tracks = new JSONArray();
        for (Line line : lines) {
            JSONArray points = new JSONArray();
            for (RoadTelemetry.Point point : line.points) {
                points.put(new JSONArray().put(point.time).put(point.value == null ? JSONObject.NULL : point.value));
            }
            tracks.put(new JSONObject().put("id", line.track.channel.name())
                .put("label", line.track.channel.label).put("lane", line.track.lane()).put("points", points));
        }
        JSONArray shifts = new JSONArray();
        List<RoadTelemetry.Shift> visible = data.visibleShifts(from, to);
        if (visible.size() <= 100) {
            for (RoadTelemetry.Shift shift : visible) shifts.put(new JSONArray().put(shift.time).put(shift.to));
        }
        return new JSONObject().put("type", "timeline").put("tracks", tracks)
            .put("from", from).put("to", to).put("shifts", shifts);
    }

    private JSONObject heatmapJson() throws JSONException {
        JSONArray cells = new JSONArray();
        for (RoadTelemetry.Cell cell : map.cells) {
            cells.put(new JSONArray().put(cell.column).put(cell.gear - 1)
                .put(cell.mean()).put(cell.count).put(cell.peak).put(cell.time));
        }
        return new JSONObject().put("type", "map").put("labels", new JSONArray(map.labels))
            .put("cells", cells).put("min", mapMin).put("max", mapMax)
            .put("unit", mapUnit).put("title", mapTitle).put("note", mapNote);
    }

    private void useFallback() {
        failed = true;
        destroyWeb();
        fallback.setVisibility(VISIBLE);
        fallback.invalidate();
    }

    private void destroyWeb() {
        if (web == null) return;
        WebView previous = web;
        web = null;
        ready = false;
        revision++;
        removeView(previous);
        previous.destroy();
    }

    @Override protected void onDetachedFromWindow() {
        destroyWeb();
        fallback.setVisibility(VISIBLE);
        super.onDetachedFromWindow();
    }

    private final class Fallback extends View {
        private static final int GRID = 0xFF294359;
        private static final int TEXT = 0xFFBDD5E7;
        private static final int CURSOR = 0xFFB9F8E8;
        private final int[] colors = {0xFFFFCB78, 0xFFFA9D8A, 0xFFB4AAFF, 0xFFD1E58C, 0xFF71E4D0, 0xFF87BFFF, 0xFFA8B9FF};
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float density;
        private String selection = "";

        Fallback(Context context) {
            super(context);
            setClickable(true);
            density = getResources().getDisplayMetrics().density;
        }

        @Override protected void onDraw(Canvas canvas) {
            canvas.drawColor(0xFF101D2F);
            if (map != null) drawMap(canvas);
            else drawTimeline(canvas);
        }

        private void drawTimeline(Canvas canvas) {
            if (lines.isEmpty()) return;
            int panels = 0;
            for (boolean lane : lanes) if (lane) panels++;
            float left = 35 * density;
            float right = getWidth() - 7 * density;
            float height = (getHeight() - 22 * density) / panels;
            int index = 0;
            String[] titles = {"Temperature · °C", "Vratila · o/min", "Stepen prenosa"};
            for (int lane = 0; lane < lanes.length; lane++) {
                if (!lanes[lane]) continue;
                float top = index * height + 23 * density;
                float bottom = (index + 1) * height - 6 * density;
                label(canvas, titles[lane], left, top - 8 * density, Paint.Align.LEFT, 11);
                double min = lane == 2 ? -1 : Double.POSITIVE_INFINITY;
                double max = lane == 2 ? 7 : Double.NEGATIVE_INFINITY;
                if (lane != 2) {
                    for (Line line : lines) {
                        if (line.track.lane() != lane) continue;
                        for (RoadTelemetry.Point point : line.points) {
                            if (point.value == null) continue;
                            min = Math.min(min, point.value);
                            max = Math.max(max, point.value);
                        }
                    }
                }
                if (Double.isFinite(min)) {
                    max = Math.max(min + 1, max);
                    for (int tick = 0; tick <= 2; tick++) {
                        float y = top + (bottom - top) * tick / 2;
                        stroke(canvas, GRID, left, y, right, y);
                        double value = max - (max - min) * tick / 2;
                        label(canvas, lane == 2 && tick == 2 ? "R" : RoadTelemetry.number(value),
                            left - 3 * density, y + 3 * density, Paint.Align.RIGHT, 9);
                    }
                    for (Line series : lines) {
                        if (series.track.lane() != lane) continue;
                        int color = colors[Math.min(colors.length - 1, colorIndex(series.track.channel))];
                        float oldX = 0;
                        float oldY = 0;
                        boolean joined = false;
                        for (RoadTelemetry.Point point : series.points) {
                            if (point.value == null) {
                                joined = false;
                                continue;
                            }
                            float x = left + (right - left) * (point.time - from) / (to - from);
                            float y = bottom - (float) ((bottom - top) * ((point.value - min) / (max - min)));
                            if (joined && lane == 2) {
                                stroke(canvas, color, oldX, oldY, x, oldY);
                                stroke(canvas, color, x, oldY, x, y);
                            } else if (joined) {
                                stroke(canvas, color, oldX, oldY, x, y);
                            } else {
                                paint.setColor(color);
                                canvas.drawCircle(x, y, 2 * density, paint);
                            }
                            joined = true;
                            oldX = x;
                            oldY = y;
                        }
                    }
                }
                if (cursor >= from && cursor <= to) {
                    float x = left + (right - left) * (cursor - from) / (to - from);
                    stroke(canvas, CURSOR, x, top, x, bottom);
                }
                index++;
            }
            label(canvas, RoadAnalysis.time(from), left, getHeight() - 8 * density, Paint.Align.LEFT, 10);
            label(canvas, RoadAnalysis.time(to), right, getHeight() - 8 * density, Paint.Align.RIGHT, 10);
        }

        private void drawMap(Canvas canvas) {
            if (map.cells.isEmpty()) {
                label(canvas, "Nema dovoljno očitavanja za mapu.", 8 * density, 24 * density, Paint.Align.LEFT, 12);
                return;
            }
            float left = 26 * density;
            float top = 12 * density;
            float width = (getWidth() - left - 6 * density) / map.labels.size();
            float height = (getHeight() - 65 * density) / 7;
            for (int row = 0; row < 7; row++) {
                float y = top + row * height;
                label(canvas, (7 - row) + ".", left - 5 * density, y + height / 2, Paint.Align.RIGHT, 10);
                for (int col = 0; col < map.labels.size(); col++) {
                    float x = left + width * col;
                    paint.setColor(0xFF192A3E);
                    canvas.drawRect(x, y, x + width - density, y + height - density, paint);
                }
            }
            for (RoadTelemetry.Cell cell : map.cells) {
                float x = left + width * cell.column;
                float y = top + height * (7 - cell.gear);
                float fraction = (float) ((cell.mean() - mapMin) / (mapMax - mapMin));
                paint.setColor(android.graphics.Color.HSVToColor(new float[]{170 - 130 * fraction, .72f, .60f + .27f * fraction}));
                canvas.drawRect(x, y, x + width - density, y + height - density, paint);
                label(canvas, RoadTelemetry.number(cell.mean()), x + width / 2, y + height / 2 + 3 * density, Paint.Align.CENTER, 10);
            }
            for (int i = 0; i < map.labels.size(); i++) {
                float x = left + width * (i + .5f);
                String[] interval = map.labels.get(i).split("–");
                float bottom = top + height * 7;
                label(canvas, interval[0], x, bottom + 12 * density, Paint.Align.CENTER, 8);
                label(canvas, interval[1], x, bottom + 23 * density, Paint.Align.CENTER, 8);
            }
            label(canvas, selection.isEmpty() ? "Izlazno vratilo · o/min" : selection, 8 * density,
                getHeight() - 12 * density, Paint.Align.LEFT, 10);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) return true;
            if (event.getActionMasked() != MotionEvent.ACTION_UP) return super.onTouchEvent(event);
            if (map == null && to > from) {
                float x = (event.getX() - 35 * density) / (getWidth() - 42 * density);
                if (x >= 0 && x <= 1) selected.accept(from + Math.round((to - from) * x));
            } else if (map != null && !map.cells.isEmpty()) {
                float width = (getWidth() - 32 * density) / map.labels.size();
                float height = (getHeight() - 65 * density) / 7;
                int col = (int) Math.floor((event.getX() - 26 * density) / width);
                int gear = 7 - (int) Math.floor((event.getY() - 12 * density) / height);
                for (RoadTelemetry.Cell cell : map.cells) {
                    if (cell.column != col || cell.gear != gear) continue;
                    selection = gear + ". stepen · " + RoadTelemetry.number(cell.mean()) + " " + mapUnit +
                        " · " + cell.count + " uzoraka";
                    announceForAccessibility(selection);
                    selected.accept(cell.time);
                    invalidate();
                    break;
                }
            }
            performClick();
            return true;
        }

        @Override public boolean performClick() { return super.performClick(); }

        private void stroke(Canvas canvas, int color, float x, float y, float toX, float toY) {
            paint.setColor(color);
            paint.setStrokeWidth(1.3f * density);
            canvas.drawLine(x, y, toX, toY, paint);
        }

        private void label(Canvas canvas, String text, float x, float y, Paint.Align align, int size) {
            paint.setColor(TEXT);
            paint.setTextAlign(align);
            paint.setTextSize(size * density);
            canvas.drawText(text, x, y, paint);
        }

        private int colorIndex(AudiQ5.Channel channel) {
            switch (channel) {
                case ATF: return 0;
                case CLUTCH_1: return 1;
                case CLUTCH_2: return 2;
                case MODULE_TEMP: return 3;
                case INPUT: return 4;
                case OUTPUT: return 5;
                default: return 6;
            }
        }
    }
}
