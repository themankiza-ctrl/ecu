package rs.kiza.obd;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class RoadBarGrid {
    static final int COLUMNS = 12;
    static final long BIN_MS = RoadChartHistory.WINDOW_MS / COLUMNS;

    enum Group {
        TEMPERATURE("Temperature", "°C", new String[]{"ATF", "K1", "K2", "TCM"},
            AudiQ5.Channel.ATF, AudiQ5.Channel.CLUTCH_1, AudiQ5.Channel.CLUTCH_2, AudiQ5.Channel.MODULE_TEMP),
        SHAFTS("Obrtaji vratila", "o/min", new String[]{"UL", "IZ"},
            AudiQ5.Channel.INPUT, AudiQ5.Channel.OUTPUT),
        COUNTERS("Brojači adaptacija", "", new String[]{"K1 OK", "K2 OK", "K2 GR"},
            AudiQ5.Channel.CLUTCH_1_ADAPT, AudiQ5.Channel.CLUTCH_2_ADAPT, AudiQ5.Channel.CLUTCH_2_ADAPT_FAILED),
        GEAR("Stepen prenosa", "", new String[]{"PREN."}, AudiQ5.Channel.GEAR);

        final String label;
        final String unit;
        private final String[] abbreviations;
        private final AudiQ5.Channel[] members;

        Group(String label, String unit, String[] abbreviations, AudiQ5.Channel... members) {
            this.label = label;
            this.unit = unit;
            this.abbreviations = abbreviations;
            this.members = members;
        }

        String abbreviation(AudiQ5.Channel channel) {
            for (int i = 0; i < members.length; i++) {
                if (members[i] == channel) return abbreviations[i];
            }
            throw new IllegalArgumentException(channel.name());
        }

        List<AudiQ5.Channel> supported(List<AudiQ5.Channel> available) {
            List<AudiQ5.Channel> result = new ArrayList<>();
            for (AudiQ5.Channel channel : members) {
                if (available.contains(channel)) result.add(channel);
            }
            return result;
        }
    }

    static final class Bar {
        final AudiQ5.Channel channel;
        final long bucket;
        final long time;
        final String value;
        final double numeric;

        Bar(AudiQ5.Channel channel, long bucket, long time, String value, double numeric) {
            this.channel = channel;
            this.bucket = bucket;
            this.time = time;
            this.value = value;
            this.numeric = numeric;
        }
    }

    final List<AudiQ5.Channel> rows;
    final long latest;
    final long firstBucket;
    final double low;
    final double high;
    final int levels;
    private final Bar[][] bars;

    RoadBarGrid(Group group, List<AudiQ5.Channel> available, List<RoadChartHistory.Point> points) {
        rows = Collections.unmodifiableList(group.supported(available));
        latest = points.isEmpty() ? 0 : points.get(points.size() - 1).millis;
        firstBucket = Math.floorDiv(latest, BIN_MS) - COLUMNS + 1;
        bars = new Bar[rows.size()][COLUMNS];
        for (RoadChartHistory.Point point : points) {
            long bucket = Math.floorDiv(point.millis, BIN_MS);
            int column = (int) (bucket - firstBucket);
            if (column < 0 || column >= COLUMNS) continue;
            for (int row = 0; row < rows.size(); row++) {
                AudiQ5.Channel channel = rows.get(row);
                String value = point.sample.values[channel.ordinal()];
                if (value == null || value.isEmpty()) continue;
                double numeric = value.equals("R") ? -1 : Double.parseDouble(value);
                bars[row][column] = new Bar(channel, bucket, point.millis, value, numeric);
            }
        }

        if (group == Group.GEAR) {
            low = -1;
            high = 7;
            levels = 4;
        } else {
            double min = 0;
            double max = 0;
            for (Bar[] row : bars) {
                for (Bar bar : row) {
                    if (bar == null) continue;
                    min = Math.min(min, bar.numeric);
                    max = Math.max(max, bar.numeric);
                }
            }
            double step = axisStep(Math.max(1, (max - min) / 5));
            low = Math.floor(min / step) * step;
            high = Math.max(low + step, Math.ceil(max / step) * step);
            levels = (int) Math.round((high - low) / step);
        }
    }

    private static double axisStep(double raw) {
        double magnitude = Math.pow(10, Math.floor(Math.log10(raw)));
        double scale = raw / magnitude;
        if (scale <= 1) return magnitude;
        if (scale <= 2) return 2 * magnitude;
        if (scale <= 2.5) return 2.5 * magnitude;
        if (scale <= 5) return 5 * magnitude;
        return 10 * magnitude;
    }

    Bar bar(int row, int col) { return bars[row][col]; }

    Bar at(AudiQ5.Channel channel, long bucket) {
        int row = rows.indexOf(channel);
        long col = bucket - firstBucket;
        if (row < 0 || col < 0 || col >= COLUMNS) return null;
        return bars[row][(int) col];
    }

    double fraction(double value) {
        return Math.max(0, Math.min(1, (value - low) / (high - low)));
    }

    boolean sameDrawing(RoadBarGrid other) {
        if (!rows.equals(other.rows) || firstBucket != other.firstBucket || low != other.low || high != other.high) {
            return false;
        }
        for (int row = 0; row < rows.size(); row++) {
            for (int col = 0; col < COLUMNS; col++) {
                Bar a = bars[row][col];
                Bar b = other.bars[row][col];
                if (a == null ? b != null : b == null || a.numeric != b.numeric) return false;
            }
        }
        return true;
    }

    boolean hasData() {
        for (Bar[] row : bars) {
            for (Bar bar : row) if (bar != null) return true;
        }
        return false;
    }
}
