package rs.kiza.obd;

import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Build;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebView;
import android.widget.FrameLayout;

import java.util.Collections;
import java.util.List;
import java.util.Locale;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class EnhancedBars extends FrameLayout {
    private static final String PAGE = LocalChartPage.url("chart.html");
    private final TransmissionBars nativeChart;
    private WebView web;
    private boolean ready;
    private boolean failed;
    private boolean rotating;
    private boolean renderPending;
    private boolean newerFrame;
    private boolean review;
    private RoadBarGrid.Group group = RoadBarGrid.Group.TEMPERATURE;
    private List<AudiQ5.Channel> channels = Collections.emptyList();
    private List<RoadChartHistory.Point> history = Collections.emptyList();
    private RoadBarGrid grid = new RoadBarGrid(group, channels, history);

    EnhancedBars(Context context, TransmissionBars.SelectionListener listener) {
        super(context);
        nativeChart = new TransmissionBars(context, listener);
        addView(nativeChart, new LayoutParams(-1, -1));
    }

    void update(RoadBarGrid.Group requested, List<AudiQ5.Channel> available, List<RoadChartHistory.Point> samples) {
        if (group == requested && channels == available && history == samples) return;
        group = requested;
        channels = available;
        history = samples;
        if (nativeChart.getVisibility() == VISIBLE) nativeChart.update(group, channels, history);
        RoadBarGrid next = new RoadBarGrid(group, channels, history);
        boolean changed = !next.sameDrawing(grid);
        grid = next;
        if (grid.hasData() && web == null && !failed && isShown() && isHardwareAccelerated()) prepareWeb();
        if (ready && (changed || review)) render();
    }

    void setReviewMode() {
        review = true;
        nativeChart.setReviewMode();
    }

    void setRotating(boolean enabled) {
        rotating = enabled;
        if (ready && web != null && nativeChart.getVisibility() == INVISIBLE) {
            web.evaluateJavascript("window.obdChart.rotate(" + enabled + "," + motion() + ")", null);
        } else {
            nativeChart.setRotating(enabled);
        }
    }

    void resetCamera() {
        rotating = false;
        nativeChart.resetCamera();
        if (ready && web != null) web.evaluateJavascript("window.obdChart.reset(" + motion() + ")", null);
    }

    @Override public void onVisibilityAggregated(boolean visible) {
        super.onVisibilityAggregated(visible);
        if (!visible) nativeChart.setRotating(false);
        else if (nativeChart.getVisibility() == VISIBLE) nativeChart.setRotating(rotating);
        if (web == null) return;
        if (visible) web.onResume();
        else {
            if (ready) web.evaluateJavascript("window.obdChart.rotate(false,false)", null);
            web.onPause();
        }
        if (visible && ready && rotating) {
            web.evaluateJavascript("window.obdChart.rotate(true," + motion() + ")", null);
        }
    }

    private void prepareWeb() {
        try {
            WebView candidate = LocalChartPage.create(getContext());
            web = candidate;
            candidate.setVisibility(INVISIBLE);
            candidate.setWebViewClient(new LocalChartPage() {
                @Override public void onPageFinished(WebView view, String url) {
                    if (web != view || !PAGE.equals(url)) return;
                    view.evaluateJavascript("Boolean(window.obdChart && window.obdChart.ready())", result -> {
                        if (web != view) return;
                        if (!"true".equals(result)) {
                            fallback();
                            return;
                        }
                        ready = true;
                        render();
                    });
                }

                @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                    if (web == view) fallback();
                    return true;
                }
            });
            addView(candidate, new LayoutParams(-1, -1));
            candidate.loadUrl(PAGE);
        } catch (RuntimeException error) {
            fallback();
        }
    }

    private void render() {
        if (web == null) return;
        if (renderPending) {
            newerFrame = true;
            return;
        }
        WebView candidate = web;
        JSONObject frame;
        try {
            frame = frame();
        } catch (JSONException error) {
            fallback();
            return;
        }
        renderPending = true;
        candidate.evaluateJavascript("window.obdChart.render(" + frame + ")", result -> {
            if (web != candidate) return;
            renderPending = false;
            if (!"true".equals(result)) {
                fallback();
                return;
            }
            if (nativeChart.getVisibility() == VISIBLE) {
                nativeChart.setRotating(false);
                nativeChart.setVisibility(INVISIBLE);
                candidate.setVisibility(VISIBLE);
                if (rotating) setRotating(true);
            }
            if (newerFrame) {
                newerFrame = false;
                render();
            }
        });
    }

    private JSONObject frame() throws JSONException {
        JSONArray labels = new JSONArray();
        JSONArray bins = new JSONArray();
        JSONArray bars = new JSONArray();
        for (int column = 0; column < RoadBarGrid.COLUMNS; column++) {
            bins.put(column == RoadBarGrid.COLUMNS - 1 ? (review ? "Kursor" : "Sada")
                : "−" + ((RoadBarGrid.COLUMNS - 1 - column) * RoadBarGrid.BIN_MS / 1000) + " s");
        }
        for (int row = 0; row < grid.rows.size(); row++) {
            AudiQ5.Channel channel = grid.rows.get(row);
            labels.put(group.abbreviation(channel));
            for (int column = 0; column < RoadBarGrid.COLUMNS; column++) {
                RoadBarGrid.Bar bar = grid.bar(row, column);
                if (bar == null) continue;
                JSONArray xyz = new JSONArray().put(column).put(row).put(bar.numeric);
                String clock = review ? RoadAnalysis.time(bar.time)
                    : "pre " + String.format(Locale.ROOT, "%.1f", (grid.latest - bar.time) / 1000.0).replace('.', ',') + " s";
                String detail = channel.label + " · " + channel.display(bar.value) + " · " + clock;
                bars.put(new JSONObject().put("id", channel.name() + ":" + bar.bucket).put("xyz", xyz)
                    .put("detail", detail).put("fraction", grid.fraction(bar.numeric)));
            }
        }
        return new JSONObject().put("group", group.name()).put("unit", group.unit).put("labels", labels)
            .put("low", grid.low).put("high", grid.high).put("levels", grid.levels)
            .put("bins", bins).put("bars", bars).put("motion", motion());
    }

    private static boolean motion() {
        return Build.VERSION.SDK_INT < 26 || ValueAnimator.areAnimatorsEnabled();
    }

    private void fallback() {
        failed = true;
        destroyWeb();
        nativeChart.setVisibility(VISIBLE);
        nativeChart.update(group, channels, history);
        if (isShown()) nativeChart.setRotating(rotating);
    }

    private void destroyWeb() {
        if (web == null) return;
        WebView previous = web;
        web = null;
        ready = false;
        renderPending = false;
        newerFrame = false;
        removeView(previous);
        previous.destroy();
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        post(() -> {
            if (isAttachedToWindow() && grid.hasData() && web == null && !failed && isShown() && isHardwareAccelerated()) {
                prepareWeb();
            }
        });
    }

    @Override protected void onDetachedFromWindow() {
        destroyWeb();
        nativeChart.setVisibility(VISIBLE);
        nativeChart.setRotating(false);
        super.onDetachedFromWindow();
    }
}
