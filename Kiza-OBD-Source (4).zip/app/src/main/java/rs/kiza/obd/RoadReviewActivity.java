package rs.kiza.obd;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public final class RoadReviewActivity extends Activity {
    static final String FILE = "rs.kiza.obd.RECORDING_FILE";
    private static final int BACKGROUND = 0xFF0A1220;
    private static final int PANEL = 0xFF122135;
    private static final int TEXT = 0xFFF2F8FF;
    private static final int MUTED = 0xFFABD0E2;
    private static final int ACCENT = 0xFF6AF1C2;
    private static final int CONTROLLER = 0xFFFFBE81;
    private static final int OBSERVATION = 0xFFFFDC8E;
    private static final long STEP_MS = 250;
    private static final long FOCUS_MS = 60_000;
    private enum Mode { TIMELINE, MAP, BARS }

    private final Handler ui = new Handler(Looper.getMainLooper());
    private ScrollView scroll;
    private LinearLayout page;
    private LinearLayout chartPanel;
    private TextView clock;
    private TextView detail;
    private Button groupButton, play, rotate, speedButton, ratioMapButton, oilMapButton;
    private final Button[] modeButtons = new Button[Mode.values().length];
    private LinearLayout timelineControls;
    private LinearLayout mapControls;
    private LinearLayout camera;
    private TextView oil, deviation, gear, output;
    private TextView mapCaption;
    private TelemetryView telemetryView;
    private RoadTelemetry telemetry;
    private Mode mode = Mode.TIMELINE;
    private long from, to;
    private boolean focused;
    private boolean oilMap;
    private int speed = 4;
    private SeekBar seek;
    private EnhancedBars chart;
    private RoadRecording recording;
    private List<RoadBarGrid.Group> groups;
    private RoadBarGrid.Group group;
    private long cursor;
    private long clockStarted;
    private long playbackFrom;
    private boolean playing;
    private boolean rotating;

    private final Runnable playback = new Runnable() {
        @Override public void run() {
            if (!playing || recording == null) return;
            long next = playbackFrom + speed * (SystemClock.elapsedRealtime() - clockStarted);
            seekTo(Math.min(recording.duration, next));
            if (next >= recording.duration) stopPlayback();
            else ui.postDelayed(this, STEP_MS);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        scroll.setOnApplyWindowInsetsListener((view, insets) -> {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets safe = insets.getInsets(android.view.WindowInsets.Type.systemBars()
                    | android.view.WindowInsets.Type.displayCutout());
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
            }
            return insets;
        });
        page = column();
        page.setPadding(dp(18), dp(14), dp(18), dp(24));
        scroll.addView(page);
        setContentView(scroll);

        Button close = button("Nazad na menjač", this::finish);
        page.addView(close);
        page.addView(text("Analiza snimka", 28, TEXT, true));
        TextView loading = text("Učitavanje očitavanja…", 15, MUTED, false);
        page.addView(loading);

        String name = getIntent().getStringExtra(FILE);
        if (name == null || !name.startsWith("Q5-") || !name.endsWith(".csv") || !name.equals(new File(name).getName())) {
            loading.setText("Izabrani snimak nije dostupan.");
            return;
        }
        long restoreAt = state == null ? -1 : state.getLong("cursor", -1);
        if (state != null) {
            mode = Mode.values()[Math.max(0, Math.min(Mode.values().length - 1, state.getInt("mode", 0)))];
            speed = state.getInt("speed", 4);
        }
        new Thread(() -> {
            try {
                RoadRecording data = RoadRecording.read(new File(Q5RoadService.logDirectory(this), name));
                ShaftRatios ratios = new ShaftRatios(data);
                RoadAnalysis.Report findings = RoadAnalysis.analyze(data, ratios);
                RoadTelemetry timeline = new RoadTelemetry(data, ratios);
                runOnUiThread(() -> {
                    if (!isFinishing() && !isDestroyed()) show(loading, data, findings, timeline, restoreAt);
                });
            } catch (IOException | IllegalArgumentException error) {
                runOnUiThread(() -> {
                    if (!isDestroyed() && !isFinishing()) loading.setText("Pregled nije učitan. " + error.getLocalizedMessage());
                });
            }
        }, "q5-recording-review").start();
    }

    private void show(TextView summary, RoadRecording data, RoadAnalysis.Report report, RoadTelemetry timeline, long restoreAt) {
        recording = data;
        telemetry = timeline;
        summary.setText(report.summary);
        if (!data.identity.isEmpty()) page.addView(text(data.identity, 13, MUTED, false));
        groups = new ArrayList<>();
        for (RoadBarGrid.Group option : RoadBarGrid.Group.values()) {
            if (!option.supported(data.channels).isEmpty()) groups.add(option);
        }
        if (!groups.isEmpty()) {
            group = groups.get(0);
            if (telemetry.tracks.isEmpty()) mode = Mode.BARS;
            oilMap = telemetry.ratios.cells.isEmpty() && !telemetry.temperatures.cells.isEmpty();
            from = 0;
            to = recording.duration;
            long first = data.rows.isEmpty() ? 0 : data.rows.get(0).time;
            cursor = restoreAt >= 0 ? Math.min(data.duration, restoreAt) : first;
            buildChart();
            selectMode(mode);
            seekTo(cursor);
        }

        page.addView(text("Nalazi", 21, TEXT, true));
        if (report.findings.isEmpty()) {
            page.addView(text("Nema dovoljno podataka za prikaz nalaza.", 15, MUTED, false));
        }
        for (RoadAnalysis.Finding finding : report.findings) showFinding(finding);
        if (!report.readings.isEmpty()) {
            LinearLayout stats = panel();
            stats.addView(text("Očitani kanali", 18, TEXT, true));
            TextView values = text(report.readings, 14, MUTED, false);
            values.setLineSpacing(dp(4), 1);
            stats.addView(values);
        }
    }

    private void buildChart() {
        chartPanel = panel();
        chartPanel.addView(text("Telemetrija menjača", 19, TEXT, true));
        LinearLayout first = new LinearLayout(this);
        oil = metric(first, "Temperatura ulja");
        deviation = metric(first, "Odstupanje odnosa");
        chartPanel.addView(first);
        LinearLayout second = new LinearLayout(this);
        gear = metric(second, "Stepen prenosa");
        output = metric(second, "Izlazno vratilo");
        chartPanel.addView(second);

        LinearLayout modes = new LinearLayout(this);
        addMode(modes, Mode.TIMELINE, "Linija");
        addMode(modes, Mode.MAP, "Mapa");
        addMode(modes, Mode.BARS, "3D stubovi");
        chartPanel.addView(modes);

        telemetryView = new TelemetryView(this, telemetry, time -> {
            stopPlayback();
            seekTo(time);
        });
        chartPanel.addView(telemetryView, new LinearLayout.LayoutParams(-1, dp(360)));
        timelineControls = column();
        LinearLayout zoom = new LinearLayout(this);
        zoom.addView(button("Ceo snimak", this::fullTimeline), new LinearLayout.LayoutParams(0, -2, 1));
        zoom.addView(button("Detalj 60 s", () -> focusTimeline(cursor)), new LinearLayout.LayoutParams(0, -2, 1));
        timelineControls.addView(zoom);
        if (!telemetry.shifts.isEmpty()) {
            timelineControls.addView(button("Promene stepena (" + telemetry.shifts.size() + ")", this::chooseShift));
        }
        chartPanel.addView(timelineControls);

        mapControls = column();
        LinearLayout measures = new LinearLayout(this);
        ratioMapButton = button("Odstupanje odnosa", () -> showMap(false));
        oilMapButton = button("Temperatura ulja", () -> showMap(true));
        measures.addView(ratioMapButton, new LinearLayout.LayoutParams(0, -2, 1));
        measures.addView(oilMapButton, new LinearLayout.LayoutParams(0, -2, 1));
        mapControls.addView(measures);
        mapCaption = text("", 13, MUTED, false);
        mapControls.addView(mapCaption);
        chartPanel.addView(mapControls);

        groupButton = button(group.label, this::chooseGroup);
        chartPanel.addView(groupButton);
        detail = text("", 13, ACCENT, true);
        detail.setVisibility(View.GONE);
        chart = new EnhancedBars(this, label -> {
            detail.setText(label);
            detail.setVisibility(mode == Mode.BARS && !label.isEmpty() ? View.VISIBLE : View.GONE);
        });
        chart.setReviewMode();
        chartPanel.addView(chart, new LinearLayout.LayoutParams(-1, dp(285)));
        chartPanel.addView(detail);
        camera = new LinearLayout(this);
        rotate = button("Rotiraj", () -> {
            rotating = !rotating;
            chart.setRotating(rotating);
            rotate.setText(rotating ? "Zaustavi rotaciju" : "Rotiraj");
        });
        camera.addView(rotate, new LinearLayout.LayoutParams(0, -2, 1));
        camera.addView(button("Vrati ugao", () -> {
            rotating = false;
            rotate.setText("Rotiraj");
            chart.resetCamera();
        }), new LinearLayout.LayoutParams(0, -2, 1));
        chartPanel.addView(camera);

        clock = text("", 15, ACCENT, true);
        chartPanel.addView(clock);
        seek = new SeekBar(this);
        seek.setContentDescription("Vremenska pozicija u snimku");
        seek.setMax((int) Math.max(1, (recording.duration + STEP_MS - 1) / STEP_MS));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (fromUser) seekTo(Math.min(recording.duration, progress * STEP_MS));
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { stopPlayback(); }
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
        chartPanel.addView(seek);
        LinearLayout controls = new LinearLayout(this);
        play = button(playLabel(), this::togglePlayback);
        speedButton = button("Brzina ×" + speed, this::chooseSpeed);
        controls.addView(play, new LinearLayout.LayoutParams(0, -2, 1));
        controls.addView(speedButton, new LinearLayout.LayoutParams(0, -2, 1));
        chartPanel.addView(controls);
    }

    private TextView metric(LinearLayout row, String label) {
        LinearLayout tile = column();
        tile.setPadding(dp(8), dp(3), dp(8), dp(5));
        GradientDrawable surface = new GradientDrawable();
        surface.setColor(0xFF172A40);
        surface.setCornerRadius(dp(8));
        surface.setStroke(dp(1), 0xFF294158);
        tile.setBackground(surface);
        tile.addView(text(label, 12, MUTED, false));
        TextView value = text("—", 18, ACCENT, true);
        tile.addView(value);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -2, 1);
        params.setMargins(dp(2), dp(3), dp(2), dp(3));
        row.addView(tile, params);
        return value;
    }

    private void addMode(LinearLayout row, Mode assigned, String label) {
        Button tab = button(label, () -> selectMode(assigned));
        if (assigned != Mode.BARS) tab.setEnabled(!telemetry.tracks.isEmpty());
        modeButtons[assigned.ordinal()] = tab;
        row.addView(tab, new LinearLayout.LayoutParams(0, -2, 1));
    }

    private void selectMode(Mode requested) {
        if (requested != Mode.BARS && telemetry.tracks.isEmpty()) return;
        mode = requested;
        for (Mode item : Mode.values()) {
            Button tab = modeButtons[item.ordinal()];
            tab.setSelected(item == mode);
            tab.setTextColor(item == mode ? ACCENT : TEXT);
        }
        telemetryView.setVisibility(mode == Mode.BARS ? View.GONE : View.VISIBLE);
        timelineControls.setVisibility(mode == Mode.TIMELINE ? View.VISIBLE : View.GONE);
        mapControls.setVisibility(mode == Mode.MAP ? View.VISIBLE : View.GONE);
        chart.setVisibility(mode == Mode.BARS ? View.VISIBLE : View.GONE);
        groupButton.setVisibility(chart.getVisibility());
        camera.setVisibility(chart.getVisibility());
        detail.setVisibility(mode == Mode.BARS && detail.length() > 0 ? View.VISIBLE : View.GONE);
        if (mode == Mode.TIMELINE) telemetryView.timeline(from, to);
        if (mode == Mode.MAP) showMap(oilMap);
        seekTo(cursor);
    }

    private void showMap(boolean oil) {
        oilMap = oil;
        mapCaption.setText(oil ? "Temperatura ulja po stepenu i obrtajima izlaznog vratila. Boja kodira prosek u °C."
            : "Prosečno odstupanje od medijane svog stepena. Polja su grupisana po obrtajima izlaznog vratila.");
        ratioMapButton.setSelected(!oil);
        ratioMapButton.setTextColor(oil ? TEXT : ACCENT);
        oilMapButton.setSelected(oil);
        oilMapButton.setTextColor(oil ? ACCENT : TEXT);
        telemetryView.heatmap(oil);
    }

    private void fullTimeline() {
        focused = false;
        from = 0;
        to = recording.duration;
        telemetryView.timeline(from, to);
    }

    private void focusTimeline(long center) {
        focused = true;
        from = Math.max(0, Math.min(center - FOCUS_MS / 2, recording.duration - FOCUS_MS));
        to = Math.min(recording.duration, from + FOCUS_MS);
        telemetryView.timeline(from, to);
    }

    private void chooseShift() {
        String[] labels = telemetry.shifts.stream()
            .map(shift -> RoadAnalysis.time(shift.time) + "     " + shift.label()).toArray(String[]::new);
        new AlertDialog.Builder(this).setTitle("Promene stepena prenosa").setItems(labels, (dialog, index) -> {
            stopPlayback();
            long at = telemetry.shifts.get(index).time;
            focusTimeline(at);
            seekTo(at);
        }).setNegativeButton(R.string.cancel, null).show();
    }

    private void chooseSpeed() {
        int[] speeds = {1, 2, 4, 8};
        String[] labels = {"×1", "×2", "×4", "×8"};
        new AlertDialog.Builder(this).setTitle("Brzina reprodukcije").setItems(labels, (dialog, index) -> {
            speed = speeds[index];
            speedButton.setText("Brzina ×" + speed);
            if (playing) {
                playbackFrom = cursor;
                clockStarted = SystemClock.elapsedRealtime();
            } else {
                play.setText(playLabel());
            }
        }).setNegativeButton(R.string.cancel, null).show();
    }

    private String playLabel() { return "Pusti ×" + speed; }

    private void showFinding(RoadAnalysis.Finding finding) {
        LinearLayout item = panel();
        String label;
        int color;
        switch (finding.level) {
            case CONTROLLER: label = "Kontroler menjača"; color = CONTROLLER; break;
            case OBSERVATION: label = "Zapažanje iz snimka"; color = OBSERVATION; break;
            default: label = "Obuhvat analize"; color = MUTED; break;
        }
        item.addView(text(label, 13, color, true));
        item.addView(text(finding.title, 17, TEXT, true));
        item.addView(text(finding.evidence, 14, TEXT, false));
        item.addView(text(finding.interpretation, 14, MUTED, false));
        if (finding.time >= 0 && chart != null) {
            item.addView(button("Prikaži " + RoadAnalysis.time(finding.time), () -> {
                stopPlayback();
                if (mode == Mode.BARS && groups.contains(finding.group)) selectGroup(finding.group);
                if (!telemetry.tracks.isEmpty() && mode != Mode.BARS) {
                    if (mode != Mode.TIMELINE) selectMode(Mode.TIMELINE);
                    focusTimeline(finding.time);
                }
                seekTo(finding.time);
                scroll.smoothScrollTo(0, chartPanel.getTop());
            }));
        }
    }

    private void chooseGroup() {
        String[] labels = groups.stream().map(option -> option.label).toArray(String[]::new);
        new AlertDialog.Builder(this).setTitle("Izaberi grupu očitavanja").setItems(labels, (dialog, which) -> {
            selectGroup(groups.get(which));
            seekTo(cursor);
        }).setNegativeButton(R.string.cancel, null).show();
    }

    private void selectGroup(RoadBarGrid.Group selected) {
        group = selected;
        groupButton.setText(group.label);
    }

    private void seekTo(long time) {
        cursor = Math.max(0, Math.min(recording.duration, time));
        clock.setText(RoadAnalysis.time(cursor) + " / " + RoadAnalysis.time(recording.duration));
        seek.setProgress((int) ((cursor + STEP_MS / 2) / STEP_MS));
        setMetric(oil, telemetry.measure(AudiQ5.Channel.ATF, cursor));
        setMetric(deviation, telemetry.deviation(cursor));
        setMetric(gear, telemetry.measure(AudiQ5.Channel.GEAR, cursor));
        setMetric(output, telemetry.measure(AudiQ5.Channel.OUTPUT, cursor));
        if (mode == Mode.BARS) chart.update(group, recording.channels, recording.window(cursor));
        else {
            if (mode == Mode.TIMELINE && focused && (cursor < from || cursor > to)) focusTimeline(cursor);
            telemetryView.seek(cursor);
        }
    }

    private static void setMetric(TextView view, String reading) {
        if (!reading.contentEquals(view.getText())) view.setText(reading);
    }

    private void togglePlayback() {
        if (playing) {
            stopPlayback();
            return;
        }
        if (cursor >= recording.duration) seekTo(0);
        playbackFrom = cursor;
        clockStarted = SystemClock.elapsedRealtime();
        playing = true;
        play.setText("Pauza");
        ui.post(playback);
    }

    private void stopPlayback() {
        playing = false;
        ui.removeCallbacks(playback);
        if (play != null) play.setText(playLabel());
    }

    @Override protected void onStop() {
        stopPlayback();
        super.onStop();
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        if (recording != null) state.putLong("cursor", cursor);
        state.putInt("mode", mode.ordinal());
        state.putInt("speed", speed);
        super.onSaveInstanceState(state);
    }

    private LinearLayout panel() {
        LinearLayout container = column();
        container.setPadding(dp(13), dp(11), dp(13), dp(13));
        GradientDrawable background = new GradientDrawable();
        background.setCornerRadius(dp(13));
        background.setColor(PANEL);
        background.setStroke(dp(1), 0xFF294158);
        container.setBackground(background);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(12);
        page.addView(container, params);
        return container;
    }

    private LinearLayout column() {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        return container;
    }

    private TextView text(String label, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(label);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setPadding(0, dp(5), 0, dp(3));
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button button(String label, Runnable action) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setOnClickListener(v -> action.run());
        return button;
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
