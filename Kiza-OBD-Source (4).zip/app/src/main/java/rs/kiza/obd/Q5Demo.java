package rs.kiza.obd;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

final class Q5Demo implements Obd.Link {
    private int ticks;

    @Override
    public String command(String command, int timeoutMillis) throws IOException {
        switch (command) {
            case "ATZ": return "ELM327 Q5 DEMO\r";
            case "ATE0": case "ATL0": case "ATS1": case "ATH0": case "ATSP0":
            case "ATCAF1": case "ATCFC1": case "ATSH7E1": case "ATCRA7E9": return "OK\r";
            case "0100": return "41 00 00 00 00 00\r";
            case "ATDPN": return "A6\r";
            case "22F187": return ascii("62 F1 87", "8R0927156S");
            case "22F19E": return ascii("62 F1 9E", "EV_TCMDL501_A02");
            case "22F191": return ascii("62 F1 91", "0B5927156J");
            case "22F189": return ascii("62 F1 89", "0010");
            case "1902FF": return "59 02 FF 17 D8 00 28\r";
            case "22210F1": return byteValue("62 21 0F", 4 + ++ticks / 8 % 4);
            case "2221041": return byteValue("62 21 04", 110 + (int) (10 * (1 + Math.sin(ticks / 45.0))));
            case "2221021": return wordValue("62 21 02", 4400 + (ticks % 8) * 600);
            case "2221031": return wordValue("62 21 03", 2800 + (ticks % 8) * 400);
            case "22102B1": return byteValue("62 10 2B", 85 + ticks % 7);
            case "22102C1": return byteValue("62 10 2C", 88 + ticks % 5);
            case "2203011": return byteValue("62 03 01", 106 + ticks % 11);
            case "2210C91": return wordValue("62 10 C9", 0x8200);
            case "2210EA1": return wordValue("62 10 EA", 0x5C00);
            case "2210ED1": return wordValue("62 10 ED", 2);
            default: return "NO DATA\r";
        }
    }

    private static String ascii(String lead, String value) {
        StringBuilder out = new StringBuilder(lead);
        for (byte b : value.getBytes(StandardCharsets.US_ASCII)) {
            out.append(String.format(Locale.US, " %02X", b));
        }
        return out.append('\r').toString();
    }

    private static String byteValue(String header, int value) {
        return String.format(Locale.US, "%s %02X\r", header, value);
    }

    private static String wordValue(String header, int value) {
        return String.format(Locale.US, "%s %02X %02X\r", header, value >> 8, value & 255);
    }
}
