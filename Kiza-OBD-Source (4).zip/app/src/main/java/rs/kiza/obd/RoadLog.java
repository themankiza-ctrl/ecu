package rs.kiza.obd;

import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

final class RoadLog implements Closeable {
    private static final DateTimeFormatter FILE_TIME = DateTimeFormatter
        .ofPattern("uuuuMMdd-HHmmss-SSS", Locale.ROOT).withZone(ZoneId.systemDefault());
    final File file;
    private final BufferedWriter writer;
    private final String source;
    private final long start;
    int rows;

    RoadLog(File folder, boolean demo, Instant now, long elapsed) throws IOException {
        Files.createDirectories(folder.toPath());
        source = demo ? "demo" : "vehicle";
        file = new File(folder, "Q5-" + source + "-" + FILE_TIME.format(now) + ".csv");
        writer = Files.newBufferedWriter(file.toPath(), StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW,
            StandardOpenOption.WRITE);
        start = elapsed;
        try {
            StringBuilder header = new StringBuilder("utc,elapsed_ms,sample_ms,event,source,tcm_part,odx_or_system,tcm_hardware,"
                + "tcm_software,tcm_dtc_status");
            for (AudiQ5.Channel channel : AudiQ5.Channel.values()) header.append(',').append(channel.column);
            header.append(",tcm_dtc_scan");
            writer.write(header.toString());
            writer.newLine();
            writer.flush();
        } catch (IOException writeError) {
            try {
                writer.close();
            } catch (IOException closeError) {
                writeError.addSuppressed(closeError);
            }
            throw writeError;
        }
    }

    void event(Instant when, long elapsed, String event, AudiQ5.Session session) throws IOException {
        String prefix = prefix(when, elapsed, "", event);
        if (session == null) {
            writer.write(prefix + ",,,,,");
        } else {
            writer.write(prefix + "," + csv(session.part) + "," + csv(session.module) + ","
                + csv(session.hardware) + "," + csv(session.softwareVersion) + "," + csv(session.faults.codes));
        }
        int channels = AudiQ5.Channel.values().length;
        for (int i = 0; i < channels; i++) writer.write(',');
        writer.write(',');
        if (session != null) writer.write(session.faults.status.name());
        writer.newLine();
        writer.flush();
    }

    void sample(Instant when, long elapsed, long duration, AudiQ5.Sample sample) throws IOException {
        writer.write(prefix(when, elapsed, Long.toString(duration), "sample") + ",,,,,");
        for (String value : sample.values) {
            writer.write(',');
            if (value != null) writer.write(value);
        }
        writer.write(',');
        writer.newLine();
        writer.flush();
        rows++;
    }

    private String prefix(Instant utc, long elapsed, String duration, String event) {
        return utc + "," + (elapsed - start) + "," + duration + "," + event + "," + source;
    }

    private static String csv(String input) {
        if (input.isEmpty()) return "";
        if ("=+-@".indexOf(input.charAt(0)) >= 0) input = "'" + input;
        return "\"" + input.replace("\"", "\"\"") + "\"";
    }

    @Override public void close() throws IOException { writer.close(); }
}
