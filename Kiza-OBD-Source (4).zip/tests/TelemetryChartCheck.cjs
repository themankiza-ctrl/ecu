const assert = require("node:assert/strict");
const chartEngine = require("../app/src/main/assets/obd-chart/echarts.min.js");
const { timeline, heatmap, clock } = require("../app/src/main/assets/obd-chart/telemetry-options.js");

const frame = {
  type: "timeline", from: 0, to: 45000,
  shifts: [[10000, 3], [23000, 4]],
  tracks: [
    { id: "ATF", label: "Temperatura ulja", lane: 0, points: [[0, 67], [5000, 71], [10000, null], [15000, 75]] },
    { id: "INPUT", label: "Ulazno vratilo", lane: 1, points: [[0, 500], [2000, 800], [45000, 1800]] },
    { id: "OUTPUT", label: "Izlazno vratilo", lane: 1, points: [[0, 200], [2000, 450], [45000, 725]] },
    { id: "GEAR", label: "Stepen prenosa", lane: 2, points: [[0, 2], [10000, 3], [23000, 4], [45000, 4]] }
  ]
};

function render(option) {
  const chart = chartEngine.init(null, null, { renderer: "svg", ssr: true, width: 366, height: 350 });
  try {
    chart.setOption(option);
    return chart.renderToSVGString();
  } finally {
    chart.dispose();
  }
}

const options = timeline(frame, 13000, true);
assert.deepEqual(options.dataZoom[0].xAxisIndex, [0, 1, 2]);
assert.equal(options.series[0].data[2][1], null);
assert.equal(options.series[3].step, "end");
assert.equal(options.series[3].markPoint.data.length, 2);
assert.equal(options.series[1].markLine.data[0].xAxis, 13000);
assert.match(render(options), /Temperature · °C/);
const map = {
  labels: ["0–249", "250–499", "500–749", "750–999"],
  cells: [[1, 2, 14, 8, 35, 16000], [2, 1, 7, 5, 10, 24000]],
  min: 0, max: 14, unit: "%"
};
const heat = heatmap(map, true);
assert.equal(heat.series[0].data[0][5], 16000);
assert.match(render(heat), /Izlazno vratilo · o\/min/);
assert.equal(clock(3661000), "1:01:01");
console.log("Passed offline ECharts timeline and heatmap SVG renders, linked axes, cursor, gaps and shift markers.");
