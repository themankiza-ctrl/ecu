package rs.kiza.obd;

import java.util.Arrays;
import java.util.List;

public final class RoadTelemetryCheck {
    public static void main(String[] args) {
        RoadRecording road = new RoadRecording();
        road.identity = "EV_TCMDL501";
        road.channels.addAll(Arrays.asList(AudiQ5.Channel.ATF, AudiQ5.Channel.GEAR,
            AudiQ5.Channel.INPUT, AudiQ5.Channel.OUTPUT));
        for (int i = 0; i < 35; i++) {
            double in = i == 29 ? 2600 : 2000;
            road.rows.add(row(i * 1000, "3", 80 + i % 2, in, 1000));
        }
        road.rows.add(row(35000, "4", 83, 1800, 1050));
        road.rows.add(row(48000, "2", 83, 1800, 1050));
        road.rows.add(row(49000, "R", 81, 1800, 1050));
        road.duration = 49000;
        RoadTelemetry data = new RoadTelemetry(road, new ShaftRatios(road));

        expect(4, data.tracks.size());
        expect("83 °C", data.measure(AudiQ5.Channel.ATF, 40000));
        expect("—", data.measure(AudiQ5.Channel.GEAR, 40000));
        expect("R", data.measure(AudiQ5.Channel.GEAR, 49000));
        expect("30 %", data.deviation(29000));
        expect("—", data.deviation(35000));

        expect(2, data.shifts.size());
        expect("3 → 4", data.shifts.get(0).label());
        expect("2 → R", data.shifts.get(1).label());
        expect(1, data.visibleShifts(34000, 48000).size());

        expect(1, data.ratios.cells.size());
        RoadTelemetry.Cell ratio = data.ratios.cells.get(0);
        expect(3, ratio.gear);
        expect("1000–1249", data.ratios.labels.get(ratio.column));
        expect(29000L, ratio.time);
        expect(300, (int) Math.round(ratio.peak * 10));
        expect(1, data.temperatures.cells.stream().filter(cell -> cell.gear == 2).findFirst().get().count);

        RoadTelemetry.Track gear = data.track(AudiQ5.Channel.GEAR);
        List<RoadTelemetry.Point> gapped = gear.plot(33000, 49000);
        expect(true, gapped.stream().anyMatch(point -> point.value == null && point.time == 35001));
        RoadTelemetry.Track shaft = data.track(AudiQ5.Channel.INPUT);
        expect(true, shaft.plot(0, 2 * 60 * 60 * 1000).stream().anyMatch(point -> Double.valueOf(2600).equals(point.value)));

        road.identity = "nepoznat";
        RoadTelemetry unknown = new RoadTelemetry(road, new ShaftRatios(road));
        expect(0, unknown.ratios.cells.size());
        expect(3, unknown.temperatures.cells.size());
        System.out.println("Passed telemetry readings, sample freshness, gear events, plot gaps, peaks and speed-bin maps.");
    }

    private static RoadRecording.Row row(long time, String gear, double temp, double in, double out) {
        String[] values = new String[AudiQ5.Channel.values().length];
        values[AudiQ5.Channel.GEAR.ordinal()] = gear;
        values[AudiQ5.Channel.ATF.ordinal()] = Double.toString(temp);
        values[AudiQ5.Channel.INPUT.ordinal()] = Double.toString(in);
        values[AudiQ5.Channel.OUTPUT.ordinal()] = Double.toString(out);
        return new RoadRecording.Row(time, 150, values);
    }

    private static void expect(Object expected, Object actual) {
        if (!expected.equals(actual)) throw new AssertionError("Expected " + expected + ", got " + actual);
    }
}
