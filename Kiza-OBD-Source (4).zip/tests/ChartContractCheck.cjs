const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const code = fs.readFileSync(path.join(__dirname, "../app/src/main/assets/obd-chart/chart.js"), "utf8");

function setup(supportsWebGL) {
  const frames = [];
  const callbacks = new Map();
  const output = {};
  const element = { addEventListener(name, callback) { callbacks.set(name, callback); } };
  const instance = {
    on(name, callback) { callbacks.set(name, callback); },
    setOption(option) { frames.push(option); },
    resize() {}
  };
  const window = { echarts: { init: () => instance }, addEventListener() {} };
  const document = {
    getElementById: id => id === "chart" ? element : output,
    createElement: () => ({ getContext: () => supportsWebGL ? { getExtension: () => null } : null })
  };
  vm.runInNewContext(code, { window, document, devicePixelRatio: 1, console });
  return { chart: window.obdChart, frames, callbacks, output };
}

const { chart, frames, callbacks, output } = setup(true);
assert.equal(chart.ready(), true);
const frame = {
  group: "TEMPERATURE", unit: "°C", low: -10, high: 100, levels: 5, motion: false,
  bins: ["−5 s", "Kursor"], labels: ["ATF", "K1"],
  bars: [{ id: "ATF:1", xyz: [1, 0, 58], detail: "ATF · 58 °C · 00:00:05", fraction: 0.6 }]
};
assert.equal(chart.render(frame), true);
assert.equal(frames[0].series[0].type, "bar3D");
assert.equal(frames[0].series[0].data.length, 1);
assert.equal(frames[0].series[0].data[0].value, frame.bars[0].xyz);
assert.equal(frames[0].animation, false);
callbacks.get("click")({ data: frames[0].series[0].data[0] });
assert.equal(output.textContent, frame.bars[0].detail);
chart.rotate(true, true);
assert.equal(frames[1].grid3D.viewControl.autoRotate, true);
chart.reset(false);
assert.equal(frames[2].grid3D.viewControl.autoRotate, false);
assert.equal(chart.render({ ...frame, group: "GEAR", bars: [] }), true);
assert.equal(frames[3].zAxis3D.axisLabel.formatter(-1), "R");
callbacks.get("webglcontextlost")();
assert.equal(chart.render(frame), false);

const disabled = setup(false);
assert.equal(disabled.chart.ready(), false);
assert.equal(disabled.chart.render(frame), false);
console.log("Passed 3D chart frame, selection, camera options, motion setting and fallback contract.");
