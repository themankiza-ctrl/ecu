package rs.kiza.obd;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public final class Q5ProtocolCheck {
    public static void main(String[] args) throws Exception {
        expect("36", AudiQ5.Channel.ATF.value("62 21 04 4C"));
        expect("53", AudiQ5.Channel.MODULE_TEMP.value("62 03 01 5D"));
        expect("1538", AudiQ5.Channel.CLUTCH_1_ADAPT.value("62 10 C9 02 06"));
        expect("", AudiQ5.Channel.CLUTCH_2_ADAPT.value("62 10 EA FF FF"));
        expect(false, AudiQ5.Channel.CLUTCH_2_ADAPT.responds("62 10 EA FF FF"));
        expect("", AudiQ5.Channel.CLUTCH_2_ADAPT_FAILED.value("62 10 ED FF FF"));
        expect("2", AudiQ5.Channel.CLUTCH_2_ADAPT_FAILED.value("62 10 ED 00 02"));
        expect("831.00", AudiQ5.Channel.INPUT.value("62 21 02 0C FC"));
        expect("318.00", AudiQ5.Channel.OUTPUT.value("62210304F8"));
        expect("1", AudiQ5.Channel.GEAR.value("62 21 0F 03"));
        expect("R", AudiQ5.Channel.GEAR.value("62 21 0F 01"));
        expect("", AudiQ5.Channel.GEAR.value("62 21 0F 02"));
        expect("", AudiQ5.Channel.GEAR.value("62 21 0F 0A"));
        expect("", AudiQ5.Channel.ATF.value("62 21 04 00 4C"));
        expect("", AudiQ5.Channel.CLUTCH_1.value("62 10 2B FF"));
        expect("", AudiQ5.Channel.CLUTCH_2.value("7F 22 31"));
        expect("P17D800:28|U010100:09", AudiQ5.decodeFaults(
            "00B\r0: 59 02 FF 17 D8 00\r1: 28 C1 01 00 09\r>").codes);
        expect("P17D800 · potvrđena", AudiQ5.decodeFaults("59 02 FF 17 D8 00 28").message);
        expect("", AudiQ5.decodeFaults("NO DATA").codes);
        expect("Upravljačka jedinica menjača nije završila očitavanje grešaka.",
            AudiQ5.decodeFaults("59 02 FF 17 D8 00").message);

        Q5Demo demo = new Q5Demo();
        List<String> requests = new ArrayList<>();
        AudiQ5.Session session = new AudiQ5.Session((request, timeout) -> {
            requests.add(request);
            return demo.command(request, timeout);
        });
        session.initialize();
        expect(true, session.isDl501);
        expect(10, session.supported.size());
        expect("8R0927156S", session.part);
        AudiQ5.Sample sample = session.sample(true);
        expect("130", sample.values[AudiQ5.Channel.CLUTCH_1_ADAPT.ordinal()]);
        expect("92", sample.values[AudiQ5.Channel.CLUTCH_2_ADAPT.ordinal()]);
        expect(true, !sample.values[AudiQ5.Channel.GEAR.ordinal()].isEmpty());
        AudiQ5.Sample fast = session.sample(false);
        expect(null, fast.values[AudiQ5.Channel.ATF.ordinal()]);
        expect(sample.values[AudiQ5.Channel.ATF.ordinal()],
            fast.over(sample).values[AudiQ5.Channel.ATF.ordinal()]);
        expect(true, requests.containsAll(Arrays.asList("ATSH7E1", "ATCRA7E9")));
        expect(false, requests.contains("ATSH7E0"));
        expect(false, requests.contains("ATCRA7E8"));
        for (String request : requests) {
            if (!request.matches("AT[A-Z0-9]+|0100|22[0-9A-F]{4}1?|1902FF")) {
                throw new AssertionError("Unexpected request " + request);
            }
        }

        Q5Demo otherDemo = new Q5Demo();
        AudiQ5.Session differentGearbox = new AudiQ5.Session((request, timeout) -> {
            if (request.equals("22F191")) return "62 F1 91 30 42 4B";
            if (request.equals("22F19E")) return "62 F1 9E 45 56 5F 54 43 4D 5A 46";
            if (request.matches("22[0-9A-F]{4}1")) throw new AssertionError("Used unconfirmed profile");
            return otherDemo.command(request, timeout);
        });
        differentGearbox.initialize();
        expect(false, differentGearbox.isDl501);
        expect(0, differentGearbox.supported.size());
        expect("P17D800:28", differentGearbox.faults.codes);
        expect(null, differentGearbox.sample(true).values[0]);
        RoadChartHistory graph = new RoadChartHistory();
        expect(1, graph.append(0, sample).size());
        expect(2, graph.append(1000, fast).size());
        expect(1, graph.append(61200, sample).size());

        checkBarGrid();

        File folder = Files.createTempDirectory("q5-log-check").toFile();
        Instant now = Instant.parse("2026-11-20T14:00:00Z");
        File file;
        try (RoadLog log = new RoadLog(folder, true, now, 1000)) {
            log.event(now, 1000, "start", session);
            log.sample(now.plusMillis(300), 1300, 220, sample);
            log.sample(now.plusMillis(600), 1600, 220, fast);
            log.event(now.plusSeconds(1), 2000, "end_scan", session);
            log.event(now.plusSeconds(1), 2001, "stop", null);
            file = log.file;
        }
        List<String> csv = Files.readAllLines(file.toPath(), StandardCharsets.UTF_8);
        expect(6, csv.size());
        expect(false, csv.get(0).contains("engine_rpm"));
        expect(true, csv.get(0).contains("tcm_c,clutch_1_adapt_ok,clutch_2_adapt_ok,clutch_2_adapt_failed"));
        for (String line : csv) expect(21, line.split(",", -1).length);
        expect(true, csv.get(1).contains("P17D800:28"));
        expect(true, csv.get(2).contains(",300,220,sample,demo,"));
        expect("", csv.get(3).split(",", -1)[11]);
        expect(true, csv.get(4).contains(",end_scan,demo,"));
        Files.delete(file.toPath());
        Files.delete(folder.toPath());
        System.out.println("Passed Q5 DTC decoding, sampled gearbox channels, profile gating, and CSV integrity.");
    }

    private static void checkBarGrid() {
        List<AudiQ5.Channel> available = Arrays.asList(AudiQ5.Channel.ATF, AudiQ5.Channel.MODULE_TEMP,
            AudiQ5.Channel.INPUT);
        List<RoadChartHistory.Point> points = Arrays.asList(
            new RoadChartHistory.Point(5100, chartSample("51", "47")),
            new RoadChartHistory.Point(5600, chartSample("52", null)),
            new RoadChartHistory.Point(6400, chartSample("", "48")),
            new RoadChartHistory.Point(15600, chartSample("-7", "110")));
        RoadBarGrid grid = new RoadBarGrid(RoadBarGrid.Group.TEMPERATURE, available, points);
        expect(Arrays.asList(AudiQ5.Channel.ATF, AudiQ5.Channel.MODULE_TEMP), grid.rows);
        expect("52", grid.at(AudiQ5.Channel.ATF, 1).value);
        expect(5600L, grid.at(AudiQ5.Channel.ATF, 1).time);
        expect("48", grid.at(AudiQ5.Channel.MODULE_TEMP, 1).value);
        expect(null, grid.at(AudiQ5.Channel.ATF, 2));
        expect("-7", grid.at(AudiQ5.Channel.ATF, 3).value);
        expect(null, grid.at(AudiQ5.Channel.INPUT, 1));
        expect(true, grid.low <= -7);
        expect(true, grid.high >= 110);
        expect(true, grid.fraction(48) < grid.fraction(52));
        expect(false, new RoadBarGrid(RoadBarGrid.Group.SHAFTS, available, points).hasData());
    }

    private static AudiQ5.Sample chartSample(String atf, String tcm) {
        String[] values = new String[AudiQ5.Channel.values().length];
        values[AudiQ5.Channel.ATF.ordinal()] = atf;
        values[AudiQ5.Channel.MODULE_TEMP.ordinal()] = tcm;
        return new AudiQ5.Sample(values);
    }

    private static void expect(Object expected, Object actual) {
        if (!Objects.equals(expected, actual)) throw new AssertionError("Expected " + expected + ", got " + actual);
    }
}
