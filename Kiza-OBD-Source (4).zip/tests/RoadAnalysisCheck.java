package rs.kiza.obd;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.List;

public final class RoadAnalysisCheck {
    private static final Instant START = Instant.parse("2026-11-20T14:00:00Z");

    public static void main(String[] args) throws Exception {
        Path folder = Files.createTempDirectory("q5-analysis");
        Path anomaly = null;
        Path quiet = null;
        Path legacy = null;
        try {
            anomaly = recording(folder.toFile(), true).toPath();
            RoadRecording data = RoadRecording.read(anomaly.toFile());
            if (!data.demo || data.channels.size() != 10 || data.startScan.status != AudiQ5.ScanStatus.OK ||
                data.startScan.codes.size() != 0 || data.endScan.codes.get("P17D800") != 0x28) {
                throw new AssertionError("Recording metadata and DTC parse");
            }
            RoadAnalysis.Report changed = RoadAnalysis.analyze(data);
            check(changed, "P17D800", "Prvi put očitan");
            check(changed, "P17CF00", "prisutan pri očitavanju");
            check(changed, "Temperatura kvačila 1 · Brz porast", "°C");
            check(changed, "Trajna razlika temperature kvačila", "25 °C");
            check(changed, "Odstupanje odnosa vratila · 3.", "%");
            check(changed, "Uzastopne promene", "3. i 4.");
            check(changed, "Neuspešne adaptacije kvačila 2", "(+2)");
            check(changed, "Ograničenja snimka", "8 s");
            List<RoadChartHistory.Point> window = data.window(78_000);
            if (window.isEmpty() || window.get(window.size() - 1).millis != 78_000) {
                throw new AssertionError("Replay window should end at the cursor");
            }
            if (window.stream().anyMatch(point -> point.millis < 18_000 || point.millis > 78_000)) {
                throw new AssertionError("Replay window outside time limits");
            }

            quiet = recording(folder.toFile(), false).toPath();
            RoadAnalysis.Report steady = RoadAnalysis.analyze(RoadRecording.read(quiet.toFile()));
            if (steady.findings.stream().anyMatch(f -> f.level != RoadAnalysis.Level.COVERAGE)) {
                throw new AssertionError("Steady, well-sampled drive should not generate alarms");
            }
            if (!steady.summary.contains("očitano bez kodova")) throw new AssertionError("DTC negative status lost");

            legacy = folder.resolve("Q5-vehicle-legacy.csv");
            String oldLog = "elapsed_ms,event,source,odx_or_system,tcm_dtc_status,gear,atf_c\n" +
                "0,start,vehicle,\"EV_TCMDL501_\"\"A02\"\"\",\"\",,\n" +
                "500,sample,vehicle,,,2,NaN\n" +
                "600,sample,vehicle,,,R,-3\n" +
                "700,end_scan,vehicle,,P17D800:28,,\n" +
                "800,stop,vehicle,,,,\n";
            Files.writeString(legacy, oldLog);
            RoadRecording legacyData = RoadRecording.read(legacy.toFile());
            if (legacyData.rows.size() != 2 || legacyData.malformed != 1 || !legacyData.identity.contains("\"A02\"") ||
                legacyData.startScan.usable() || legacyData.endScan.codes.get("P17D800") != 0x28) {
                throw new AssertionError("Backward-compatible CSV, missing scan evidence, and quoted fields");
            }
            if (RoadAnalysis.analyze(legacyData).findings.stream().anyMatch(f -> f.evidence.contains("Prvi put"))) {
                throw new AssertionError("Cannot infer a newly observed code without a readable baseline");
            }
            System.out.println("Passed report and replay checks for normal, anomalous, partial, and legacy recordings.");
        } finally {
            if (anomaly != null) Files.deleteIfExists(anomaly);
            if (quiet != null) Files.deleteIfExists(quiet);
            if (legacy != null) Files.deleteIfExists(legacy);
            Files.deleteIfExists(folder);
        }
    }

    private static File recording(File folder, boolean anomaly) throws Exception {
        Instant utc = anomaly ? START : START.plusSeconds(600);
        AudiQ5.Session session = new AudiQ5.Session(new Q5Demo());
        session.initialize();
        session.faults = AudiQ5.decodeFaults("59 02 FF");
        try (RoadLog log = new RoadLog(folder, anomaly, utc, 0)) {
            log.event(utc, 0, "start", session);
            for (int i = 1; i <= 86; i++) {
                if (anomaly && i > 75 && i < 83) continue;
                long time = i * 1000L;
                String[] values = {
                    anomaly && i >= 63 && i <= 67 && (i % 2 == 1) ? "4" : "3",
                    "67", anomaly && i >= 48 && i <= 53 ? "2550" : "2000", "1000",
                    Integer.toString(anomaly ? Math.min(100, 64 + Math.max(0, (i - 18) * 2)) : 64),
                    "64", "70", "100", "92", anomaly && i >= 20 ? "3" : "1"
                };
                log.sample(utc.plusMillis(time), time, 90, new AudiQ5.Sample(values));
            }
            if (anomaly) session.faults = AudiQ5.decodeFaults("59 02 FF 17 D8 00 28 17 CF 00 09");
            log.event(utc.plusSeconds(87), 87_000, "end_scan", session);
            log.event(utc.plusSeconds(87), 87_001, "stop", null);
            return log.file;
        }
    }

    private static void check(RoadAnalysis.Report report, String title, String evidence) {
        if (report.findings.stream().noneMatch(finding -> finding.title.contains(title) && finding.evidence.contains(evidence))) {
            throw new AssertionError("Missing finding " + title + ": " + report.findings.stream()
                .map(finding -> finding.title + " (" + finding.evidence + ")").toList());
        }
    }
}
