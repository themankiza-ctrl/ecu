package rs.kiza.obd;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public final class ProtocolCheck {
    public static void main(String[] args) throws Exception {
        checkPayloads();
        checkProtocolDiscovery();
        checkTransport();
        System.out.println("Passed response framing, CAN discovery and timeout recovery.");
    }

    private static void checkPayloads() {
        List<int[]> frames = Obd.payloads("00B\r0: 59 02 FF 17 D8 00\r1: 28 C1 01 00 09\r>");
        expect(1, frames.size());
        expect(11, frames.get(0).length);
        expect(0x09, frames.get(0)[10]);
        expect(true, Obd.payloads("00B\r0: 59 02 FF 17 D8 00\r2: 28 C1 01 00 09\r>").isEmpty());
        expect(0x41, Obd.payloads("SEARCHING...41 00 00 00 00 00\r>").get(0)[0]);
    }

    private static void checkProtocolDiscovery() throws IOException {
        List<String> commands = new ArrayList<>();
        Q5Demo demo = new Q5Demo();
        expect(6, Obd.detectProtocol((command, timeout) -> {
            commands.add(command);
            return demo.command(command, timeout);
        }));
        expect(Arrays.asList("ATZ", "ATE0", "ATL0", "ATS1", "ATH0", "ATSP0", "0100", "ATDPN"), commands);
    }

    private static void checkTransport() throws IOException {
        ScheduledExecutorService timer = Executors.newSingleThreadScheduledExecutor();
        ByteArrayOutputStream commands = new ByteArrayOutputStream();
        try {
            ByteArrayInputStream replies = new ByteArrayInputStream(
                "ELM327\r>41 0D 00\r>".getBytes(StandardCharsets.US_ASCII));
            try (ElmConnection elm = new ElmConnection(transport(replies, commands, () -> {}), timer)) {
                elm.connect();
                expect("ELM327\r", elm.command("ATZ", 3000));
                expect("41 0D 00\r", elm.command("010D", 3000));
                expect("ATZ\r010D\r", commands.toString("US-ASCII"));
            }

            CountDownLatch closed = new CountDownLatch(1);
            InputStream stall = new InputStream() {
                @Override public int read() throws IOException {
                    try {
                        closed.await();
                        return -1;
                    } catch (InterruptedException e) {
                        throw new IOException(e);
                    }
                }
            };
            try (ElmConnection elm = new ElmConnection(transport(stall, commands, closed::countDown), timer)) {
                elm.connect();
                try {
                    elm.command("0100", 50);
                    throw new AssertionError("Expected a timeout");
                } catch (SocketTimeoutException expected) {
                    expect(0L, closed.getCount());
                }
            }
        } finally {
            timer.shutdownNow();
        }
    }

    private static ElmConnection.Transport transport(InputStream in, OutputStream out, Runnable close) {
        return new ElmConnection.Transport() {
            @Override public void connect() {}
            @Override public InputStream input() { return in; }
            @Override public OutputStream output() { return out; }
            @Override public void close() { close.run(); }
        };
    }

    private static void expect(Object expected, Object actual) {
        if (!java.util.Objects.equals(expected, actual)) {
            throw new AssertionError("Expected " + expected + ", got " + actual);
        }
    }
}
